<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$page_title = 'Tugon Chatbot';
?>
<?php include '../templates/header.php'; ?>

<section class="dashboard-hero ai-page-hero">
    <div class="hero-text">
        <h1>Tugon Chatbot</h1>
        <p>Ask about certificates, blessings, sacramental services, request status, schedules, requirements, registration, and parish announcements.</p>
    </div>
    <div class="hero-quote">
        Parish assistance chat for Tugon-related questions.
    </div>
</section>

<section class="ai-workspace ai-workspace-chat-only">
    <div class="card-panel ai-chat-panel">
        <div class="panel-title"><i class="fas fa-comments"></i> Chat with Tugon</div>
        <div class="ai-chat-log" id="aiChatLog" aria-live="polite"></div>
        <form class="ai-chat-form" id="aiChatForm">
            <label class="visually-hidden" for="aiMessage">Ask a parish question</label>
            <textarea id="aiMessage" rows="3" placeholder="Example: How do I request a baptismal certificate?"></textarea>
            <div class="ai-form-actions">
                <button class="btn btn-outline-primary" type="button" data-ai-prompt="Show my request status guidance">Status Help</button>
                <button class="btn btn-outline-primary" type="button" data-ai-prompt="Search Mass schedule">Find Schedule</button>
                <button class="btn btn-primary" type="submit"><i class="fas fa-wand-magic-sparkles"></i> Ask Assistant</button>
            </div>
        </form>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('aiChatForm');
    const input = document.getElementById('aiMessage');
    const log = document.getElementById('aiChatLog');
    const promptButtons = document.querySelectorAll('[data-ai-prompt]');

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, function(char) {
            return ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'})[char];
        });
    }

    function addMessage(type, html) {
        const item = document.createElement('div');
        item.className = 'ai-message ' + type;
        item.innerHTML = html;
        log.appendChild(item);
        log.scrollTop = log.scrollHeight;
    }

    function askAssistant(message, mode) {
        addMessage('user', '<strong>You</strong><p>' + escapeHtml(message) + '</p>');
        addMessage('assistant loading', '<strong>Tugon Chatbot</strong><div class="ai-typing-dots" aria-label="Tugon Chatbot is typing"><span></span><span></span><span></span></div>');

        fetch('../api/ai-assistant.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: message, mode: mode || 'chat'})
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            const loading = log.querySelector('.ai-message.loading');
            if (loading) loading.remove();
            if (!data.success) {
                addMessage('assistant', '<strong>Tugon Chatbot</strong><p>' + escapeHtml(data.message || 'The chatbot could not answer right now.') + '</p>');
                return;
            }
            const steps = data.guidance && data.guidance.steps
                ? '<ol>' + data.guidance.steps.map(function(step) { return '<li>' + escapeHtml(step) + '</li>'; }).join('') + '</ol>'
                : '';
            addMessage('assistant', '<strong>' + escapeHtml(data.guidance.title) + '</strong><p>' + escapeHtml(data.answer) + '</p>' + steps);
        })
        .catch(function() {
            const loading = log.querySelector('.ai-message.loading');
            if (loading) loading.remove();
            addMessage('assistant', '<strong>Tugon Chatbot</strong><p>Unable to reach the chatbot endpoint. Please try again.</p>');
        });
    }

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const message = input.value.trim();
        if (!message) return;
        input.value = '';
        askAssistant(message, 'chat');
    });

    promptButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const prompt = button.getAttribute('data-ai-prompt');
            askAssistant(prompt, 'chat');
        });
    });
});
</script>

<?php include '../templates/footer.php'; ?>
