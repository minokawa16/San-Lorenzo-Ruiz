    <?php if (isset($is_user_area) && $is_user_area): ?>
            </main>
            <footer class="user-footer">
                <span>&copy; 2026 San Lorenzo Ruiz Mission Station</span>
                <span><?php echo e(t('footer.tagline', 'Serving with faith and care')); ?></span>
            </footer>
        </div>
    </div>
    <?php elseif (isset($is_admin_area) && $is_admin_area): ?>
        </main>
    </div>
    <?php else: ?>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2026 San Lorenzo Ruiz Mission Station. <?php echo e(t('footer.rights', 'All rights reserved.')); ?></p>
            <p><small><?php echo e(t('footer.powered', 'Powered by AI for efficient parish services')); ?></small></p>
        </div>
    </footer>
    <?php endif; ?>

    <div class="language-switcher floating-language" aria-label="<?php echo e(t('lang.label', 'Language')); ?>">
        <span><?php echo e(t('lang.label', 'Language')); ?></span>
        <a href="<?php echo e(tugonLanguageUrl('en')); ?>" class="<?php echo tugonCurrentLanguage() === 'en' ? 'active' : ''; ?>">EN</a>
        <a href="<?php echo e(tugonLanguageUrl('fil')); ?>" class="<?php echo tugonCurrentLanguage() === 'fil' ? 'active' : ''; ?>">FIL</a>
    </div>

    <?php if (isLoggedIn()): ?>
    <div class="ai-assistant-widget" id="aiAssistantWidget">
        <button class="ai-assistant-trigger" type="button" id="aiAssistantTrigger" aria-label="<?php echo e(t('chatbot.trigger_label', 'AI Parish Assistant')); ?>" aria-expanded="false">
            <span class="ai-assistant-glow" aria-hidden="true"></span>
            <span class="ai-assistant-icon" aria-hidden="true">
                <i class="fas fa-robot"></i>
                <i class="fas fa-wand-magic-sparkles"></i>
            </span>
        </button>
        <div class="ai-assistant-tooltip" role="tooltip"><?php echo e(t('chatbot.title', 'Tugon Chatbot')); ?></div>
        <section class="ai-assistant-panel" id="aiAssistantPanel" aria-hidden="true">
            <div class="ai-assistant-panel-header">
                <div class="ai-assistant-panel-mark" aria-hidden="true">
                    <i class="fas fa-wand-magic-sparkles"></i>
                </div>
                <div>
                    <strong><?php echo e(t('chatbot.title', 'Tugon Chatbot')); ?></strong>
                    <span><?php echo e(t('chatbot.subtitle', 'Parish assistance chat')); ?></span>
                </div>
                <button class="ai-assistant-close" type="button" id="aiAssistantClose" aria-label="<?php echo e(t('chatbot.close_label', 'Close AI assistant')); ?>">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="ai-assistant-panel-body">
                <div class="ai-assistant-live-answer" id="aiAssistantLiveAnswer" hidden>
                    <div class="ai-assistant-empty-state" id="aiAssistantEmptyState">
                        <i class="fas fa-comments"></i>
                        <span><?php echo e(t('chatbot.empty', 'Ask anything about Tugon or parish services.')); ?></span>
                    </div>
                </div>

                <form class="ai-assistant-live-form" id="aiAssistantLiveForm">
                    <label class="ai-assistant-search" for="aiAssistantLiveInput">
                        <i class="fas fa-message" aria-hidden="true"></i>
                        <input type="text" id="aiAssistantLiveInput" data-no-autocomplete="true" placeholder="<?php echo e(t('chatbot.placeholder', 'Ask about certificates, status, schedule...')); ?>">
                    </label>
                    <button type="submit"><i class="fas fa-paper-plane"></i> <?php echo e(t('chatbot.send', 'Send')); ?></button>
                </form>
            </div>
        </section>
    </div>
    <?php endif; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Custom JS -->
    <script src="../assets/js/main.js"></script>
    <?php if (isLoggedIn()): ?>
    <script>
        (function() {
            const widget = document.getElementById('aiAssistantWidget');
            const trigger = document.getElementById('aiAssistantTrigger');
            const panel = document.getElementById('aiAssistantPanel');
            const close = document.getElementById('aiAssistantClose');
            const liveForm = document.getElementById('aiAssistantLiveForm');
            const liveInput = document.getElementById('aiAssistantLiveInput');
            const liveAnswer = document.getElementById('aiAssistantLiveAnswer');
            const chatLabels = {
                title: <?php echo json_encode(t('chatbot.title', 'Tugon Chatbot')); ?>,
                you: <?php echo json_encode(t('chatbot.you', 'You')); ?>,
                typing: <?php echo json_encode(t('chatbot.typing', 'Tugon Chatbot is typing')); ?>,
                unable: <?php echo json_encode(t('chatbot.unable', 'Unable to answer right now.')); ?>,
                noAnswer: <?php echo json_encode(t('chatbot.no_answer', 'I could not find a Tugon answer for that question.')); ?>,
                endpointError: <?php echo json_encode(t('chatbot.endpoint_error', 'Unable to reach the chatbot endpoint. Please try again.')); ?>
            };

            if (!widget || !trigger || !panel || !close) {
                return;
            }

            function setAssistantOpen(isOpen) {
                widget.classList.toggle('is-open', isOpen);
                trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
                panel.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
            }

            function escapeHtml(value) {
                return String(value).replace(/[&<>"']/g, function(char) {
                    return ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'})[char];
                });
            }

            function appendChatMessage(type, title, message) {
                if (!liveAnswer) {
                    return null;
                }
                liveAnswer.hidden = false;
                const emptyState = document.getElementById('aiAssistantEmptyState');
                if (emptyState) {
                    emptyState.remove();
                }
                const item = document.createElement('div');
                item.className = 'ai-assistant-chat-message ' + type;
                item.innerHTML = '<strong>' + escapeHtml(title) + '</strong><p>' + escapeHtml(message) + '</p>';
                liveAnswer.appendChild(item);
                liveAnswer.scrollTop = liveAnswer.scrollHeight;
                return item;
            }

            function appendTypingBubble() {
                if (!liveAnswer) {
                    return null;
                }
                liveAnswer.hidden = false;
                const emptyState = document.getElementById('aiAssistantEmptyState');
                if (emptyState) {
                    emptyState.remove();
                }
                const item = document.createElement('div');
                item.className = 'ai-assistant-chat-message assistant loading';
                item.innerHTML = '<strong>' + escapeHtml(chatLabels.title) + '</strong><div class="ai-typing-dots" aria-label="' + escapeHtml(chatLabels.typing) + '"><span></span><span></span><span></span></div>';
                liveAnswer.appendChild(item);
                liveAnswer.scrollTop = liveAnswer.scrollHeight;
                return item;
            }

            function askLiveAssistant(message) {
                if (!liveAnswer) {
                    return;
                }
                appendChatMessage('user', chatLabels.you, message);
                const loading = appendTypingBubble();

                fetch('<?php echo BASE_URL; ?>api/ai-assistant.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({message: message, mode: 'chat'})
                })
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (loading) {
                        loading.remove();
                    }
                    if (!data.success) {
                        appendChatMessage('assistant', chatLabels.title, data.message || chatLabels.unable);
                        return;
                    }
                    appendChatMessage('assistant', data.guidance.title || chatLabels.title, data.answer || chatLabels.noAnswer);
                })
                .catch(function() {
                    if (loading) {
                        loading.remove();
                    }
                    appendChatMessage('assistant', chatLabels.title, chatLabels.endpointError);
                });
            }

            trigger.addEventListener('click', function() {
                setAssistantOpen(!widget.classList.contains('is-open'));
            });

            close.addEventListener('click', function() {
                setAssistantOpen(false);
            });

            if (liveForm && liveInput) {
                liveForm.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const message = liveInput.value.trim();
                    if (!message) {
                        return;
                    }
                    liveInput.value = '';
                    askLiveAssistant(message);
                });
            }

            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    setAssistantOpen(false);
                }
            });
        })();
    </script>
    <?php endif; ?>
    <script>
        (function() {
            const toggle = document.getElementById('darkModeToggle') || document.getElementById('adminThemeToggle');
            if (!toggle) {
                return;
            }
            const prefersDark = localStorage.getItem('theme') === 'dark' || localStorage.getItem('parishTheme') === 'dark';
            if (prefersDark) {
                document.body.setAttribute('data-theme', 'dark');
            }
            toggle.addEventListener('click', function() {
                const isDark = document.body.getAttribute('data-theme') === 'dark';
                if (isDark) {
                    document.body.removeAttribute('data-theme');
                    localStorage.setItem('theme', 'light');
                    localStorage.setItem('parishTheme', 'light');
                } else {
                    document.body.setAttribute('data-theme', 'dark');
                    localStorage.setItem('theme', 'dark');
                    localStorage.setItem('parishTheme', 'dark');
                }
            });
        })();
    </script>
</body>
</html>
