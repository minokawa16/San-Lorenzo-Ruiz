<?php
// Database Configuration
define('DB_SERVER', 'localhost');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_PASS', '');
define('DB_NAME', 'parish_management_system');

// Create connection using consistent constant names
$conn = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn->connect_error) {
    // If connection fails due to database not existing, try to create it
    if (strpos($conn->connect_error, 'Unknown database') !== false) {
        // Connect without specifying database
        $temp_conn = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD);
        if ($temp_conn->connect_error) {
            die("Connection failed: " . $temp_conn->connect_error . " <br>Please check your database credentials in config.php");
        }
        
        // Try to run install script
        $install_url = str_replace('config.php', 'install.php', __FILE__);
        if (file_exists($install_url)) {
            header("Location: " . str_replace(dirname(__FILE__), '', $install_url));
            exit();
        }
        
        $temp_conn->close();
        die("Database not found. Please run the installation script at /database/install.php");
    }
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8");

?>
