<?php
/**
 * Centralized Session Management
 * Safe session initialization - prevents duplicate session_start() warnings
 * 
 * Usage: Include this file at the very beginning of every page that needs a session
 * <?php include '../includes/session.php'; ?>
 */

// Only start session if one hasn't been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Session timeout check
// Skip timeout check on login/auth pages to prevent redirect loops
$current_file = basename($_SERVER['PHP_SELF']);
$auth_pages = ['login.php', 'register.php', 'logout.php', 'profile.php'];

if (!in_array($current_file, $auth_pages)) {
    // Optional: Set session timeout (30 minutes)
    $timeout = 30 * 60; // 30 minutes in seconds
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout)) {
        // Session expired
        session_unset();
        session_destroy();
        header("Location: ../auth/login.php?session=expired");
        exit();
    }
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();
?>
