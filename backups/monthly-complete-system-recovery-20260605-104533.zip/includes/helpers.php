<?php
/**
 * Helper Functions and Authentication
 * AI-Powered Parish Request and Sacramental Records Management System
 * Provides utility functions for authentication, validation, and security
 */

if (!defined('BASE_URL')) {
    define('BASE_URL', '/ParishSystem/');
}

if (!function_exists('t')) {
    include_once __DIR__ . '/i18n.php';
}

// Generate unique reference numbers for requests
function generateReferenceNumber() {
    return 'PRQ-' . date('Ymd') . '-' . mt_rand(10000, 99999);
}

// Sanitize input data - remove special characters and trim whitespace
function sanitize($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function e($data) {
    return htmlspecialchars((string) $data, ENT_QUOTES, 'UTF-8');
}

// Validate email format
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Hash password using bcrypt (PASSWORD_DEFAULT uses bcrypt by default)
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
}

// Verify password against bcrypt hash
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Check if password needs rehashing (for bcrypt algorithm updates)
function passwordNeedsRehash($hash) {
    return password_needs_rehash($hash, PASSWORD_DEFAULT, ['cost' => 10]);
}

// Validate password strength
function isValidPassword($password) {
    // Minimum 8 characters, at least one uppercase, one lowercase, one number
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/', $password);
}

// Create notification
function createNotification($conn, $user_id, $title, $message) {
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    if (!$stmt) {
        return false;
    }

    $user_id = intval($user_id);
    $stmt->bind_param('iss', $user_id, $title, $message);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function ensureEmailNotificationSchema($conn) {
    ensureUserVerificationSchema($conn);

    $conn->query("CREATE TABLE IF NOT EXISTS email_verifications (
        verification_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        email VARCHAR(150) NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        verified_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_email_verifications_user (user_id),
        INDEX idx_email_verifications_token (token_hash)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS otp_codes (
        otp_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        email VARCHAR(150) NOT NULL,
        purpose VARCHAR(40) NOT NULL,
        otp_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        attempts INT DEFAULT 0,
        verified_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_otp_user_purpose (user_id, purpose),
        INDEX idx_otp_email_purpose (email, purpose)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS notification_logs (
        log_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NULL,
        email VARCHAR(150) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        notification_type VARCHAR(80) DEFAULT 'system',
        delivery_status VARCHAR(30) DEFAULT 'pending',
        error_message TEXT NULL,
        sent_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_notification_logs_status (delivery_status),
        INDEX idx_notification_logs_created (created_at)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS announcement_recipients (
        recipient_id INT PRIMARY KEY AUTO_INCREMENT,
        announcement_id INT NOT NULL,
        user_id INT NOT NULL,
        email VARCHAR(150) NOT NULL,
        delivery_status VARCHAR(30) DEFAULT 'pending',
        sent_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_announcement_user (announcement_id, user_id)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS notification_preferences (
        preference_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        category VARCHAR(80) NOT NULL,
        email_enabled TINYINT(1) DEFAULT 1,
        in_app_enabled TINYINT(1) DEFAULT 1,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_user_category (user_id, category)
    )");

    $columns = [
        'email_verified_at' => "ALTER TABLE users ADD COLUMN email_verified_at TIMESTAMP NULL DEFAULT NULL AFTER email",
        'email_verification_sent_at' => "ALTER TABLE users ADD COLUMN email_verification_sent_at TIMESTAMP NULL DEFAULT NULL AFTER email_verified_at",
        'login_otp_enabled' => "ALTER TABLE users ADD COLUMN login_otp_enabled TINYINT(1) DEFAULT 0 AFTER email_verification_sent_at"
    ];

    foreach ($columns as $column => $sql) {
        if (!columnExists($conn, 'users', $column)) {
            $conn->query($sql);
        }
    }

    $conn->query("UPDATE users SET email_verified_at = COALESCE(email_verified_at, NOW()) WHERE status = 'active' AND email_verified_at IS NULL");
}

function tugonMailConfig() {
    $defaults = [
        'from_email' => 'no-reply@tugon.local',
        'from_name' => 'TUGON Parish System',
        'reply_to' => '',
        'enabled' => true
    ];
    $path = __DIR__ . '/../config/mail.php';
    if (is_file($path)) {
        $config = include $path;
        if (is_array($config)) {
            return array_merge($defaults, $config);
        }
    }
    return $defaults;
}

function sendTugonEmail($conn, $to, $subject, $html_body, $text_body = '', $user_id = null, $type = 'system') {
    $config = tugonMailConfig();
    $status = 'failed';
    $error = '';
    $ok = false;

    if (!empty($config['enabled'])) {
        $from = $config['from_email'];
        $from_name = $config['from_name'];
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from . '>'
        ];
        if (!empty($config['reply_to'])) {
            $headers[] = 'Reply-To: ' . $config['reply_to'];
        }
        $ok = @mail($to, $subject, $html_body, implode("\r\n", $headers));
        if (!$ok) {
            $error = 'PHP mail() failed. Configure SMTP/sendmail in XAMPP or add an SMTP provider.';
        }
    } else {
        $error = 'Email sending disabled in config/mail.php.';
    }

    $status = $ok ? 'sent' : 'failed';
    $sent_at = $ok ? date('Y-m-d H:i:s') : null;
    $stmt = $conn->prepare("INSERT INTO notification_logs (user_id, email, subject, notification_type, delivery_status, error_message, sent_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $uid = $user_id ? intval($user_id) : null;
        $stmt->bind_param('issssss', $uid, $to, $subject, $type, $status, $error, $sent_at);
        $stmt->execute();
        $stmt->close();
    }

    return ['ok' => $ok, 'error' => $error];
}

function tugonEmailTemplate($title, $body, $button_label = '', $button_url = '') {
    $button = '';
    if ($button_label !== '' && $button_url !== '') {
        $button = '<p style="margin:24px 0;"><a href="' . e($button_url) . '" style="background:#d7ad43;color:#171205;padding:12px 18px;border-radius:8px;text-decoration:none;font-weight:700;">' . e($button_label) . '</a></p>';
    }
    return '<div style="font-family:Arial,sans-serif;background:#f7f9fc;padding:24px;color:#172033;">'
        . '<div style="max-width:620px;margin:0 auto;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;">'
        . '<h2 style="margin:0 0 10px;">' . e($title) . '</h2>'
        . '<div style="line-height:1.6;color:#334155;">' . $body . '</div>'
        . $button
        . '<p style="border-top:1px solid #e5e7eb;margin-top:24px;padding-top:14px;color:#64748b;font-size:13px;">San Lorenzo Ruiz Mission Station | TUGON Parish System</p>'
        . '</div></div>';
}

function createEmailVerification($conn, $user_id, $email) {
    ensureEmailNotificationSchema($conn);
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $expires = date('Y-m-d H:i:s', time() + 86400);
    $stmt = $conn->prepare("INSERT INTO email_verifications (user_id, email, token_hash, expires_at) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $uid = intval($user_id);
        $stmt->bind_param('isss', $uid, $email, $hash, $expires);
        $stmt->execute();
        $stmt->close();
    }
    $conn->query("UPDATE users SET email_verification_sent_at = NOW() WHERE id = " . intval($user_id));
    return $token;
}

function sendEmailVerificationMessage($conn, $user_id, $email, $fullname = '') {
    $token = createEmailVerification($conn, $user_id, $email);
    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL;
    $url = $base . 'auth/verify-email.php?token=' . urlencode($token);
    $body = '<p>Hello ' . e($fullname ?: 'Parishioner') . ',</p><p>Please verify your Gmail address to continue your TUGON registration.</p><p>This verification link expires in 24 hours.</p>';
    return sendTugonEmail($conn, $email, 'Verify your TUGON Gmail account', tugonEmailTemplate('Gmail Verification', $body, 'Verify Gmail', $url), '', $user_id, 'email_verification');
}

function createOtpCode($conn, $user_id, $email, $purpose = 'registration') {
    ensureEmailNotificationSchema($conn);
    $recent = $conn->prepare("SELECT created_at FROM otp_codes WHERE email = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1");
    if ($recent) {
        $recent->bind_param('ss', $email, $purpose);
        $recent->execute();
        $row = $recent->get_result()->fetch_assoc();
        $recent->close();
        if ($row && strtotime($row['created_at']) > time() - 60) {
            return ['ok' => false, 'error' => 'Please wait 60 seconds before requesting another OTP.'];
        }
    }

    $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $hash = password_hash($otp, PASSWORD_DEFAULT);
    $expires = date('Y-m-d H:i:s', time() + 300);
    $stmt = $conn->prepare("INSERT INTO otp_codes (user_id, email, purpose, otp_hash, expires_at) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        return ['ok' => false, 'error' => 'Unable to create OTP.'];
    }
    $uid = intval($user_id);
    $stmt->bind_param('issss', $uid, $email, $purpose, $hash, $expires);
    $stmt->execute();
    $stmt->close();
    return ['ok' => true, 'otp' => $otp, 'expires_at' => $expires];
}

function sendOtpEmail($conn, $user_id, $email, $purpose = 'registration') {
    $created = createOtpCode($conn, $user_id, $email, $purpose);
    if (!$created['ok']) {
        return $created;
    }
    $body = '<p>Your TUGON verification code is:</p><p style="font-size:28px;font-weight:800;letter-spacing:6px;">' . e($created['otp']) . '</p><p>This OTP expires in 5 minutes. Do not share it with anyone.</p>';
    $sent = sendTugonEmail($conn, $email, 'Your TUGON OTP Code', tugonEmailTemplate('One-Time Password', $body), '', $user_id, 'otp_' . $purpose);
    return ['ok' => $sent['ok'], 'error' => $sent['error'] ?? '', 'expires_at' => $created['expires_at']];
}

function verifyOtpCode($conn, $user_id, $email, $purpose, $otp) {
    $stmt = $conn->prepare("SELECT otp_id, otp_hash, expires_at, attempts, verified_at FROM otp_codes WHERE user_id = ? AND email = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1");
    if (!$stmt) {
        return ['ok' => false, 'error' => 'Unable to verify OTP.'];
    }
    $uid = intval($user_id);
    $stmt->bind_param('iss', $uid, $email, $purpose);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row || $row['verified_at']) {
        return ['ok' => false, 'error' => 'OTP not found. Please request a new code.'];
    }
    if (strtotime($row['expires_at']) < time()) {
        return ['ok' => false, 'error' => 'OTP expired. Please request a new code.'];
    }
    if (intval($row['attempts']) >= 5) {
        return ['ok' => false, 'error' => 'Too many OTP attempts. Please request a new code.'];
    }
    $conn->query("UPDATE otp_codes SET attempts = attempts + 1 WHERE otp_id = " . intval($row['otp_id']));
    if (!password_verify($otp, $row['otp_hash'])) {
        return ['ok' => false, 'error' => 'Invalid OTP code.'];
    }
    $conn->query("UPDATE otp_codes SET verified_at = NOW() WHERE otp_id = " . intval($row['otp_id']));
    return ['ok' => true];
}

function userAllowsEmailCategory($conn, $user_id, $category) {
    $stmt = $conn->prepare("SELECT email_enabled FROM notification_preferences WHERE user_id = ? AND category = ? LIMIT 1");
    if ($stmt) {
        $uid = intval($user_id);
        $stmt->bind_param('is', $uid, $category);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            return intval($row['email_enabled']) === 1;
        }
    }
    return true;
}

function sendRequestSubmittedEmail($conn, $user_id, $reference_number, $request_label) {
    if (!userAllowsEmailCategory($conn, $user_id, 'requests')) {
        return ['ok' => true, 'skipped' => true];
    }
    $stmt = $conn->prepare("SELECT fullname, email FROM users WHERE id = ? LIMIT 1");
    if (!$stmt) {
        return ['ok' => false, 'error' => 'Unable to load user email.'];
    }
    $uid = intval($user_id);
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$user) {
        return ['ok' => false, 'error' => 'User not found.'];
    }
    $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL . 'users/my-requests.php?q=' . urlencode($reference_number);
    $body = '<p>Hello ' . e($user['fullname']) . ',</p><p>Your ' . e($request_label) . ' was submitted successfully.</p><p>Reference number: <strong>' . e($reference_number) . '</strong></p><p>You will receive updates when the parish office reviews your request.</p>';
    return sendTugonEmail($conn, $user['email'], 'TUGON Request Submitted - ' . $reference_number, tugonEmailTemplate('Request Submitted', $body, 'Track Request', $url), '', $user_id, 'request_submitted');
}

function columnExists($conn, $table, $column) {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $column_safe = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column_safe'");
    return $result && $result->num_rows > 0;
}

function tableExists($conn, $table) {
    $table_safe = $conn->real_escape_string(preg_replace('/[^a-zA-Z0-9_]/', '', $table));
    $result = $conn->query("SHOW TABLES LIKE '$table_safe'");
    return $result && $result->num_rows > 0;
}

function ensureChatbotInquirySchema($conn) {
    if (!$conn) {
        return false;
    }

    $sql = "CREATE TABLE IF NOT EXISTS chatbot_inquiries (
        inquiry_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NULL,
        user_role VARCHAR(30) DEFAULT 'user',
        question TEXT NOT NULL,
        answer_preview TEXT,
        mode VARCHAR(40) DEFAULT 'chat',
        context_limited TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_chatbot_inquiries_created (created_at),
        INDEX idx_chatbot_inquiries_user (user_id)
    )";

    return (bool) $conn->query($sql);
}

function logChatbotInquiry($conn, $user_id, $role, $question, $answer, $mode = 'chat', $context_limited = true) {
    if (!ensureChatbotInquirySchema($conn)) {
        return false;
    }

    $stmt = $conn->prepare("INSERT INTO chatbot_inquiries (user_id, user_role, question, answer_preview, mode, context_limited) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        return false;
    }

    $user_id = !empty($user_id) ? intval($user_id) : null;
    $role = substr((string) $role, 0, 30);
    $question = trim((string) $question);
    $answer = mb_strimwidth(trim((string) $answer), 0, 500, '...');
    $mode = substr((string) $mode, 0, 40);
    $context_limited = $context_limited ? 1 : 0;

    $stmt->bind_param('issssi', $user_id, $role, $question, $answer, $mode, $context_limited);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function ensureExpandedRequestTypeSchema($conn) {
    if (!$conn) {
        return false;
    }

    $result = $conn->query("SHOW TABLES LIKE 'requests'");
    if (!$result || $result->num_rows === 0) {
        return false;
    }

    return (bool) $conn->query("ALTER TABLE requests MODIFY COLUMN request_type VARCHAR(80) NOT NULL");
}

function ensureRequestDocumentsSchema($conn) {
    if (!$conn || !tableExists($conn, 'requests')) {
        return false;
    }

    $sql = "CREATE TABLE IF NOT EXISTS request_documents (
        document_id INT PRIMARY KEY AUTO_INCREMENT,
        request_id INT NOT NULL,
        uploaded_by INT NOT NULL,
        document_type VARCHAR(60) DEFAULT 'requirement',
        file_path VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(120) NOT NULL,
        file_size INT UNSIGNED NOT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        deleted_at TIMESTAMP NULL DEFAULT NULL,
        INDEX idx_request_documents_request (request_id),
        INDEX idx_request_documents_uploader (uploaded_by)
    )";

    return (bool) $conn->query($sql);
}

function getRequestDocumentConfig() {
    return [
        'max_size' => 10 * 1024 * 1024,
        'extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
        'mime_types' => [
            'image/jpeg',
            'image/png',
            'image/gif',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'text/plain'
        ]
    ];
}

function isRequestImageDocument($mime_type) {
    return in_array((string) $mime_type, ['image/jpeg', 'image/png', 'image/gif'], true);
}

function saveRequestRequirementDocument($conn, $request_id, $uploaded_by, $file) {
    if (!isset($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'saved' => false];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Unable to upload the requirements file. Please try again.'];
    }

    $config = getRequestDocumentConfig();
    $original_name = basename($file['name']);
    $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $size = intval($file['size']);
    $tmp_name = $file['tmp_name'];
    $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : false;
    $mime_type = $finfo ? finfo_file($finfo, $tmp_name) : mime_content_type($tmp_name);
    if ($finfo) {
        finfo_close($finfo);
    }

    if ($size > $config['max_size']) {
        return ['ok' => false, 'error' => 'Requirements file must not exceed 10MB.'];
    }

    if (!in_array($extension, $config['extensions'], true) || !in_array($mime_type, $config['mime_types'], true)) {
        return ['ok' => false, 'error' => 'Requirements file type is not allowed. Use an image, PDF, Office document, or text file.'];
    }

    $upload_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'request_requirements';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    $index_file = $upload_dir . DIRECTORY_SEPARATOR . 'index.php';
    if (!is_file($index_file)) {
        file_put_contents($index_file, "<?php\nhttp_response_code(403);\nexit('Access denied');\n");
    }
    $htaccess_file = $upload_dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess_file)) {
        file_put_contents($htaccess_file, "Options -Indexes\nRequire all denied\nDeny from all\n");
    }

    $safe_filename = 'request-' . intval($request_id) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
    $target_path = $upload_dir . DIRECTORY_SEPARATOR . $safe_filename;
    if (!move_uploaded_file($tmp_name, $target_path)) {
        return ['ok' => false, 'error' => 'Unable to save the requirements file.'];
    }

    $db_path = 'uploads/request_requirements/' . $safe_filename;
    $stmt = $conn->prepare("INSERT INTO request_documents (request_id, uploaded_by, document_type, file_path, original_name, mime_type, file_size) VALUES (?, ?, 'requirement', ?, ?, ?, ?)");
    if (!$stmt) {
        @unlink($target_path);
        return ['ok' => false, 'error' => 'Unable to prepare the requirements file record.'];
    }

    $request_id = intval($request_id);
    $uploaded_by = intval($uploaded_by);
    $stmt->bind_param('iisssi', $request_id, $uploaded_by, $db_path, $original_name, $mime_type, $size);
    if (!$stmt->execute()) {
        @unlink($target_path);
        $stmt->close();
        return ['ok' => false, 'error' => 'Unable to save the requirements file record.'];
    }

    $document_id = $stmt->insert_id;
    $stmt->close();

    return ['ok' => true, 'saved' => true, 'document_id' => $document_id];
}

function ensureExpandedAnnouncementTypeSchema($conn) {
    if (!$conn) {
        return false;
    }

    $result = $conn->query("SHOW TABLES LIKE 'announcements'");
    if (!$result || $result->num_rows === 0) {
        return false;
    }

    return (bool) $conn->query("ALTER TABLE announcements MODIFY COLUMN type VARCHAR(50) DEFAULT 'announcement'");
}

function ensureAnnouncementAttachmentSchema($conn) {
    if (!$conn || !tableExists($conn, 'announcements')) {
        return false;
    }

    $columns = [
        'attachment_path' => "ALTER TABLE announcements ADD COLUMN attachment_path VARCHAR(255) NULL AFTER image_path",
        'attachment_original_name' => "ALTER TABLE announcements ADD COLUMN attachment_original_name VARCHAR(255) NULL AFTER attachment_path",
        'attachment_mime_type' => "ALTER TABLE announcements ADD COLUMN attachment_mime_type VARCHAR(120) NULL AFTER attachment_original_name",
        'attachment_size' => "ALTER TABLE announcements ADD COLUMN attachment_size INT UNSIGNED NULL AFTER attachment_mime_type"
    ];

    foreach ($columns as $column => $sql) {
        if (!columnExists($conn, 'announcements', $column)) {
            $conn->query($sql);
        }
    }

    return true;
}

function getAnnouncementAttachmentConfig() {
    return [
        'max_size' => 10 * 1024 * 1024,
        'extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
        'mime_types' => [
            'image/jpeg',
            'image/png',
            'image/gif',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'text/plain'
        ]
    ];
}

function isAnnouncementImageAttachment($mime_type) {
    return in_array((string) $mime_type, ['image/jpeg', 'image/png', 'image/gif'], true);
}

function formatFileSize($bytes) {
    $bytes = intval($bytes);
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1) . ' KB';
    }
    return $bytes . ' B';
}

function ensureUserVerificationSchema($conn) {
    $conn->query("ALTER TABLE users MODIFY COLUMN status ENUM('active','inactive','pending_verification','rejected','archived') DEFAULT 'active'");

    $columns = [
        'first_name' => "ALTER TABLE users ADD COLUMN first_name VARCHAR(100) NULL AFTER fullname",
        'surname' => "ALTER TABLE users ADD COLUMN surname VARCHAR(100) NULL AFTER first_name",
        'middle_initial' => "ALTER TABLE users ADD COLUMN middle_initial VARCHAR(5) NULL AFTER surname",
        'address' => "ALTER TABLE users ADD COLUMN address VARCHAR(255) NULL AFTER chapel_district",
        'birthdate' => "ALTER TABLE users ADD COLUMN birthdate DATE NULL AFTER address",
        'id_number_hash' => "ALTER TABLE users ADD COLUMN id_number_hash CHAR(64) NULL AFTER birthdate",
        'id_number_encrypted' => "ALTER TABLE users ADD COLUMN id_number_encrypted TEXT NULL AFTER id_number_hash",
        'valid_id_path' => "ALTER TABLE users ADD COLUMN valid_id_path VARCHAR(255) NULL AFTER profile_picture",
        'valid_id_original_name' => "ALTER TABLE users ADD COLUMN valid_id_original_name VARCHAR(255) NULL AFTER valid_id_path",
        'valid_id_mime_type' => "ALTER TABLE users ADD COLUMN valid_id_mime_type VARCHAR(100) NULL AFTER valid_id_original_name",
        'valid_id_capture_method' => "ALTER TABLE users ADD COLUMN valid_id_capture_method VARCHAR(40) DEFAULT 'live_camera' AFTER valid_id_mime_type",
        'face_image_path' => "ALTER TABLE users ADD COLUMN face_image_path VARCHAR(255) NULL AFTER valid_id_capture_method",
        'face_image_mime_type' => "ALTER TABLE users ADD COLUMN face_image_mime_type VARCHAR(100) NULL AFTER face_image_path",
        'face_verification_status' => "ALTER TABLE users ADD COLUMN face_verification_status VARCHAR(40) DEFAULT 'pending' AFTER face_image_mime_type",
        'face_verified_at' => "ALTER TABLE users ADD COLUMN face_verified_at TIMESTAMP NULL DEFAULT NULL AFTER face_verification_status",
        'ocr_extracted_text_encrypted' => "ALTER TABLE users ADD COLUMN ocr_extracted_text_encrypted MEDIUMTEXT NULL AFTER face_verified_at",
        'ocr_extracted_data_encrypted' => "ALTER TABLE users ADD COLUMN ocr_extracted_data_encrypted TEXT NULL AFTER ocr_extracted_text_encrypted",
        'ocr_match_score' => "ALTER TABLE users ADD COLUMN ocr_match_score TINYINT UNSIGNED DEFAULT 0 AFTER ocr_extracted_data_encrypted",
        'ocr_status' => "ALTER TABLE users ADD COLUMN ocr_status VARCHAR(40) DEFAULT 'manual_review' AFTER ocr_match_score",
        'ocr_processed_at' => "ALTER TABLE users ADD COLUMN ocr_processed_at TIMESTAMP NULL DEFAULT NULL AFTER ocr_status",
        'rejection_reason' => "ALTER TABLE users ADD COLUMN rejection_reason TEXT NULL AFTER ocr_processed_at",
        'verified_at' => "ALTER TABLE users ADD COLUMN verified_at TIMESTAMP NULL DEFAULT NULL AFTER rejection_reason",
        'verified_by' => "ALTER TABLE users ADD COLUMN verified_by INT NULL AFTER verified_at"
    ];

    foreach ($columns as $column => $sql) {
        if (!columnExists($conn, 'users', $column)) {
            $conn->query($sql);
        }
    }

    if (!indexExists($conn, 'users', 'idx_users_id_number_hash')) {
        $conn->query("CREATE INDEX idx_users_id_number_hash ON users (id_number_hash)");
    }
}

function indexExists($conn, $table, $index) {
    $table_safe = $conn->real_escape_string($table);
    $index_safe = $conn->real_escape_string($index);
    $result = $conn->query("SHOW INDEX FROM `$table_safe` WHERE Key_name = '$index_safe'");
    return $result && $result->num_rows > 0;
}

function getVerificationEncryptionKey() {
    $configured = getenv('PARISH_VERIFICATION_KEY');
    if ($configured) {
        return hash('sha256', $configured, true);
    }

    $seed = (defined('DB_NAME') ? DB_NAME : 'parish') . '|' . __DIR__ . '|verification-documents';
    return hash('sha256', $seed, true);
}

function encryptSensitiveValue($plain_text) {
    if ($plain_text === null || $plain_text === '') {
        return null;
    }

    $iv = random_bytes(16);
    $ciphertext = openssl_encrypt((string) $plain_text, 'AES-256-CBC', getVerificationEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    if ($ciphertext === false) {
        return null;
    }

    return base64_encode($iv . $ciphertext);
}

function decryptSensitiveValue($encrypted_text) {
    if (!$encrypted_text) {
        return '';
    }

    $payload = base64_decode($encrypted_text, true);
    if ($payload === false || strlen($payload) <= 16) {
        return '';
    }

    $iv = substr($payload, 0, 16);
    $ciphertext = substr($payload, 16);
    $plain = openssl_decrypt($ciphertext, 'AES-256-CBC', getVerificationEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    return $plain === false ? '' : $plain;
}

function encryptUploadedFile($source_path, $target_path) {
    $contents = @file_get_contents($source_path);
    if ($contents === false) {
        return false;
    }

    $encrypted = encryptSensitiveValue($contents);
    if (!$encrypted) {
        return false;
    }

    return file_put_contents($target_path, $encrypted, LOCK_EX) !== false;
}

function decryptStoredFile($path) {
    if (!is_file($path)) {
        return false;
    }

    return decryptSensitiveValue(file_get_contents($path));
}

function decodeCameraCapture($data_url, $max_bytes = 5242880) {
    if (!is_string($data_url) || !preg_match('/^data:image\/(jpeg|png);base64,([A-Za-z0-9+\/=\r\n]+)$/', $data_url, $matches)) {
        return ['ok' => false, 'error' => 'Invalid camera capture format.'];
    }

    $binary = base64_decode($matches[2], true);
    if ($binary === false || $binary === '') {
        return ['ok' => false, 'error' => 'Camera capture could not be decoded.'];
    }

    if (strlen($binary) > $max_bytes) {
        return ['ok' => false, 'error' => 'Camera capture must not exceed 5MB.'];
    }

    $image_info = @getimagesizefromstring($binary);
    if (!$image_info || !in_array($image_info['mime'], ['image/jpeg', 'image/png'], true)) {
        return ['ok' => false, 'error' => 'Camera capture must be a valid JPG or PNG image.'];
    }

    return [
        'ok' => true,
        'binary' => $binary,
        'mime_type' => $image_info['mime'],
        'extension' => $image_info['mime'] === 'image/png' ? 'png' : 'jpg'
    ];
}

function saveEncryptedCameraCapture($capture, $directory, $prefix) {
    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }

    $filename = $prefix . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(6)) . '.' . $capture['extension'] . '.enc';
    $target_path = $directory . DIRECTORY_SEPARATOR . $filename;
    $encrypted = encryptSensitiveValue($capture['binary']);
    if (!$encrypted || file_put_contents($target_path, $encrypted, LOCK_EX) === false) {
        return false;
    }

    return [
        'filename' => $filename,
        'path' => $target_path
    ];
}

function normalizeIdentityValue($value) {
    return strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $value));
}

function hashIdentityNumber($id_number) {
    return hash('sha256', normalizeIdentityValue($id_number));
}

function runValidIdOcr($image_path) {
    $result = [
        'available' => false,
        'text' => '',
        'error' => ''
    ];

    if (!is_file($image_path)) {
        $result['error'] = 'ID image file was not found.';
        return $result;
    }

    $commands = ['tesseract', 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'];
    foreach ($commands as $command) {
        $probe = @shell_exec('"' . $command . '" --version 2>&1');
        if (!is_string($probe) || stripos($probe, 'tesseract') === false) {
            continue;
        }

        $output_base = tempnam(sys_get_temp_dir(), 'parish_ocr_');
        if ($output_base === false) {
            $result['error'] = 'Unable to create OCR temporary file.';
            return $result;
        }
        @unlink($output_base);

        $ocr_command = '"' . $command . '" "' . $image_path . '" "' . $output_base . '" --psm 6 2>&1';
        @shell_exec($ocr_command);
        $output_file = $output_base . '.txt';
        $text = is_file($output_file) ? trim((string) file_get_contents($output_file)) : '';
        @unlink($output_file);

        $result['available'] = true;
        $result['text'] = $text;
        return $result;
    }

    $result['error'] = 'OCR engine is not installed or not available to PHP.';
    return $result;
}

function extractValidIdData($ocr_text) {
    $text = trim((string) $ocr_text);
    $lines = array_values(array_filter(array_map('trim', preg_split('/\R+/', $text))));
    $data = [
        'full_name' => '',
        'birthdate' => '',
        'address' => '',
        'id_number' => ''
    ];

    if (preg_match('/(?:name|pangalan)\s*[:\-]?\s*([A-Z][A-Z\s\.,-]{4,})/i', $text, $matches)) {
        $data['full_name'] = trim($matches[1]);
    } elseif (!empty($lines)) {
        foreach ($lines as $line) {
            if (preg_match('/[A-Za-z]{2,}\s+[A-Za-z]{2,}/', $line) && !preg_match('/republic|address|birth|date|signature|license|identification/i', $line)) {
                $data['full_name'] = $line;
                break;
            }
        }
    }

    if (preg_match('/(?:birth(?:date)?|date of birth|dob|kapanganakan)\s*[:\-]?\s*([0-9]{1,2}[\/\-.][0-9]{1,2}[\/\-.][0-9]{2,4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})/i', $text, $matches)) {
        $timestamp = strtotime($matches[1]);
        $data['birthdate'] = $timestamp ? date('Y-m-d', $timestamp) : '';
    }

    if (preg_match('/(?:address|tirahan)\s*[:\-]?\s*(.{8,140})/i', $text, $matches)) {
        $data['address'] = trim($matches[1]);
    } else {
        foreach ($lines as $line) {
            if (preg_match('/\b(aleosan|cotabato|barangay|brgy\.?|purok|street|st\.)\b/i', $line)) {
                $data['address'] = $line;
                break;
            }
        }
    }

    if (preg_match('/(?:id(?:\s*no\.?|\s*number)?|card\s*no\.?|license\s*no\.?)\s*[:\-]?\s*([A-Z0-9\- ]{5,32})/i', $text, $matches)) {
        $data['id_number'] = trim($matches[1]);
    } elseif (preg_match('/\b([A-Z0-9]{2,5}[- ]?[A-Z0-9]{3,6}[- ]?[A-Z0-9]{3,8})\b/', $text, $matches)) {
        $data['id_number'] = trim($matches[1]);
    }

    return $data;
}

function compareIdentityData($submitted, $extracted) {
    $checks = [];
    $score = 0;

    $submitted_name = normalizeIdentityValue($submitted['fullname'] ?? '');
    $extracted_name = normalizeIdentityValue($extracted['full_name'] ?? '');
    similar_text($submitted_name, $extracted_name, $name_percent);
    $checks['name'] = $extracted_name !== '' && $name_percent >= 72;
    $score += $checks['name'] ? 35 : 0;

    $submitted_birthdate = (string) ($submitted['birthdate'] ?? '');
    $extracted_birthdate = (string) ($extracted['birthdate'] ?? '');
    $checks['birthdate'] = $submitted_birthdate !== '' && $submitted_birthdate === $extracted_birthdate;
    $score += $checks['birthdate'] ? 20 : 0;

    $submitted_address = normalizeIdentityValue($submitted['address'] ?? '');
    $extracted_address = normalizeIdentityValue($extracted['address'] ?? '');
    $checks['address'] = $extracted_address !== '' && (strpos($extracted_address, 'aleosan') !== false || levenshtein(substr($submitted_address, 0, 80), substr($extracted_address, 0, 80)) <= 35);
    $score += $checks['address'] ? 25 : 0;

    $submitted_id = normalizeIdentityValue($submitted['id_number'] ?? '');
    $extracted_id = normalizeIdentityValue($extracted['id_number'] ?? '');
    $checks['id_number'] = $submitted_id !== '' && $extracted_id !== '' && ($submitted_id === $extracted_id || strpos($extracted_id, $submitted_id) !== false || strpos($submitted_id, $extracted_id) !== false);
    $score += $checks['id_number'] ? 20 : 0;

    return [
        'score' => min(100, $score),
        'checks' => $checks,
        'status' => $score >= 70 ? 'matched' : ($score > 0 ? 'needs_review' : 'manual_review')
    ];
}

function getUserStatusLabel($status) {
    $labels = [
        'active' => 'Approved',
        'inactive' => 'Inactive',
        'pending_verification' => 'Pending Verification',
        'rejected' => 'Rejected',
        'archived' => 'Archived'
    ];
    return $labels[$status] ?? ucfirst(str_replace('_', ' ', (string) $status));
}

function getUserStatusBadgeClass($status) {
    $classes = [
        'active' => 'success',
        'inactive' => 'secondary',
        'pending_verification' => 'warning',
        'rejected' => 'danger',
        'archived' => 'secondary'
    ];
    return $classes[$status] ?? 'secondary';
}

function getOcrStatusLabel($status) {
    $labels = [
        'matched' => 'Matched',
        'needs_review' => 'Needs Review',
        'manual_review' => 'Manual Review',
        'unreadable' => 'Unreadable ID',
        'ocr_unavailable' => 'OCR Unavailable'
    ];
    return $labels[$status] ?? ucfirst(str_replace('_', ' ', (string) $status));
}

// Get notification count
function getUnreadNotificationCount($conn, $user_id) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    if (!$stmt) {
        return 0;
    }

    $user_id = intval($user_id);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : ['count' => 0];
    $stmt->close();
    return intval($row['count'] ?? 0);
}

function getRecentNotifications($conn, $user_id, $limit = 5) {
    $notifications = [];
    $stmt = $conn->prepare("SELECT notification_id, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    if (!$stmt) {
        return $notifications;
    }

    $user_id = intval($user_id);
    $limit = max(1, intval($limit));
    $stmt->bind_param('ii', $user_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($result && $row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
    return $notifications;
}

// Log audit trail for admin actions
function createAuditLog($conn, $user_id, $action, $table_name, $record_id, $old_value = null, $new_value = null) {
    $user_id = !empty($user_id) ? intval($user_id) : 'NULL';
    $action = $conn->real_escape_string($action);
    $table_name = $conn->real_escape_string($table_name);
    $old_value = $old_value ? $conn->real_escape_string(json_encode($old_value)) : 'NULL';
    $new_value = $new_value ? $conn->real_escape_string(json_encode($new_value)) : 'NULL';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $ip = $conn->real_escape_string($ip);
    
    $sql = "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value, ip_address)
            VALUES ($user_id, '$action', '$table_name', $record_id, '$old_value', '$new_value', '$ip')";
    return $conn->query($sql);
}

// Format date for display
function formatDate($date) {
    if (empty($date)) {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

function formatDateTime($date) {
    if (empty($date)) {
        return 'N/A';
    }
    return date('M d, Y g:i A', strtotime($date));
}

function formatTime($time) {
    if (empty($time)) {
        return '';
    }
    return date('g:i A', strtotime($time));
}

function scheduleEventColumnExists($conn, $column) {
    $column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM schedule_events LIKE '$column'");
    return $result && $result->num_rows > 0;
}

function ensureScheduleEventsTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS schedule_events (
        schedule_id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        event_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NULL,
        location VARCHAR(150),
        category VARCHAR(50) DEFAULT 'event',
        priority VARCHAR(20) DEFAULT 'normal',
        color_label VARCHAR(20) DEFAULT '#1a73e8',
        recurrence_rule VARCHAR(100) DEFAULT 'none',
        assigned_personnel VARCHAR(150),
        visibility ENUM('public', 'private') DEFAULT 'public',
        approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
        status ENUM('active', 'upcoming', 'ongoing', 'finished', 'cancelled') DEFAULT 'upcoming',
        reminder_minutes INT DEFAULT 30,
        notify_email TINYINT(1) DEFAULT 0,
        notify_sms TINYINT(1) DEFAULT 0,
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
        INDEX idx_schedule_date (event_date),
        INDEX idx_schedule_status_date (status, event_date, start_time)
    )";

    if (!$conn->query($sql)) {
        return false;
    }

    $columns = [
        'category' => "ALTER TABLE schedule_events ADD COLUMN category VARCHAR(50) DEFAULT 'event' AFTER location",
        'priority' => "ALTER TABLE schedule_events ADD COLUMN priority VARCHAR(20) DEFAULT 'normal' AFTER category",
        'color_label' => "ALTER TABLE schedule_events ADD COLUMN color_label VARCHAR(20) DEFAULT '#1a73e8' AFTER priority",
        'recurrence_rule' => "ALTER TABLE schedule_events ADD COLUMN recurrence_rule VARCHAR(100) DEFAULT 'none' AFTER color_label",
        'assigned_personnel' => "ALTER TABLE schedule_events ADD COLUMN assigned_personnel VARCHAR(150) AFTER recurrence_rule",
        'visibility' => "ALTER TABLE schedule_events ADD COLUMN visibility ENUM('public', 'private') DEFAULT 'public' AFTER assigned_personnel",
        'approval_status' => "ALTER TABLE schedule_events ADD COLUMN approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved' AFTER visibility",
        'reminder_minutes' => "ALTER TABLE schedule_events ADD COLUMN reminder_minutes INT DEFAULT 30 AFTER status",
        'notify_email' => "ALTER TABLE schedule_events ADD COLUMN notify_email TINYINT(1) DEFAULT 0 AFTER reminder_minutes",
        'notify_sms' => "ALTER TABLE schedule_events ADD COLUMN notify_sms TINYINT(1) DEFAULT 0 AFTER notify_email",
        'source_type' => "ALTER TABLE schedule_events ADD COLUMN source_type VARCHAR(40) DEFAULT 'manual' AFTER notify_sms",
        'source_id' => "ALTER TABLE schedule_events ADD COLUMN source_id INT NULL AFTER source_type"
    ];

    foreach ($columns as $column => $alterSql) {
        if (!scheduleEventColumnExists($conn, $column) && !$conn->query($alterSql)) {
            return false;
        }
    }

    $conn->query("ALTER TABLE schedule_events MODIFY COLUMN status ENUM('active', 'upcoming', 'ongoing', 'finished', 'cancelled') DEFAULT 'upcoming'");
    $conn->query("ALTER TABLE schedule_events ADD INDEX idx_schedule_source (source_type, source_id)");

    return true;
}

function syncApprovedReservationToCalendar($conn, $reservation_id, $admin_user_id) {
    if (!ensureScheduleEventsTable($conn)) {
        return ['success' => false, 'message' => 'Unable to prepare calendar table.'];
    }

    $reservation_id = intval($reservation_id);
    $stmt = $conn->prepare("
        SELECT r.*, u.fullname
        FROM reservations r
        JOIN users u ON r.user_id = u.id
        WHERE r.reservation_id = ?
        LIMIT 1
    ");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to load reservation.'];
    }

    $stmt->bind_param('i', $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$reservation || $reservation['status'] !== 'approved') {
        return ['success' => true, 'message' => 'Reservation is not approved; calendar sync skipped.'];
    }

    $type_label = ucfirst(str_replace('_', ' ', $reservation['reservation_type']));
    $title = $type_label . ' Reservation - ' . $reservation['fullname'];
    $description = trim((string) ($reservation['event_details'] ?? ''));
    if (!empty($reservation['admin_notes'])) {
        $description .= ($description !== '' ? "\n\n" : '') . 'Admin notes: ' . $reservation['admin_notes'];
    }

    $event_date = $reservation['event_date'];
    $start_time = substr((string) $reservation['event_time'], 0, 5);
    if ($start_time === '') {
        $start_time = '08:00';
    }
    $end_time = date('H:i', strtotime($start_time . ' +1 hour'));
    $location = 'Parish';
    $category = 'reservation';
    $priority = 'normal';
    $color_label = '#188038';
    $recurrence_rule = 'none';
    $assigned_personnel = '';
    $visibility = 'public';
    $approval_status = 'approved';
    $status = 'upcoming';
    $reminder_minutes = 30;
    $notify_email = 0;
    $notify_sms = 0;
    $source_type = 'reservation';
    $admin_user_id = intval($admin_user_id);

    $existing_id = 0;
    $stmt = $conn->prepare("SELECT schedule_id FROM schedule_events WHERE source_type = 'reservation' AND source_id = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('i', $reservation_id);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $existing_id = intval($existing['schedule_id'] ?? 0);
        $stmt->close();
    }

    $conflict = calendarSlotConflict($conn, $event_date, $start_time, $end_time, 'reservation', $reservation_id);
    if ($conflict['conflict']) {
        return ['success' => false, 'message' => $conflict['message'], 'conflict' => true];
    }

    if ($existing_id > 0) {
        $stmt = $conn->prepare("
            UPDATE schedule_events
            SET title = ?, description = ?, event_date = ?, start_time = ?, end_time = ?, location = ?,
                category = ?, priority = ?, color_label = ?, recurrence_rule = ?, assigned_personnel = ?,
                visibility = ?, approval_status = ?, status = ?, reminder_minutes = ?, notify_email = ?, notify_sms = ?
            WHERE schedule_id = ?
        ");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Unable to update calendar event.'];
        }
        $stmt->bind_param(
            'ssssssssssssssiiii',
            $title,
            $description,
            $event_date,
            $start_time,
            $end_time,
            $location,
            $category,
            $priority,
            $color_label,
            $recurrence_rule,
            $assigned_personnel,
            $visibility,
            $approval_status,
            $status,
            $reminder_minutes,
            $notify_email,
            $notify_sms,
            $existing_id
        );
        $ok = $stmt->execute();
        $stmt->close();
        if (!$ok) {
            return ['success' => false, 'message' => 'Unable to update calendar event.'];
        }
        createAuditLog($conn, $admin_user_id, 'SYNC_RESERVATION_CALENDAR', 'schedule_events', $existing_id);
        return ['success' => true, 'message' => 'Calendar event updated.', 'schedule_id' => $existing_id];
    }

    $stmt = $conn->prepare("
        INSERT INTO schedule_events
        (title, description, event_date, start_time, end_time, location, category, priority, color_label,
         recurrence_rule, assigned_personnel, visibility, approval_status, status, reminder_minutes,
         notify_email, notify_sms, source_type, source_id, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to create calendar event.'];
    }

    $stmt->bind_param(
        'ssssssssssssssiiisii',
        $title,
        $description,
        $event_date,
        $start_time,
        $end_time,
        $location,
        $category,
        $priority,
        $color_label,
        $recurrence_rule,
        $assigned_personnel,
        $visibility,
        $approval_status,
        $status,
        $reminder_minutes,
        $notify_email,
        $notify_sms,
        $source_type,
        $reservation_id,
        $admin_user_id
    );

    if (!$stmt->execute()) {
        $stmt->close();
        return ['success' => false, 'message' => 'Unable to create calendar event.'];
    }

    $schedule_id = $stmt->insert_id;
    $stmt->close();
    createAuditLog($conn, $admin_user_id, 'SYNC_RESERVATION_CALENDAR', 'schedule_events', $schedule_id);

    return ['success' => true, 'message' => 'Calendar event created.', 'schedule_id' => $schedule_id];
}

function requestCalendarField($description, $labels) {
    $description = (string) $description;
    foreach ((array) $labels as $label) {
        $pattern = '/^' . preg_quote($label, '/') . '\s*:\s*(.+)$/mi';
        if (preg_match($pattern, $description, $matches)) {
            $value = trim($matches[1]);
            return in_array(strtolower($value), ['not specified', 'none', 'n/a'], true) ? '' : $value;
        }
    }
    return '';
}

function validDateValue($date) {
    $dt = DateTime::createFromFormat('Y-m-d', (string) $date);
    return $dt && $dt->format('Y-m-d') === $date;
}

function normalizeRequestCalendarTime($time) {
    $time = trim((string) $time);
    if ($time === '') {
        return '08:00';
    }

    $dt = DateTime::createFromFormat('H:i', $time);
    if ($dt && $dt->format('H:i') === $time) {
        return $time;
    }

    $dt = DateTime::createFromFormat('H:i:s', $time);
    if ($dt) {
        return $dt->format('H:i');
    }

    $parsed = strtotime($time);
    return $parsed ? date('H:i', $parsed) : '08:00';
}

function calendarSlotConflict($conn, $event_date, $start_time, $end_time = null, $source_type = '', $source_id = 0) {
    if (!ensureScheduleEventsTable($conn)) {
        return ['conflict' => true, 'message' => 'Unable to check calendar availability.'];
    }

    $event_date = (string) $event_date;
    $start_time = normalizeRequestCalendarTime($start_time);
    $end_time = $end_time ? normalizeRequestCalendarTime($end_time) : date('H:i', strtotime($start_time . ' +1 hour'));
    $source_type = (string) $source_type;
    $source_id = intval($source_id);

    $stmt = $conn->prepare("
        SELECT title, start_time, end_time
        FROM schedule_events
        WHERE event_date = ?
        AND status != 'cancelled'
        AND NOT (source_type = ? AND source_id = ?)
        ORDER BY start_time ASC
    ");
    if ($stmt) {
        $stmt->bind_param('ssi', $event_date, $source_type, $source_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $existing_start = substr((string) $row['start_time'], 0, 5);
            $existing_end = !empty($row['end_time']) ? substr((string) $row['end_time'], 0, 5) : date('H:i', strtotime($existing_start . ' +1 hour'));
            if ($start_time < $existing_end && $end_time > $existing_start) {
                $stmt->close();
                return [
                    'conflict' => true,
                    'message' => 'Schedule conflict: "' . $row['title'] . '" is already set on ' . formatDate($event_date) . ' at ' . formatTime($existing_start) . '.'
                ];
            }
        }
        $stmt->close();
    }

    $stmt = $conn->prepare("
        SELECT reservation_id, reservation_type, event_time
        FROM reservations
        WHERE status = 'approved'
        AND event_date = ?
        AND NOT (? = 'reservation' AND reservation_id = ?)
        ORDER BY event_time ASC
    ");
    if ($stmt) {
        $stmt->bind_param('ssi', $event_date, $source_type, $source_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $existing_start = $row['event_time'] ? substr((string) $row['event_time'], 0, 5) : '08:00';
            $existing_end = date('H:i', strtotime($existing_start . ' +1 hour'));
            if ($start_time < $existing_end && $end_time > $existing_start) {
                $stmt->close();
                return [
                    'conflict' => true,
                    'message' => 'Schedule conflict: an approved ' . ucfirst(str_replace('_', ' ', $row['reservation_type'])) . ' reservation already uses ' . formatDate($event_date) . ' at ' . formatTime($existing_start) . '.'
                ];
            }
        }
        $stmt->close();
    }

    return ['conflict' => false, 'message' => 'Schedule is available.'];
}

function reservationApprovalConflict($conn, $reservation_id) {
    $reservation_id = intval($reservation_id);
    $stmt = $conn->prepare("SELECT event_date, event_time FROM reservations WHERE reservation_id = ? LIMIT 1");
    if (!$stmt) {
        return ['conflict' => true, 'message' => 'Unable to check reservation schedule.'];
    }
    $stmt->bind_param('i', $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$reservation || empty($reservation['event_date'])) {
        return ['conflict' => true, 'message' => 'Reservation has no valid event date.'];
    }

    $start_time = $reservation['event_time'] ? substr((string) $reservation['event_time'], 0, 5) : '08:00';
    return calendarSlotConflict($conn, $reservation['event_date'], $start_time, null, 'reservation', $reservation_id);
}

function requestApprovalConflict($conn, $request_id) {
    $calendar_request_types = [
        'house_blessing',
        'car_blessing',
        'vehicle_blessing',
        'business_blessing',
        'office_blessing',
        'event_blessing',
        'church_reservation',
        'wedding_reservation',
        'burial_reservation',
        'baptism_service',
        'marriage_wedding_service',
        'funeral_mass',
        'anointing_of_the_sick',
        'patronal_fiesta'
    ];
    $request_id = intval($request_id);
    $stmt = $conn->prepare("SELECT request_type, description FROM requests WHERE request_id = ? LIMIT 1");
    if (!$stmt) {
        return ['conflict' => true, 'message' => 'Unable to check request schedule.'];
    }
    $stmt->bind_param('i', $request_id);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$request || !in_array($request['request_type'], $calendar_request_types, true)) {
        return ['conflict' => false, 'message' => 'Request type does not require schedule checking.'];
    }

    $description = (string) ($request['description'] ?? '');
    $event_date = requestCalendarField($description, ['Date of Patronal Fiesta', 'Preferred date', 'Event date', 'Date']);
    if (!validDateValue($event_date)) {
        return ['conflict' => true, 'message' => 'This request has no valid preferred date, so it cannot be approved into the calendar.'];
    }

    $start_time = normalizeRequestCalendarTime(requestCalendarField($description, ['Preferred time', 'Event time', 'Time']));
    return calendarSlotConflict($conn, $event_date, $start_time, null, 'request', $request_id);
}

function syncApprovedRequestToCalendar($conn, $request_id, $admin_user_id) {
    if (!ensureScheduleEventsTable($conn)) {
        return ['success' => false, 'message' => 'Unable to prepare calendar table.'];
    }

    $calendar_request_types = [
        'house_blessing',
        'car_blessing',
        'vehicle_blessing',
        'business_blessing',
        'office_blessing',
        'event_blessing',
        'church_reservation',
        'wedding_reservation',
        'burial_reservation',
        'baptism_service',
        'marriage_wedding_service',
        'funeral_mass',
        'anointing_of_the_sick',
        'patronal_fiesta'
    ];

    $request_id = intval($request_id);
    $stmt = $conn->prepare("
        SELECT r.*, u.fullname
        FROM requests r
        JOIN users u ON r.user_id = u.id
        WHERE r.request_id = ?
        LIMIT 1
    ");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to load request.'];
    }

    $stmt->bind_param('i', $request_id);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$request || $request['status'] !== 'approved') {
        return ['success' => true, 'message' => 'Request is not approved; calendar sync skipped.'];
    }

    if (!in_array($request['request_type'], $calendar_request_types, true)) {
        return ['success' => true, 'message' => 'Request type does not require calendar sync.'];
    }

    $description = (string) ($request['description'] ?? '');
    $event_date = requestCalendarField($description, ['Date of Patronal Fiesta', 'Preferred date', 'Event date', 'Date']);
    if (!validDateValue($event_date)) {
        return ['success' => false, 'message' => 'Missing or invalid request date for calendar sync.'];
    }

    $start_time = normalizeRequestCalendarTime(requestCalendarField($description, ['Preferred time', 'Event time', 'Time']));
    $end_time = date('H:i', strtotime($start_time . ' +1 hour'));
    $location = requestCalendarField($description, ['Location', 'Address', 'Venue']);
    if ($location === '') {
        $location = 'Parish';
    }

    $type_label = ucfirst(str_replace('_', ' ', $request['request_type']));
    $title = $type_label . ' - ' . $request['fullname'];
    $blessing_request_types = ['house_blessing', 'car_blessing', 'vehicle_blessing', 'business_blessing', 'office_blessing', 'event_blessing'];
    $service_request_types = ['baptism_service', 'marriage_wedding_service', 'funeral_mass', 'anointing_of_the_sick', 'patronal_fiesta'];
    $category = in_array($request['request_type'], $blessing_request_types, true) ? 'blessing' : (in_array($request['request_type'], $service_request_types, true) ? 'sacramental' : 'reservation');
    $priority = 'normal';
    $color_label = $category === 'blessing' ? '#d7ad43' : ($category === 'sacramental' ? '#7c3aed' : '#188038');
    $recurrence_rule = 'none';
    $assigned_personnel = '';
    $visibility = 'public';
    $approval_status = 'approved';
    $status = 'upcoming';
    $reminder_minutes = 30;
    $notify_email = 0;
    $notify_sms = 0;
    $source_type = 'request';
    $admin_user_id = intval($admin_user_id);

    $existing_id = 0;
    $stmt = $conn->prepare("SELECT schedule_id FROM schedule_events WHERE source_type = 'request' AND source_id = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('i', $request_id);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $existing_id = intval($existing['schedule_id'] ?? 0);
        $stmt->close();
    }

    $conflict = calendarSlotConflict($conn, $event_date, $start_time, $end_time, 'request', $request_id);
    if ($conflict['conflict']) {
        return ['success' => false, 'message' => $conflict['message'], 'conflict' => true];
    }

    if ($existing_id > 0) {
        $stmt = $conn->prepare("
            UPDATE schedule_events
            SET title = ?, description = ?, event_date = ?, start_time = ?, end_time = ?, location = ?,
                category = ?, priority = ?, color_label = ?, recurrence_rule = ?, assigned_personnel = ?,
                visibility = ?, approval_status = ?, status = ?, reminder_minutes = ?, notify_email = ?, notify_sms = ?
            WHERE schedule_id = ?
        ");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Unable to update calendar event.'];
        }
        $stmt->bind_param(
            'ssssssssssssssiiii',
            $title,
            $description,
            $event_date,
            $start_time,
            $end_time,
            $location,
            $category,
            $priority,
            $color_label,
            $recurrence_rule,
            $assigned_personnel,
            $visibility,
            $approval_status,
            $status,
            $reminder_minutes,
            $notify_email,
            $notify_sms,
            $existing_id
        );
        $ok = $stmt->execute();
        $stmt->close();
        if (!$ok) {
            return ['success' => false, 'message' => 'Unable to update calendar event.'];
        }
        createAuditLog($conn, $admin_user_id, 'SYNC_REQUEST_CALENDAR', 'schedule_events', $existing_id);
        return ['success' => true, 'message' => 'Calendar event updated.', 'schedule_id' => $existing_id];
    }

    $stmt = $conn->prepare("
        INSERT INTO schedule_events
        (title, description, event_date, start_time, end_time, location, category, priority, color_label,
         recurrence_rule, assigned_personnel, visibility, approval_status, status, reminder_minutes,
         notify_email, notify_sms, source_type, source_id, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to create calendar event.'];
    }

    $stmt->bind_param(
        'ssssssssssssssiiisii',
        $title,
        $description,
        $event_date,
        $start_time,
        $end_time,
        $location,
        $category,
        $priority,
        $color_label,
        $recurrence_rule,
        $assigned_personnel,
        $visibility,
        $approval_status,
        $status,
        $reminder_minutes,
        $notify_email,
        $notify_sms,
        $source_type,
        $request_id,
        $admin_user_id
    );

    if (!$stmt->execute()) {
        $stmt->close();
        return ['success' => false, 'message' => 'Unable to create calendar event.'];
    }

    $schedule_id = $stmt->insert_id;
    $stmt->close();
    createAuditLog($conn, $admin_user_id, 'SYNC_REQUEST_CALENDAR', 'schedule_events', $schedule_id);

    return ['success' => true, 'message' => 'Calendar event created.', 'schedule_id' => $schedule_id];
}

function cancelLinkedRequestCalendarEvent($conn, $request_id) {
    if (!ensureScheduleEventsTable($conn)) {
        return false;
    }

    $request_id = intval($request_id);
    $stmt = $conn->prepare("UPDATE schedule_events SET status = 'cancelled' WHERE source_type = 'request' AND source_id = ?");
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('i', $request_id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function syncApprovedRequestCalendarBacklog($conn, $admin_user_id = 0, $limit = 50) {
    if (!ensureScheduleEventsTable($conn)) {
        return 0;
    }

    $limit = max(1, intval($limit));
    $sql = "
        SELECT r.request_id
        FROM requests r
        LEFT JOIN schedule_events se
            ON se.source_type = 'request'
            AND se.source_id = r.request_id
            AND se.status != 'cancelled'
        WHERE r.status = 'approved'
        AND r.request_type IN (
            'house_blessing',
            'car_blessing',
            'vehicle_blessing',
            'business_blessing',
            'office_blessing',
            'event_blessing',
            'church_reservation',
            'wedding_reservation',
            'burial_reservation',
            'baptism_service',
            'marriage_wedding_service',
            'funeral_mass',
            'anointing_of_the_sick',
            'patronal_fiesta'
        )
        AND se.schedule_id IS NULL
        ORDER BY r.updated_at DESC
        LIMIT $limit
    ";

    $synced = 0;
    $result = $conn->query($sql);
    while ($result && $row = $result->fetch_assoc()) {
        $sync = syncApprovedRequestToCalendar($conn, intval($row['request_id']), intval($admin_user_id));
        if ($sync['success'] && in_array($sync['message'], ['Calendar event created.', 'Calendar event updated.'], true)) {
            $synced++;
        }
    }

    return $synced;
}

// Get user by ID
function getUserById($conn, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM users WHERE id = $id";
    $result = $conn->query($sql);
    return $result ? $result->fetch_assoc() : null;
}

// Get request status badge color
function getStatusBadgeClass($status) {
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'processing' => 'info',
        'completed' => 'success',
        'cancelled' => 'secondary',
        'active' => 'success',
        'inactive' => 'secondary',
        'archived' => 'secondary'
    ];
    return $colors[$status] ?? 'secondary';
}

// Pagination helper
function getPaginationData($page, $limit, $total) {
    $page = max(1, intval($page));
    $limit = max(1, intval($limit));
    $offset = ($page - 1) * $limit;
    $total = intval($total);
    $total_pages = ceil($total / $limit);
    
    return [
        'page' => $page,
        'limit' => $limit,
        'offset' => $offset,
        'total' => $total,
        'total_pages' => $total_pages
    ];
}

// Redirect function
function redirect($location) {
    header("Location: $location");
    exit;
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check user role - admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Check user role - regular user
function isUser() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
}

// Require login - redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('../auth/login.php');
    }
}

// Require admin access
function requireAdmin() {
    if (!isLoggedIn() || !isAdmin()) {
        redirect('../auth/login.php');
    }
}

// Get current user full name
function getCurrentUserFullName() {
    return isset($_SESSION['fullname']) ? htmlspecialchars($_SESSION['fullname']) : 'User';
}

// Get current user ID
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
}

?>
