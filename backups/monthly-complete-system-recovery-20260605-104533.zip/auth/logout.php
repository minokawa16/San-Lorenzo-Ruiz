<?php
/**
 * LOGOUT - Destroy session and redirect to login
 * Simple, direct logout with no complications
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Completely unset all session variables
foreach ($_SESSION as $key => $value) {
    unset($_SESSION[$key]);
}

// Clear the entire session array
$_SESSION = array();

// Destroy the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Completely destroy session
session_destroy();

// Clear any cached headers
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");

// Redirect to login page
header("Location: login.php", true, 302);
exit();
?>

