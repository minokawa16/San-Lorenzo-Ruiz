<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../database/config.php';
include '../includes/helpers.php';

ensureEmailNotificationSchema($conn);

$purpose = $_GET['purpose'] ?? ($_POST['purpose'] ?? 'registration');
$allowed_purposes = ['registration', 'login'];
if (!in_array($purpose, $allowed_purposes, true)) {
    $purpose = 'registration';
}

$user_id = intval($_GET['user_id'] ?? ($_POST['user_id'] ?? ($_SESSION['pending_otp_user_id'] ?? 0)));
$email = trim($_GET['email'] ?? ($_POST['email'] ?? ($_SESSION['pending_otp_email'] ?? '')));
$error = '';
$success = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = $_POST['action'] ?? 'verify';

    if ($action === 'resend') {
        $sent = sendOtpEmail($conn, $user_id, $email, $purpose);
        $success = $sent['ok'] ? 'A new OTP was sent to your Gmail address.' : ($sent['error'] ?: 'Unable to send OTP.');
    } else {
        $otp = preg_replace('/\D/', '', $_POST['otp'] ?? '');
        if (strlen($otp) !== 6) {
            $error = 'Please enter the 6-digit OTP.';
        } else {
            $verified = verifyOtpCode($conn, $user_id, $email, $purpose, $otp);
            if ($verified['ok']) {
                if ($purpose === 'registration') {
                    $conn->query("UPDATE users SET email_verified_at = NOW() WHERE id = " . intval($user_id));
                    createAuditLog($conn, $user_id, 'VERIFY_REGISTRATION_OTP', 'users', $user_id);
                    $success = 'OTP verified. Your registration is now ready for parish administrator review.';
                } else {
                    $stmt = $conn->prepare("SELECT id, fullname, email, role FROM users WHERE id = ? AND email = ? LIMIT 1");
                    if ($stmt) {
                        $stmt->bind_param('is', $user_id, $email);
                        $stmt->execute();
                        $user = $stmt->get_result()->fetch_assoc();
                        $stmt->close();
                        if ($user) {
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['fullname'] = $user['fullname'];
                            $_SESSION['email'] = $user['email'];
                            $_SESSION['role'] = $user['role'];
                            unset($_SESSION['pending_otp_user_id'], $_SESSION['pending_otp_email']);
                            createAuditLog($conn, $user_id, 'VERIFY_LOGIN_OTP', 'users', $user_id);
                            header("Location: " . ($user['role'] === 'admin' ? '../admin/dashboard.php' : '../users/dashboard.php'));
                            exit;
                        }
                    }
                    $error = 'Unable to complete login OTP verification.';
                }
            } else {
                $error = $verified['error'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification | TUGON</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-parish.css">
</head>
<body class="auth-cinematic-page">
    <main class="auth-screen" style="min-height:100vh;display:grid;place-items:center;padding:24px;">
        <section class="auth-glass-card" style="max-width:560px;width:100%;">
            <div class="auth-card-header">
                <span class="auth-eyebrow"><i class="fas fa-key"></i> One-Time Password</span>
                <h2>Verify Your Gmail</h2>
                <p>Enter the 6-digit code sent to <?php echo e($email); ?>. Codes expire after 5 minutes.</p>
            </div>

            <?php if ($error): ?><div class="alert alert-danger"><?php echo e($error); ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><?php echo e($success); ?></div><?php endif; ?>

            <form method="POST" class="auth-form">
                <input type="hidden" name="user_id" value="<?php echo intval($user_id); ?>">
                <input type="hidden" name="email" value="<?php echo e($email); ?>">
                <input type="hidden" name="purpose" value="<?php echo e($purpose); ?>">
                <input type="hidden" name="action" value="verify">
                <div class="auth-field">
                    <label class="form-label" for="otp">OTP Code</label>
                    <div class="auth-input-wrap">
                        <i class="fas fa-shield-halved"></i>
                        <input type="text" class="form-control" id="otp" name="otp" inputmode="numeric" pattern="\d{6}" maxlength="6" placeholder="000000" required autofocus>
                    </div>
                </div>
                <button type="submit" class="auth-submit"><i class="fas fa-circle-check"></i> Verify OTP</button>
            </form>

            <form method="POST" class="mt-3">
                <input type="hidden" name="user_id" value="<?php echo intval($user_id); ?>">
                <input type="hidden" name="email" value="<?php echo e($email); ?>">
                <input type="hidden" name="purpose" value="<?php echo e($purpose); ?>">
                <input type="hidden" name="action" value="resend">
                <button type="submit" class="auth-social-btn w-100"><i class="fas fa-rotate"></i> Resend OTP</button>
            </form>
        </section>
    </main>
</body>
</html>
