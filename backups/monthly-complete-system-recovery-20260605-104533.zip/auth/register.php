<?php
/**
 * User Registration Page
 * AI-Powered Parish Request and Sacramental Records Management System
 * Handles user registration with proper password hashing and validation
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../database/config.php';
include '../includes/helpers.php';

ensureUserVerificationSchema($conn);
ensureEmailNotificationSchema($conn);

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header("Location: ../admin/dashboard.php", true, 302);
    } else {
        header("Location: ../users/dashboard.php", true, 302);
    }
    exit();
}

$error = '';
$success = '';
$form_data = [
    'first_name' => '',
    'surname' => '',
    'middle_initial' => '',
    'phone_number' => '',
    'email' => '',
    'chapel_district' => '',
    'address' => '',
    'birthdate' => '',
    'id_number' => ''
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = isset($_POST['first_name']) ? sanitize($_POST['first_name']) : '';
    $surname = isset($_POST['surname']) ? sanitize($_POST['surname']) : '';
    $middle_initial = isset($_POST['middle_initial']) ? strtoupper(substr(preg_replace('/[^A-Za-z]/', '', sanitize($_POST['middle_initial'])), 0, 1)) : '';
    $fullname = trim($first_name . ' ' . ($middle_initial !== '' ? $middle_initial . '. ' : '') . $surname);
    $phone_number = isset($_POST['phone_number']) ? sanitize($_POST['phone_number']) : '';
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : '';
    $chapel_district = isset($_POST['chapel_district']) ? sanitize($_POST['chapel_district']) : '';
    $address = isset($_POST['address']) ? sanitize($_POST['address']) : '';
    $birthdate = isset($_POST['birthdate']) ? sanitize($_POST['birthdate']) : '';
    $id_number = isset($_POST['id_number']) ? sanitize($_POST['id_number']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $form_data = [
        'first_name' => $first_name,
        'surname' => $surname,
        'middle_initial' => $middle_initial,
        'phone_number' => $phone_number,
        'email' => $email,
        'chapel_district' => $chapel_district,
        'address' => $address,
        'birthdate' => $birthdate,
        'id_number' => $id_number
    ];

    if (empty($first_name) || empty($surname) || empty($phone_number) || empty($email) || empty($chapel_district) || empty($address) || empty($birthdate) || empty($id_number) || empty($password) || empty($confirm_password)) {
        $error = 'Please complete all required fields.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please enter a valid email address.';
    } elseif (!preg_match('/@gmail\.com$/i', $email)) {
        $error = 'Please use a Gmail address ending in @gmail.com.';
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthdate) || strtotime($birthdate) === false || strtotime($birthdate) > strtotime('-13 years')) {
        $error = 'Please enter a valid birthdate. Registrants must be at least 13 years old.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (empty($_POST['face_capture']) || empty($_POST['valid_id_capture'])) {
        $error = 'Live camera identity verification must be completed before registration.';
    } else {
        $email_safe = $conn->real_escape_string($email);
        $id_number_hash = hashIdentityNumber($id_number);
        $id_number_hash_safe = $conn->real_escape_string($id_number_hash);
        $sql = "SELECT id FROM users WHERE email = '$email_safe' OR id_number_hash = '$id_number_hash_safe' LIMIT 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $error = 'This Gmail address or ID number is already registered.';
        } else {
            $face_capture = decodeCameraCapture($_POST['face_capture']);
            $id_capture = decodeCameraCapture($_POST['valid_id_capture']);

            if (!$face_capture['ok']) {
                $error = $face_capture['error'];
            } elseif (!$id_capture['ok']) {
                $error = $id_capture['error'];
            } else {
                $id_upload_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'valid_ids';
                $face_upload_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'live_faces';
                $ocr_tmp = tempnam(sys_get_temp_dir(), 'tugon_id_');
                file_put_contents($ocr_tmp, $id_capture['binary']);

                $ocr_result = runValidIdOcr($ocr_tmp);
                $extracted_data = extractValidIdData($ocr_result['text']);
                $identity_match = compareIdentityData([
                    'fullname' => $fullname,
                    'birthdate' => $birthdate,
                    'address' => $address,
                    'id_number' => $id_number
                ], $extracted_data);

                if ($ocr_result['available'] && trim($ocr_result['text']) === '') {
                    $identity_match['status'] = 'unreadable';
                } elseif (!$ocr_result['available']) {
                    $identity_match['status'] = 'ocr_unavailable';
                }

                $id_saved = saveEncryptedCameraCapture($id_capture, $id_upload_dir, 'live-valid-id');
                $face_saved = saveEncryptedCameraCapture($face_capture, $face_upload_dir, 'live-face');
                @unlink($ocr_tmp);

                if (!$id_saved || !$face_saved) {
                    if ($id_saved && is_file($id_saved['path'])) {
                        unlink($id_saved['path']);
                    }
                    if ($face_saved && is_file($face_saved['path'])) {
                        unlink($face_saved['path']);
                    }
                    $error = 'Unable to save the live verification captures. Please try again.';
                } else {
                    $db_path = 'uploads/valid_ids/' . $id_saved['filename'];
                    $face_db_path = 'uploads/live_faces/' . $face_saved['filename'];
                    $mime_type = $id_capture['mime_type'];
                    $face_mime_type = $face_capture['mime_type'];
                    $original_name = 'live-camera-id.' . $id_capture['extension'];
                    $hashed_password = hashPassword($password);
                    $id_number_encrypted = encryptSensitiveValue($id_number);
                    $ocr_text_encrypted = encryptSensitiveValue($ocr_result['text']);
                    $ocr_data_encrypted = encryptSensitiveValue(json_encode([
                        'extracted' => $extracted_data,
                        'checks' => $identity_match['checks'],
                        'ocr_error' => $ocr_result['error']
                    ]));
                    $ocr_score = intval($identity_match['score']);
                    $ocr_status = $identity_match['status'];
                    $face_status = 'live_camera_verified';

                    $stmt = $conn->prepare("INSERT INTO users (fullname, first_name, surname, middle_initial, phone_number, email, chapel_district, address, birthdate, id_number_hash, id_number_encrypted, password, role, status, valid_id_path, valid_id_original_name, valid_id_mime_type, valid_id_capture_method, face_image_path, face_image_mime_type, face_verification_status, face_verified_at, ocr_extracted_text_encrypted, ocr_extracted_data_encrypted, ocr_match_score, ocr_status, ocr_processed_at)
                                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 'pending_verification', ?, ?, ?, 'live_camera', ?, ?, ?, NOW(), ?, ?, ?, ?, NOW())");

                    if ($stmt) {
                        $stmt->bind_param(
                            'ssssssssssssssssssssis',
                            $fullname,
                            $first_name,
                            $surname,
                            $middle_initial,
                            $phone_number,
                            $email,
                            $chapel_district,
                            $address,
                            $birthdate,
                            $id_number_hash,
                            $id_number_encrypted,
                            $hashed_password,
                            $db_path,
                            $original_name,
                            $mime_type,
                            $face_db_path,
                            $face_mime_type,
                            $face_status,
                            $ocr_text_encrypted,
                            $ocr_data_encrypted,
                            $ocr_score,
                            $ocr_status
                        );
                    }

                    if ($stmt && $stmt->execute()) {
                        $success = $ocr_status === 'matched'
                            ? 'Your ID details were scanned successfully. Your registration is now under parish administrator review.'
                            : 'Your registration is under review. The ID scan needs administrator verification before approval.';
                        $form_data = [
                            'first_name' => '',
                            'surname' => '',
                            'middle_initial' => '',
                            'phone_number' => '',
                            'email' => '',
                            'chapel_district' => '',
                            'address' => '',
                            'birthdate' => '',
                            'id_number' => ''
                        ];

                        $new_user_id = $conn->insert_id;
                        sendEmailVerificationMessage($conn, $new_user_id, $email, $fullname);
                        sendOtpEmail($conn, $new_user_id, $email, 'registration');
                        createAuditLog($conn, $new_user_id, 'REGISTRATION_OCR_PENDING_VERIFICATION', 'users', $new_user_id, null, [
                            'ocr_status' => $ocr_status,
                            'ocr_match_score' => $ocr_score
                        ]);
                        header('Location: verify-otp.php?purpose=registration&user_id=' . urlencode($new_user_id) . '&email=' . urlencode($email));
                        exit;
                    } else {
                        if (is_file($id_saved['path'])) {
                            unlink($id_saved['path']);
                        }
                        if (is_file($face_saved['path'])) {
                            unlink($face_saved['path']);
                        }
                        $error = 'Registration failed. Please try again later.';
                    }
                    if ($stmt) {
                        $stmt->close();
                    }
                }
            }
        }
    }
}

$chapel_options = [
    'District 1',
    'District 2',
    'District 3'
];

$logo_file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'san-lorenzo-logo.png';
$has_logo = is_file($logo_file);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Register | San Lorenzo Ruiz Mission Station</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/premium-parish.css">
    <style>
        :root {
            --register-navy: #0b1f3a;
            --register-navy-soft: #14365d;
            --register-gold: #d4af37;
            --register-gold-soft: #f4dc82;
            --register-gray: #eef3f7;
            --register-muted: #5d6d7f;
            --register-danger: #b42318;
            --register-success: #0f7a4f;
        }

        body.register-page {
            min-height: 100vh;
            margin: 0;
            color: #fff8eb;
            background: #14100d;
            overflow-x: hidden;
        }

        body.register-page::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -3;
            background-image:
                linear-gradient(135deg, rgba(0, 0, 0, 0.18), rgba(11, 31, 58, 0.12)),
                url("../church%20image.png");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            filter: sepia(0.22) saturate(1.34) contrast(1.08) brightness(0.88);
            transform: none;
        }

        body.register-page::after {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            background:
                radial-gradient(circle at 39% 30%, rgba(255, 214, 126, 0.26), transparent 25%),
                radial-gradient(circle at 50% 70%, rgba(255, 184, 64, 0.18), transparent 24%),
                linear-gradient(90deg, rgba(15, 10, 6, 0.62) 0%, rgba(15, 10, 6, 0.24) 44%, rgba(8, 11, 18, 0.78) 100%),
                linear-gradient(180deg, rgba(0, 0, 0, 0.22), rgba(0, 0, 0, 0.62));
        }

        .register-shell {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            width: min(1180px, calc(100% - 32px));
            margin: 0 auto;
            padding: clamp(18px, 4vw, 42px) 0;
            overflow: hidden;
        }

        .register-shell::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: 0;
            background-image:
                radial-gradient(circle, rgba(255, 255, 255, 0.2) 1px, transparent 1.8px),
                radial-gradient(circle, rgba(212, 175, 55, 0.18) 1px, transparent 2px);
            background-position: 0 0, 38px 52px;
            background-size: 92px 92px, 126px 126px;
            opacity: 0.45;
            animation: particleDrift 18s linear infinite;
            pointer-events: none;
        }

        .register-shell::after {
            content: "\f684  \f654  \f2cd";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            position: absolute;
            inset: auto 4vw 4vh auto;
            z-index: 0;
            color: rgba(255, 255, 255, 0.08);
            font-size: clamp(2.4rem, 8vw, 6rem);
            letter-spacing: 24px;
            pointer-events: none;
        }

        .register-card {
            position: relative;
            z-index: 1;
            width: min(100%, 760px);
            max-height: calc(100vh - 42px);
            overflow-y: auto;
            background:
                linear-gradient(155deg, rgba(255, 248, 235, 0.22), rgba(255, 248, 235, 0.08)),
                rgba(20, 16, 13, 0.72);
            border: 1px solid rgba(255, 248, 235, 0.26);
            border-radius: 8px;
            box-shadow:
                0 34px 90px rgba(0, 0, 0, 0.5),
                0 0 56px rgba(216, 165, 58, 0.18),
                inset 0 1px 0 rgba(255, 255, 255, 0.16);
            padding: clamp(24px, 3vw, 34px);
            backdrop-filter: blur(28px) saturate(145%);
            -webkit-backdrop-filter: blur(28px) saturate(145%);
            animation: fadeUp 0.78s cubic-bezier(0.2, 0.8, 0.2, 1) both;
        }

        .register-card::before {
            content: "";
            position: absolute;
            inset: 12px;
            z-index: -1;
            border-radius: 8px;
            background:
                radial-gradient(circle at top left, rgba(246, 217, 139, 0.14), transparent 32%),
                linear-gradient(135deg, rgba(255, 248, 235, 0.08), transparent);
        }

        .register-card-header {
            text-align: center;
            margin-bottom: 22px;
        }

        .register-card-icon {
            width: 82px;
            height: 82px;
            margin: 0 auto 14px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--register-gold-soft), var(--register-gold));
            color: var(--register-navy);
            font-size: 2rem;
            box-shadow: 0 18px 40px rgba(212, 175, 55, 0.28);
            text-decoration: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .register-card-icon:hover {
            color: #0b1f3a;
            transform: translateY(-2px);
            box-shadow: 0 22px 46px rgba(212, 175, 55, 0.36);
        }

        .register-card h2 {
            margin: 0;
            font-weight: 850;
            color: #fff8eb;
            letter-spacing: 0;
            font-size: clamp(1.9rem, 4vw, 2.45rem);
        }

        .register-card-header p {
            color: rgba(255, 248, 235, 0.78);
            margin: 8px 0 0;
            line-height: 1.55;
        }

        .community-quote {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0 0 20px;
            padding: 12px 14px;
            border-radius: 18px;
            color: rgba(255, 248, 235, 0.86);
            background: rgba(255, 248, 235, 0.1);
            border: 1px solid rgba(246, 217, 139, 0.2);
            font-size: 0.9rem;
            line-height: 1.45;
        }

        .community-quote i {
            color: var(--register-gold);
        }

        .registration-form {
            display: grid;
            gap: 14px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .field-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .field-group.full {
            grid-column: 1 / -1;
        }

        .field-label {
            color: #fff8eb;
            font-weight: 800;
            font-size: 0.9rem;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap .field-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(246, 217, 139, 0.82);
            pointer-events: none;
            width: 18px;
            text-align: center;
        }

        .register-card .form-control,
        .register-card .form-select {
            width: 100%;
            min-height: 50px;
            border-radius: 8px;
            border: 1px solid rgba(255, 248, 235, 0.24);
            padding: 12px 16px 12px 46px;
            background: rgba(255, 248, 235, 0.13);
            color: #fff8eb;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease, background 0.2s ease;
        }

        .register-card .form-select {
            padding-right: 42px;
        }

        .register-card #chapel_district {
            background-color: #ffffff;
            color: #000000 !important;
            -webkit-text-fill-color: #000000;
        }

        .register-card .form-select option {
            background: #ffffff !important;
            color: #000000 !important;
            -webkit-text-fill-color: #000000;
        }

        .register-card .form-select option:checked {
            background: #d4af37;
            color: #000000 !important;
            font-weight: 700;
        }

        .register-card .form-control:focus,
        .register-card .form-select:focus {
            border-color: var(--register-gold);
            background: rgba(255, 248, 235, 0.16);
            color: #fff8eb;
            box-shadow:
                0 0 0 4px rgba(212, 175, 55, 0.2),
                0 12px 26px rgba(11, 31, 58, 0.12);
            transform: translateY(-1px);
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 8px;
            background: transparent;
            color: rgba(255, 248, 235, 0.68);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease, color 0.2s ease;
        }

        .password-toggle:hover {
            background: rgba(255, 248, 235, 0.12);
            color: #f6d98b;
        }

        .input-wrap.password .form-control {
            padding-right: 54px;
        }

        .field-message {
            min-height: 18px;
            color: var(--register-danger);
            font-size: 0.82rem;
            font-weight: 700;
        }

        .form-hint {
            color: rgba(255, 248, 235, 0.62);
            font-size: 0.82rem;
            margin-top: -2px;
        }

        .verification-notice {
            display: flex;
            gap: 10px;
            padding: 12px 14px;
            border-radius: 18px;
            color: rgba(255, 248, 235, 0.86);
            background: rgba(255, 248, 235, 0.1);
            border: 1px solid rgba(246, 217, 139, 0.2);
            font-size: 0.88rem;
            line-height: 1.45;
        }

        .verification-notice i {
            color: var(--register-gold);
            margin-top: 2px;
        }

        .id-upload-box {
            position: relative;
            display: grid;
            place-items: center;
            min-height: 170px;
            padding: 18px;
            border: 2px dashed rgba(11, 31, 58, 0.28);
            border-radius: 8px;
            background: rgba(255, 248, 235, 0.1);
            cursor: pointer;
            text-align: center;
            transition: border-color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            overflow: hidden;
        }

        .id-upload-box:hover,
        .id-upload-box.is-dragover {
            border-color: var(--register-gold);
            background: rgba(255, 248, 235, 0.16);
            transform: translateY(-1px);
            box-shadow: 0 14px 30px rgba(11, 31, 58, 0.12);
        }

        .id-upload-box input {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
        }

        .id-upload-content {
            display: grid;
            justify-items: center;
            gap: 8px;
            color: rgba(255, 248, 235, 0.72);
        }

        .id-upload-content i {
            width: 48px;
            height: 48px;
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #14100d;
            background: linear-gradient(135deg, var(--register-gold-soft), var(--register-gold));
            font-size: 1.25rem;
        }

        .id-upload-content strong {
            color: #fff8eb;
        }

        .id-preview {
            display: none;
            width: 100%;
            gap: 12px;
            align-items: center;
            text-align: left;
        }

        .id-preview img {
            width: 92px;
            height: 72px;
            object-fit: cover;
            border-radius: 14px;
            border: 1px solid rgba(11, 31, 58, 0.12);
        }

        .id-upload-box.has-preview .id-upload-content {
            display: none;
        }

        .id-upload-box.has-preview .id-preview {
            display: flex;
        }

        .live-verification {
            display: grid;
            gap: 12px;
            padding: 14px;
            border-radius: 8px;
            border: 1px solid rgba(255, 248, 235, 0.22);
            background: rgba(255, 248, 235, 0.1);
        }

        .camera-stage {
            position: relative;
            aspect-ratio: 16 / 9;
            min-height: 240px;
            overflow: hidden;
            border-radius: 8px;
            background: #111827;
            border: 1px solid rgba(255, 248, 235, 0.2);
        }

        .camera-stage video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
        }

        .camera-stage.is-active video {
            display: block;
        }

        .camera-placeholder {
            position: absolute;
            inset: 0;
            display: grid;
            place-items: center;
            align-content: center;
            gap: 8px;
            padding: 20px;
            color: rgba(255, 248, 235, 0.8);
            text-align: center;
            background: linear-gradient(135deg, rgba(20, 16, 13, 0.88), rgba(11, 31, 58, 0.8));
        }

        .camera-placeholder i {
            color: var(--register-gold);
            font-size: 2rem;
        }

        .camera-stage.is-active .camera-placeholder {
            display: none;
        }

        .face-guide {
            position: absolute;
            left: 50%;
            top: 50%;
            width: min(42%, 220px);
            aspect-ratio: 0.76;
            transform: translate(-50%, -50%);
            border: 3px solid rgba(246, 217, 139, 0.92);
            border-radius: 50%;
            box-shadow: 0 0 0 999px rgba(0, 0, 0, 0.24);
            display: none;
            pointer-events: none;
        }

        .camera-stage.is-face-mode .face-guide {
            display: block;
        }

        .verification-steps,
        .camera-actions,
        .capture-previews {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px;
        }

        .verification-step {
            display: flex;
            align-items: center;
            gap: 8px;
            min-height: 42px;
            padding: 10px;
            border-radius: 8px;
            color: rgba(255, 248, 235, 0.7);
            background: rgba(255, 248, 235, 0.08);
            border: 1px solid rgba(255, 248, 235, 0.16);
            font-weight: 800;
        }

        .verification-step.is-current {
            color: #14100d;
            background: linear-gradient(135deg, var(--register-gold-soft), var(--register-gold));
        }

        .verification-step.is-done {
            color: #dcfce7;
            border-color: rgba(74, 222, 128, 0.42);
            background: rgba(22, 101, 52, 0.42);
        }

        .camera-btn {
            min-height: 44px;
            border: 0;
            border-radius: 8px;
            color: #14100d;
            background: linear-gradient(135deg, var(--register-gold-soft), var(--register-gold));
            font-weight: 900;
        }

        .camera-btn.secondary {
            color: #fff8eb;
            background: rgba(255, 248, 235, 0.14);
            border: 1px solid rgba(255, 248, 235, 0.2);
        }

        .camera-btn:disabled {
            opacity: 0.48;
            cursor: not-allowed;
        }

        .camera-status {
            margin: 0;
            color: rgba(255, 248, 235, 0.78);
            font-size: 0.86rem;
            font-weight: 700;
        }

        .capture-preview {
            min-height: 112px;
            padding: 9px;
            border-radius: 8px;
            background: rgba(255, 248, 235, 0.08);
            border: 1px solid rgba(255, 248, 235, 0.16);
        }

        .capture-preview span {
            display: block;
            margin-bottom: 7px;
            color: rgba(255, 248, 235, 0.72);
            font-size: 0.78rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .capture-preview img {
            width: 100%;
            height: 82px;
            object-fit: cover;
            border-radius: 8px;
            background: rgba(255, 248, 235, 0.1);
            display: block;
        }

        .is-invalid-field {
            border-color: #f04438 !important;
            box-shadow: 0 0 0 4px rgba(240, 68, 56, 0.12) !important;
        }

        .auth-alert {
            border: none;
            border-radius: 8px;
            box-shadow: none;
            font-weight: 700;
        }

        .auth-alert.alert-danger {
            color: var(--register-danger);
            background: #fff1f0;
        }

        .auth-alert.alert-success {
            color: var(--register-success);
            background: #ecfdf3;
        }

        .submit-btn {
            min-height: 54px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #fff8eb, #f6d98b 45%, #d8a53a);
            color: #14100d;
            font-weight: 850;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow:
                0 18px 42px rgba(216, 165, 58, 0.32);
            transition: transform 0.22s ease, box-shadow 0.22s ease, opacity 0.22s ease, filter 0.22s ease;
        }

        .submit-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            filter: brightness(1.04);
            box-shadow:
                0 24px 54px rgba(216, 165, 58, 0.36);
        }

        .submit-btn:disabled {
            cursor: not-allowed;
            opacity: 0.78;
        }

        .spinner {
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255, 255, 255, 0.45);
            border-top-color: #ffffff;
            border-radius: 50%;
            animation: spin 0.75s linear infinite;
            display: none;
        }

        .submit-btn.is-loading .spinner {
            display: inline-block;
        }

        .submit-btn.is-loading .submit-icon {
            display: none;
        }

        .login-link {
            text-align: center;
            color: rgba(255, 248, 235, 0.78);
            margin: 18px 0 0;
        }

        .login-link a {
            color: #f6d98b;
            font-weight: 850;
            text-decoration: none;
        }

        .login-link a:hover {
            color: #fff8eb;
            text-decoration: underline;
        }

        .register-social-divider {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0 12px;
            color: rgba(255, 248, 235, 0.62);
            font-size: 0.82rem;
            font-weight: 800;
        }

        .register-social-divider::before,
        .register-social-divider::after {
            content: "";
            height: 1px;
            flex: 1;
            background: rgba(255, 248, 235, 0.18);
        }

        .register-socials {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px;
        }

        .register-social-btn {
            min-height: 42px;
            border-radius: 8px;
            border: 1px solid rgba(255, 248, 235, 0.2);
            color: #fff8eb;
            background: rgba(255, 248, 235, 0.09);
            font-weight: 850;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease;
        }

        .register-social-btn:hover,
        .register-social-btn:focus-visible {
            transform: translateY(-2px);
            border-color: rgba(246, 217, 139, 0.48);
            background: rgba(255, 248, 235, 0.16);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.18);
        }

        .toast-stack {
            position: fixed;
            z-index: 20;
            top: 20px;
            right: 20px;
            display: grid;
            gap: 12px;
            width: min(360px, calc(100vw - 28px));
        }

        .auth-toast {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 14px 16px;
            border-radius: 18px;
            color: #ffffff;
            background: rgba(11, 31, 58, 0.86);
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(18px);
            animation: toastIn 0.35s ease both;
        }

        .auth-toast.success i {
            color: #87efac;
        }

        .auth-toast.error i {
            color: #fecaca;
        }

        .auth-toast strong {
            display: block;
            line-height: 1.2;
        }

        .auth-toast span {
            display: block;
            color: rgba(255, 255, 255, 0.78);
            font-size: 0.88rem;
            margin-top: 2px;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(22px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes toastIn {
            from {
                opacity: 0;
                transform: translateX(14px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes particleDrift {
            from {
                background-position: 0 0, 38px 52px;
            }
            to {
                background-position: 92px 92px, 164px 178px;
            }
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
            }
        }

        @media (max-width: 640px) {
            .register-shell {
                align-items: flex-start;
                justify-content: center;
                width: min(100% - 20px, 760px);
                padding: 16px 10px;
            }

            .register-card {
                max-height: none;
                border-radius: 24px;
                padding: 22px 16px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .register-socials {
                grid-template-columns: 1fr;
            }

            .verification-steps,
            .camera-actions,
            .capture-previews {
                grid-template-columns: 1fr;
            }

            .camera-stage {
                min-height: 210px;
            }

            .toast-stack {
                top: 12px;
                right: 14px;
                left: 14px;
                width: auto;
            }
        }
    </style>
</head>
<body class="register-page">
    <div class="toast-stack" id="toastStack" aria-live="polite" aria-atomic="true">
        <?php if ($error): ?>
            <div class="auth-toast error" role="alert">
                <i class="fas fa-circle-exclamation"></i>
                <div>
                    <strong>Registration needs attention</strong>
                    <span><?php echo e($error); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="auth-toast success" role="status">
                <i class="fas fa-circle-check"></i>
                <div>
                    <strong>Registration submitted</strong>
                    <span><?php echo e($success); ?></span>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <main class="register-shell">
        <section class="register-card" aria-label="Registration form">
            <div class="register-card-header">
                <a href="../index.php" class="register-card-icon" aria-label="Back to Parish System homepage">
                    <?php if ($has_logo): ?>
                        <img src="../assets/img/san-lorenzo-logo.png" alt="San Lorenzo Ruiz logo">
                    <?php else: ?>
                        <i class="fas fa-church"></i>
                    <?php endif; ?>
                </a>
                <h2>Create Your Parish Account</h2>
                <p>Register to access parish requests, sacramental records, schedules, and church services.</p>
            </div>

            <div class="community-quote">
                <i class="fas fa-cross"></i>
                    <span>Welcome to San Lorenzo Ruiz Mission Station. One community, one faith, one service portal.</span>
            </div>

            <div class="verification-notice">
                <i class="fas fa-shield-halved"></i>
                <span>This platform is exclusively for parishioners and residents of Aleosan, Cotabato. All registrations are subject to parish verification and approval.</span>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger auth-alert alert-dismissible fade show" role="alert">
                    <i class="fas fa-circle-exclamation"></i> <?php echo e($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success auth-alert alert-dismissible fade show" role="alert">
                    <i class="fas fa-circle-check"></i> <?php echo e($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="registration-form" id="registrationForm" novalidate>
                <div class="form-grid">
                    <div class="field-group">
                        <label for="first_name" class="field-label">First Name</label>
                        <div class="input-wrap">
                            <i class="fas fa-user field-icon"></i>
                            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($form_data['first_name']); ?>" autocomplete="given-name" required autofocus>
                        </div>
                        <div class="field-message" data-error-for="first_name"></div>
                    </div>

                    <div class="field-group">
                        <label for="surname" class="field-label">Surname</label>
                        <div class="input-wrap">
                            <i class="fas fa-user-tag field-icon"></i>
                            <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e($form_data['surname']); ?>" autocomplete="family-name" required>
                        </div>
                        <div class="field-message" data-error-for="surname"></div>
                    </div>

                    <div class="field-group">
                        <label for="middle_initial" class="field-label">Middle Initial</label>
                        <div class="input-wrap">
                            <i class="fas fa-signature field-icon"></i>
                            <input type="text" class="form-control" id="middle_initial" name="middle_initial" value="<?php echo e($form_data['middle_initial']); ?>" autocomplete="additional-name" maxlength="1" placeholder="Optional">
                        </div>
                        <div class="field-message" data-error-for="middle_initial"></div>
                    </div>

                    <div class="field-group">
                        <label for="phone_number" class="field-label">Phone Number</label>
                        <div class="input-wrap">
                            <i class="fas fa-phone field-icon"></i>
                            <input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?php echo e($form_data['phone_number']); ?>" autocomplete="tel" placeholder="09XXXXXXXXX" required>
                        </div>
                        <div class="field-message" data-error-for="phone_number"></div>
                    </div>

                    <div class="field-group">
                        <label for="email" class="field-label">Gmail Address</label>
                        <div class="input-wrap">
                            <i class="fas fa-envelope field-icon"></i>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($form_data['email']); ?>" autocomplete="email" placeholder="name@gmail.com" required>
                        </div>
                        <div class="field-message" data-error-for="email"></div>
                    </div>

                    <div class="field-group">
                        <label for="chapel_district" class="field-label">Chapel/District</label>
                        <div class="input-wrap">
                            <i class="fas fa-location-dot field-icon"></i>
                            <select class="form-select" id="chapel_district" name="chapel_district" required>
                                <option value="">Select your Chapel/District</option>
                                <?php foreach ($chapel_options as $option): ?>
                                    <option value="<?php echo e($option); ?>" <?php echo $form_data['chapel_district'] === $option ? 'selected' : ''; ?>>
                                        <?php echo e($option); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field-message" data-error-for="chapel_district"></div>
                    </div>

                    <div class="field-group">
                        <label for="role_selection" class="field-label">Role Selection</label>
                        <div class="input-wrap">
                            <i class="fas fa-user-shield field-icon"></i>
                            <select class="form-select" id="role_selection" name="role_selection" required>
                                <option value="user" selected>Parishioner</option>
                                <option value="volunteer">Volunteer / Ministry Member</option>
                            </select>
                        </div>
                        <div class="form-hint">Administrator access is granted only by parish staff after verification.</div>
                    </div>

                    <div class="field-group full">
                        <label for="address" class="field-label">Address</label>
                        <div class="input-wrap">
                            <i class="fas fa-map-location-dot field-icon"></i>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo e($form_data['address']); ?>" autocomplete="street-address" placeholder="Complete Aleosan address" required>
                        </div>
                        <div class="field-message" data-error-for="address"></div>
                    </div>

                    <div class="field-group">
                        <label for="birthdate" class="field-label">Birthdate</label>
                        <div class="input-wrap">
                            <i class="fas fa-calendar-day field-icon"></i>
                            <input type="date" class="form-control" id="birthdate" name="birthdate" value="<?php echo e($form_data['birthdate']); ?>" autocomplete="bday" required>
                        </div>
                        <div class="field-message" data-error-for="birthdate"></div>
                    </div>

                    <div class="field-group">
                        <label for="id_number" class="field-label">ID Number</label>
                        <div class="input-wrap">
                            <i class="fas fa-fingerprint field-icon"></i>
                            <input type="text" class="form-control" id="id_number" name="id_number" value="<?php echo e($form_data['id_number']); ?>" autocomplete="off" placeholder="Number printed on your ID" required>
                        </div>
                        <div class="form-hint">This is encrypted and used only to prevent duplicate registrations.</div>
                        <div class="field-message" data-error-for="id_number"></div>
                    </div>

                    <div class="field-group">
                        <label for="password" class="field-label">Password</label>
                        <div class="input-wrap password">
                            <i class="fas fa-lock field-icon"></i>
                            <input type="password" class="form-control" id="password" name="password" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password="password" aria-label="Show password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-hint">Use at least 8 characters.</div>
                        <div class="password-strength" aria-label="Password strength">
                            <span></span><span></span><span></span><span></span>
                        </div>
                        <div class="form-hint" id="passwordStrengthText">Password strength: waiting for input.</div>
                        <div class="field-message" data-error-for="password"></div>
                    </div>

                    <div class="field-group">
                        <label for="confirm_password" class="field-label">Confirm Password</label>
                        <div class="input-wrap password">
                            <i class="fas fa-key field-icon"></i>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password="confirm_password" aria-label="Show confirm password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="field-message" data-error-for="confirm_password"></div>
                    </div>

                    <div class="field-group full">
                        <span class="field-label">Live Identity Verification</span>
                        <div class="live-verification" id="liveVerification">
                            <div class="camera-stage">
                                <video id="verificationVideo" playsinline muted></video>
                                <canvas id="captureCanvas" hidden></canvas>
                                <div class="face-guide" id="faceGuide" aria-hidden="true"></div>
                                <div class="camera-placeholder" id="cameraPlaceholder">
                                    <i class="fas fa-camera"></i>
                                    <strong>Camera verification required</strong>
                                    <small>No gallery uploads are allowed. Tugon will capture your live face and valid ID using the device camera.</small>
                                </div>
                            </div>

                            <div class="verification-steps">
                                <div class="verification-step is-current" id="faceStep">
                                    <i class="fas fa-user-check"></i>
                                    <span>Face verification</span>
                                </div>
                                <div class="verification-step" id="idStep">
                                    <i class="fas fa-id-card"></i>
                                    <span>Live ID scan</span>
                                </div>
                            </div>

                            <div class="camera-actions">
                                <button type="button" class="camera-btn" id="startCameraBtn">
                                    <i class="fas fa-video"></i> Start Camera
                                </button>
                                <button type="button" class="camera-btn secondary" id="captureIdBtn" disabled>
                                    <i class="fas fa-camera-retro"></i> Capture ID
                                </button>
                            </div>

                            <p class="camera-status" id="cameraStatus">Start the camera and position your face inside the guide.</p>

                            <div class="capture-previews">
                                <div class="capture-preview">
                                    <span>Live Face</span>
                                    <img id="facePreviewImage" alt="Captured live face preview">
                                </div>
                                <div class="capture-preview">
                                    <span>Valid ID</span>
                                    <img id="idPreviewImage" alt="Captured valid ID preview">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="face_capture" name="face_capture">
                        <input type="hidden" id="valid_id_capture" name="valid_id_capture">
                        <div class="field-message" data-error-for="live_verification"></div>
                    </div>

                    <div class="field-group full">
                        <label class="auth-check terms-check" for="terms_check">
                            <input type="checkbox" id="terms_check" name="terms_check" required>
                            <span>I agree to the Terms & Conditions, parish verification policy, and responsible use of sacramental records.</span>
                        </label>
                        <div class="field-message" data-error-for="terms_check"></div>
                    </div>
                </div>

                <button type="submit" class="submit-btn" id="registerSubmit" <?php echo $success ? 'disabled' : ''; ?>>
                    <span class="spinner" aria-hidden="true"></span>
                    <i class="fas fa-user-check submit-icon"></i>
                    <span class="submit-text"><?php echo $success ? 'Registration Submitted' : 'Create Account'; ?></span>
                </button>
            </form>

            <p class="login-link">
                Already have an account? <a href="login.php">Login here</a>
            </p>

            <div class="register-social-divider"><span>or register with</span></div>
            <div class="register-socials" aria-label="Social registration options">
                <button type="button" class="register-social-btn" title="Google registration integration placeholder">
                    <i class="fab fa-google"></i> Google
                </button>
                <button type="button" class="register-social-btn" title="Facebook registration integration placeholder">
                    <i class="fab fa-facebook-f"></i> Facebook
                </button>
                <button type="button" class="register-social-btn" title="Email verification placeholder">
                    <i class="fas fa-envelope-circle-check"></i> Verify Email
                </button>
            </div>
        </section>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const form = document.getElementById('registrationForm');
        const submitButton = document.getElementById('registerSubmit');
        const submitText = submitButton.querySelector('.submit-text');

        const fields = {
            first_name: document.getElementById('first_name'),
            surname: document.getElementById('surname'),
            middle_initial: document.getElementById('middle_initial'),
            phone_number: document.getElementById('phone_number'),
            email: document.getElementById('email'),
            chapel_district: document.getElementById('chapel_district'),
            address: document.getElementById('address'),
            birthdate: document.getElementById('birthdate'),
            id_number: document.getElementById('id_number'),
            password: document.getElementById('password'),
            confirm_password: document.getElementById('confirm_password'),
            face_capture: document.getElementById('face_capture'),
            valid_id_capture: document.getElementById('valid_id_capture'),
            terms_check: document.getElementById('terms_check')
        };
        const cameraStage = document.querySelector('.camera-stage');
        const video = document.getElementById('verificationVideo');
        const canvas = document.getElementById('captureCanvas');
        const startCameraBtn = document.getElementById('startCameraBtn');
        const captureIdBtn = document.getElementById('captureIdBtn');
        const cameraStatus = document.getElementById('cameraStatus');
        const faceStep = document.getElementById('faceStep');
        const idStep = document.getElementById('idStep');
        const facePreviewImage = document.getElementById('facePreviewImage');
        const idPreviewImage = document.getElementById('idPreviewImage');
        const strengthBars = Array.from(document.querySelectorAll('.password-strength span'));
        const strengthText = document.getElementById('passwordStrengthText');
        let cameraStream = null;
        let verificationMode = 'face';
        let faceDetector = null;
        let faceDetectedSince = 0;
        let detectionTimer = null;

        function setFieldError(fieldName, message) {
            const field = fields[fieldName];
            const messageTarget = document.querySelector('[data-error-for="' + fieldName + '"]');
            if (!messageTarget) {
                return;
            }

            if (field) {
                field.classList.toggle('is-invalid-field', Boolean(message));
            }
            messageTarget.textContent = message || '';
        }

        function validateForm() {
            let isValid = true;
            const emailPattern = /^[^\s@]+@gmail\.com$/i;

            Object.keys(fields).forEach((fieldName) => setFieldError(fieldName, ''));

            if (!fields.first_name.value.trim()) {
                setFieldError('first_name', 'First name is required.');
                isValid = false;
            }

            if (!fields.surname.value.trim()) {
                setFieldError('surname', 'Surname is required.');
                isValid = false;
            }

            if (fields.middle_initial.value.trim() && !/^[A-Za-z]$/.test(fields.middle_initial.value.trim())) {
                setFieldError('middle_initial', 'Use one letter only.');
                isValid = false;
            }

            if (!fields.phone_number.value.trim()) {
                setFieldError('phone_number', 'Phone number is required.');
                isValid = false;
            }

            if (!emailPattern.test(fields.email.value.trim())) {
                setFieldError('email', 'Use a valid Gmail address.');
                isValid = false;
            }

            if (!fields.chapel_district.value) {
                setFieldError('chapel_district', 'Please select a chapel or district.');
                isValid = false;
            }

            if (!fields.address.value.trim()) {
                setFieldError('address', 'Complete address is required.');
                isValid = false;
            }

            if (!fields.birthdate.value) {
                setFieldError('birthdate', 'Birthdate is required.');
                isValid = false;
            } else {
                const birthdate = new Date(fields.birthdate.value + 'T00:00:00');
                const minimumAgeDate = new Date();
                minimumAgeDate.setFullYear(minimumAgeDate.getFullYear() - 13);
                if (Number.isNaN(birthdate.getTime()) || birthdate > minimumAgeDate) {
                    setFieldError('birthdate', 'Registrant must be at least 13 years old.');
                    isValid = false;
                }
            }

            if (!fields.id_number.value.trim()) {
                setFieldError('id_number', 'ID number is required.');
                isValid = false;
            }

            if (fields.password.value.length < 8) {
                setFieldError('password', 'Password must be at least 8 characters.');
                isValid = false;
            }

            if (fields.confirm_password.value !== fields.password.value) {
                setFieldError('confirm_password', 'Passwords do not match.');
                isValid = false;
            }

            if (!fields.face_capture.value || !fields.valid_id_capture.value) {
                setFieldError('live_verification', 'Complete the live face and ID camera verification.');
                isValid = false;
            }

            if (!fields.terms_check.checked) {
                setFieldError('terms_check', 'Please accept the Terms & Conditions.');
                isValid = false;
            }

            return isValid;
        }

        function updatePasswordStrength() {
            const value = fields.password.value;
            let score = 0;
            if (value.length >= 8) score++;
            if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
            if (/\d/.test(value)) score++;
            if (/[^A-Za-z0-9]/.test(value)) score++;

            strengthBars.forEach((bar, index) => {
                bar.classList.toggle('active', index < score);
            });

            const labels = ['waiting for input', 'weak', 'fair', 'good', 'strong'];
            strengthText.textContent = 'Password strength: ' + labels[score] + '.';
        }

        function showToast(type, title, message) {
            const toastStack = document.getElementById('toastStack');
            const toast = document.createElement('div');
            toast.className = 'auth-toast ' + type;
            toast.setAttribute('role', type === 'success' ? 'status' : 'alert');
            toast.innerHTML = '<i class="fas ' + (type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><div><strong>' + title + '</strong><span>' + message + '</span></div>';
            toastStack.appendChild(toast);
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(14px)';
                setTimeout(() => toast.remove(), 280);
            }, 4200);
        }

        Object.values(fields).forEach((field) => {
            if (!field) {
                return;
            }
            field.addEventListener('input', () => {
                if (field === fields.middle_initial) {
                    field.value = field.value.replace(/[^A-Za-z]/g, '').slice(0, 1).toUpperCase();
                }
                if (field === fields.password) {
                    updatePasswordStrength();
                }
                if (field.classList.contains('is-invalid-field')) {
                    validateForm();
                }
            });
            field.addEventListener('change', () => {
                if (field.classList.contains('is-invalid-field')) {
                    validateForm();
                }
            });
        });

        function setCameraStatus(message, isError = false) {
            cameraStatus.textContent = message;
            cameraStatus.style.color = isError ? '#fecaca' : 'rgba(255, 248, 235, 0.78)';
        }

        async function startCamera(facingMode = 'user') {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                setFieldError('live_verification', 'This browser does not support camera access.');
                return false;
            }

            if (cameraStream) {
                cameraStream.getTracks().forEach((track) => track.stop());
            }

            try {
                cameraStream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: { ideal: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } },
                    audio: false
                });
                video.srcObject = cameraStream;
                await video.play();
                cameraStage.classList.add('is-active');
                setFieldError('live_verification', '');
                return true;
            } catch (error) {
                setCameraStatus('Camera is blocked or unavailable. Please allow camera access and try again.', true);
                setFieldError('live_verification', 'Camera access is required for registration.');
                return false;
            }
        }

        function captureFrame() {
            const width = video.videoWidth || 1280;
            const height = video.videoHeight || 720;
            canvas.width = width;
            canvas.height = height;
            canvas.getContext('2d').drawImage(video, 0, 0, width, height);
            return canvas.toDataURL('image/jpeg', 0.86);
        }

        function markStepDone(step) {
            step.classList.remove('is-current');
            step.classList.add('is-done');
        }

        function switchToIdCapture() {
            verificationMode = 'id';
            clearInterval(detectionTimer);
            cameraStage.classList.remove('is-face-mode');
            markStepDone(faceStep);
            idStep.classList.add('is-current');
            captureIdBtn.disabled = false;
            setCameraStatus('Place your valid ID inside the camera view, then capture it live.');
            startCamera('environment');
        }

        async function detectFaceLoop() {
            if (verificationMode !== 'face') {
                return;
            }

            if ('FaceDetector' in window && !faceDetector) {
                faceDetector = new FaceDetector({ fastMode: true, maxDetectedFaces: 1 });
            }

            try {
                if (faceDetector) {
                    const faces = await faceDetector.detect(video);
                    if (faces.length === 1) {
                        const box = faces[0].boundingBox;
                        const centerX = box.x + box.width / 2;
                        const centerY = box.y + box.height / 2;
                        const aligned = centerX > video.videoWidth * 0.32 &&
                            centerX < video.videoWidth * 0.68 &&
                            centerY > video.videoHeight * 0.22 &&
                            centerY < video.videoHeight * 0.78 &&
                            box.width > video.videoWidth * 0.16;

                        if (aligned) {
                            faceDetectedSince = faceDetectedSince || Date.now();
                            setCameraStatus('Face detected. Hold still for automatic capture.');
                            if (Date.now() - faceDetectedSince > 900) {
                                fields.face_capture.value = captureFrame();
                                facePreviewImage.src = fields.face_capture.value;
                                switchToIdCapture();
                            }
                            return;
                        }
                    }
                    faceDetectedSince = 0;
                    setCameraStatus('Position your face clearly inside the guide.');
                    return;
                }

                faceDetectedSince = faceDetectedSince || Date.now();
                setCameraStatus('Native face detection is unavailable. Hold still inside the guide for live capture.');
                if (Date.now() - faceDetectedSince > 2200) {
                    fields.face_capture.value = captureFrame();
                    facePreviewImage.src = fields.face_capture.value;
                    switchToIdCapture();
                }
            } catch (error) {
                faceDetectedSince = 0;
                setCameraStatus('Face detection failed. Improve lighting and keep your face clear.', true);
            }
        }

        startCameraBtn.addEventListener('click', async () => {
            verificationMode = 'face';
            fields.face_capture.value = '';
            fields.valid_id_capture.value = '';
            facePreviewImage.removeAttribute('src');
            idPreviewImage.removeAttribute('src');
            faceStep.className = 'verification-step is-current';
            idStep.className = 'verification-step';
            captureIdBtn.disabled = true;
            cameraStage.classList.add('is-face-mode');
            const started = await startCamera('user');
            if (started) {
                setCameraStatus('Position your face clearly inside the guide.');
                clearInterval(detectionTimer);
                detectionTimer = setInterval(detectFaceLoop, 350);
            }
        });

        captureIdBtn.addEventListener('click', () => {
            if (verificationMode !== 'id') {
                return;
            }

            fields.valid_id_capture.value = captureFrame();
            idPreviewImage.src = fields.valid_id_capture.value;
            markStepDone(idStep);
            captureIdBtn.disabled = true;
            setFieldError('live_verification', '');
            setCameraStatus('Live identity verification complete. You can now create the account.');
        });

        document.querySelectorAll('[data-toggle-password]').forEach((toggle) => {
            toggle.addEventListener('click', () => {
                const target = document.getElementById(toggle.dataset.togglePassword);
                const icon = toggle.querySelector('i');
                const shouldShow = target.type === 'password';
                target.type = shouldShow ? 'text' : 'password';
                icon.classList.toggle('fa-eye', !shouldShow);
                icon.classList.toggle('fa-eye-slash', shouldShow);
                toggle.setAttribute('aria-label', shouldShow ? 'Hide password' : 'Show password');
            });
        });

        form.addEventListener('submit', (event) => {
            if (!validateForm()) {
                event.preventDefault();
                showToast('error', 'Check the form', 'Please correct the highlighted fields before creating your account.');
                return;
            }

            submitButton.disabled = true;
            submitButton.classList.add('is-loading');
            submitText.textContent = 'Creating account...';
        });
    </script>
</body>
</html>
