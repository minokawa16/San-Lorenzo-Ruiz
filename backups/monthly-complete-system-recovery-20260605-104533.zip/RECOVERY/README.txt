Complete System Recovery Backup
Created: 2026-06-05 10:45:33

This package includes database records, uploaded files, application source, templates, assets, configuration, logs, and recovery metadata.
