<?php
session_start();
include '../database/config.php';
include '../includes/helpers.php';

requireAdmin();

// Redirect to certificate generator
header("Location: certificate-generator.php");
exit;
?>
