<?php
return [
    // Set to false to keep email attempts logged without sending.
    'enabled' => true,
    'from_email' => 'no-reply@tugon.local',
    'from_name' => 'TUGON Parish System',
    'reply_to' => ''
];
