<?php
/**
 * Security Configuration & Constants
 * Centralized security settings for the application
 */

// ===================================================================
// SECURITY SETTINGS
// ===================================================================

// Password Security
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_NUMBERS', true);
define('PASSWORD_REQUIRE_SPECIAL_CHARS', true);
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_HASH_COST', 12); // Higher = more secure but slower

// Session Security
define('SESSION_TIMEOUT', 30 * 60); // 30 minutes in seconds
define('SESSION_REGENERATE_INTERVAL', 5 * 60); // Regenerate every 5 minutes
define('SESSION_COOKIE_HTTPONLY', true);
define('SESSION_COOKIE_SECURE', false); // Set to true in production with HTTPS
define('SESSION_COOKIE_SAMESITE', 'Lax');

// Login Security
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_DURATION', 15 * 60); // 15 minutes in seconds
define('LOGIN_ATTEMPT_WINDOW', 10 * 60); // 10 minute window for counting attempts

// CSRF Protection
define('CSRF_TOKEN_EXPIRY', 1 * 3600); // 1 hour
define('CSRF_TOKEN_NAME', '_csrf_token');

// Rate Limiting
define('RATE_LIMIT_REQUESTS', 100);
define('RATE_LIMIT_WINDOW', 3600); // 1 hour in seconds

// ===================================================================
// DATABASE SECURITY
// ===================================================================

// Prepared Statement Settings
define('DB_FETCH_ASSOC', MYSQLI_ASSOC);
define('DB_PREPARED_STMT_CACHE_SIZE', 256);

// ===================================================================
// FILE UPLOAD SECURITY
// ===================================================================

define('ALLOWED_UPLOAD_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5 MB
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

// MIME type whitelist
$ALLOWED_MIME_TYPES = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/gif' => 'gif',
    'application/pdf' => 'pdf',
    'application/msword' => 'doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx'
];

// ===================================================================
// ENCRYPTION
// ===================================================================

define('ENCRYPTION_CIPHER', 'AES-256-CBC');
define('ENCRYPTION_KEY', getenv('ENCRYPTION_KEY') ?: bin2hex(random_bytes(16)));

// ===================================================================
// CACHE SETTINGS
// ===================================================================

define('CACHE_ENABLED', true);
define('CACHE_DRIVER', 'file'); // Options: 'file', 'redis', 'memcached'
define('CACHE_TTL_DEFAULT', 30 * 60); // 30 minutes
define('CACHE_DIR', __DIR__ . '/../cache/');
define('CACHE_REDIS_HOST', 'localhost');
define('CACHE_REDIS_PORT', 6379);

// ===================================================================
// LOGGING
// ===================================================================

define('LOG_ENABLED', true);
define('LOG_DIR', __DIR__ . '/../logs/');
define('LOG_LEVEL', 'debug'); // Options: 'debug', 'info', 'warning', 'error'
define('LOG_MAX_SIZE', 10 * 1024 * 1024); // 10 MB per file
define('LOG_RETENTION_DAYS', 30);

// ===================================================================
// ERROR HANDLING
// ===================================================================

define('DEBUG_MODE', false); // Set to false in production
define('DISPLAY_ERRORS', DEBUG_MODE);
define('LOG_ERRORS', true);
define('ERROR_REPORT_EMAIL', 'admin@parish.local');

// ===================================================================
// API SETTINGS
// ===================================================================

define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 1000); // Requests per hour
define('JWT_EXPIRY', 24 * 3600); // 24 hours
define('JWT_SECRET_KEY', getenv('JWT_SECRET_KEY') ?: 'your-secret-key-change-in-production');

// ===================================================================
// SECURITY HEADERS
// ===================================================================

$SECURITY_HEADERS = [
    'Strict-Transport-Security' => 'max-age=31536000; includeSubDomains',
    'X-Content-Type-Options' => 'nosniff',
    'X-Frame-Options' => 'DENY',
    'X-XSS-Protection' => '1; mode=block',
    'Referrer-Policy' => 'strict-origin-when-cross-origin',
    'Permissions-Policy' => 'geolocation=(), microphone=(), camera=()',
    'Content-Security-Policy' => "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; img-src 'self' data: https:; font-src 'self' https://cdnjs.cloudflare.com"
];

// ===================================================================
// PAGINATION SETTINGS
// ===================================================================

define('DEFAULT_PAGE_SIZE', 20);
define('MAX_PAGE_SIZE', 100);
define('PAGINATION_RANGE', 5); // Number of page links to show

// ===================================================================
// EMAIL SETTINGS
// ===================================================================

define('SMTP_HOST', getenv('SMTP_HOST') ?: 'localhost');
define('SMTP_PORT', getenv('SMTP_PORT') ?: 587);
define('SMTP_USERNAME', getenv('SMTP_USERNAME') ?: '');
define('SMTP_PASSWORD', getenv('SMTP_PASSWORD') ?: '');
define('SMTP_FROM_EMAIL', getenv('SMTP_FROM_EMAIL') ?: 'noreply@parish.local');
define('SMTP_FROM_NAME', 'San Lorenzo Ruiz Mission Station');
define('SMTP_ENCRYPTION', 'tls'); // 'ssl' or 'tls'

// ===================================================================
// TWILIO SMS SETTINGS
// ===================================================================

define('TWILIO_ACCOUNT_SID', getenv('TWILIO_ACCOUNT_SID') ?: '');
define('TWILIO_AUTH_TOKEN', getenv('TWILIO_AUTH_TOKEN') ?: '');
define('TWILIO_PHONE_NUMBER', getenv('TWILIO_PHONE_NUMBER') ?: '');

// ===================================================================
// IP WHITELIST / BLACKLIST
// ===================================================================

$IP_WHITELIST = [];
$IP_BLACKLIST = [];

// ===================================================================
// ALLOWED CORS ORIGINS
// ===================================================================

$ALLOWED_ORIGINS = [
    'http://localhost',
    'http://localhost:3000',
    'http://localhost:8000',
];

if (!in_array($_SERVER['HTTP_ORIGIN'] ?? '', $ALLOWED_ORIGINS, true)) {
    // Set to empty array in production
}
?>
