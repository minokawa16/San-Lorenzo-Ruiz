<?php
/**
 * Manage Announcements Page
 * Admin interface for managing parish announcements
 */

// Include centralized session management
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

// Require admin access
requireAdmin();

$error = '';
$success = '';
ensureExpandedAnnouncementTypeSchema($conn);
ensureAnnouncementAttachmentSchema($conn);
ensureEmailNotificationSchema($conn);

$announcement_types = [
    'announcement' => 'General Announcement',
    'monthly_schedule' => 'Monthly Schedule',
    'mass_schedule' => 'Schedule Calendar',
    'parish_event' => 'Parish Event',
    'patronal_fiesta_schedule' => 'Patronal Fiesta Schedule'
];

function ensureAnnouncementArchiveColumn($conn) {
    $result = $conn->query("SHOW COLUMNS FROM announcements LIKE 'deleted_at'");
    if ($result && $result->num_rows > 0) {
        return true;
    }

    return $conn->query("ALTER TABLE announcements ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL AFTER updated_at");
}

if (!ensureAnnouncementArchiveColumn($conn)) {
    $error = 'Error preparing announcement archive: ' . $conn->error;
}

if (!columnExists($conn, 'announcements', 'event_date')) {
    $conn->query("ALTER TABLE announcements ADD COLUMN event_date DATE NULL AFTER expiry_date");
}

function saveAnnouncementAttachment($file) {
    if (!isset($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'path' => null, 'original_name' => null, 'mime_type' => null, 'size' => null];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Unable to upload the attachment. Please try again.'];
    }

    $config = getAnnouncementAttachmentConfig();
    $original_name = basename($file['name']);
    $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $size = intval($file['size']);
    $tmp_name = $file['tmp_name'];
    $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : false;
    $mime_type = $finfo ? finfo_file($finfo, $tmp_name) : mime_content_type($tmp_name);
    if ($finfo) {
        finfo_close($finfo);
    }

    if ($size > $config['max_size']) {
        return ['ok' => false, 'error' => 'Attachment must not exceed 10MB.'];
    }

    if (!in_array($extension, $config['extensions'], true) || !in_array($mime_type, $config['mime_types'], true)) {
        return ['ok' => false, 'error' => 'Attachment type is not allowed. Use an image, PDF, Office document, or text file.'];
    }

    $upload_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'announcements';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    $index_file = $upload_dir . DIRECTORY_SEPARATOR . 'index.php';
    if (!is_file($index_file)) {
        file_put_contents($index_file, "<?php\nhttp_response_code(403);\nexit('Access denied');\n");
    }
    $htaccess_file = $upload_dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess_file)) {
        file_put_contents($htaccess_file, "Options -Indexes\nRequire all denied\nDeny from all\n");
    }

    $safe_filename = 'announcement-' . date('YmdHis') . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
    $target_path = $upload_dir . DIRECTORY_SEPARATOR . $safe_filename;
    if (!move_uploaded_file($tmp_name, $target_path)) {
        return ['ok' => false, 'error' => 'Unable to save the announcement attachment.'];
    }

    return [
        'ok' => true,
        'path' => 'uploads/announcements/' . $safe_filename,
        'original_name' => $original_name,
        'mime_type' => $mime_type,
        'size' => $size
    ];
}

// Handle form submission 
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'archive_announcement') {
        $announcement_id = intval($_POST['announcement_id']);

        if ($conn->query("UPDATE announcements SET deleted_at = NOW(), status = 'inactive' WHERE announcement_id = $announcement_id")) {
            createAuditLog($conn, $_SESSION['user_id'], 'ARCHIVE_ANNOUNCEMENT', 'announcements', $announcement_id);
            $success = 'Announcement archived successfully!';
        } else {
            $error = 'Error archiving announcement: ' . $conn->error;
        }
    } elseif ($action == 'add_announcement') {
        $title = trim(sanitize($_POST['title']));
        $content = trim($_POST['content'] ?? '');
        $type_raw = $_POST['type'] ?? 'announcement';
        $type = array_key_exists($type_raw, $announcement_types) ? $type_raw : 'announcement';
        $event_date_raw = trim($_POST['event_date'] ?? '');
        $event_date_value = $type_raw === 'patronal_fiesta_schedule' && $event_date_raw !== '' ? $event_date_raw : null;
        $published_by = $_SESSION['user_id'];

        if ($title === '' || $content === '') {
            $error = 'Please add a title and description.';
        } elseif ($type_raw === 'patronal_fiesta_schedule' && $event_date_raw === '') {
            $error = 'Please add the date of the Patronal Fiesta.';
        } else {
            $attachment = saveAnnouncementAttachment($_FILES['attachment'] ?? null);
            if (!$attachment['ok']) {
                $error = $attachment['error'];
            } else {
                $image_path = isAnnouncementImageAttachment($attachment['mime_type'] ?? '') ? $attachment['path'] : null;
                $stmt = $conn->prepare("INSERT INTO announcements (title, content, image_path, attachment_path, attachment_original_name, attachment_mime_type, attachment_size, type, published_by, status, event_date)
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)");
                if ($stmt) {
                    $published_by = intval($published_by);
                    $attachment_size = $attachment['size'];
                    $stmt->bind_param(
                        'ssssssisis',
                        $title,
                        $content,
                        $image_path,
                        $attachment['path'],
                        $attachment['original_name'],
                        $attachment['mime_type'],
                        $attachment_size,
                        $type,
                        $published_by,
                        $event_date_value
                    );
                    if ($stmt->execute()) {
                        $announcement_id = $stmt->insert_id;
                        createAuditLog($conn, $_SESSION['user_id'], 'ADD_ANNOUNCEMENT', 'announcements', $announcement_id);
                        $recipients = $conn->query("SELECT u.id, u.email, u.fullname, COALESCE(np.email_enabled, 1) AS email_enabled
                            FROM users u
                            LEFT JOIN notification_preferences np ON np.user_id = u.id AND np.category = 'announcements'
                            WHERE u.role = 'user' AND u.status = 'active'");
                        while ($recipients && $recipient = $recipients->fetch_assoc()) {
                            createNotification($conn, $recipient['id'], 'New Parish Announcement', $title);
                            $delivery_status = 'skipped';
                            if (intval($recipient['email_enabled']) === 1) {
                                $email_body = '<p><strong>' . e($title) . '</strong></p><p>' . nl2br(e($content)) . '</p><p>Published: ' . e(formatDateTime(date('Y-m-d H:i:s'))) . '</p>';
                                $view_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL . 'users/announcements.php';
                                $sent = sendTugonEmail($conn, $recipient['email'], 'New Parish Announcement: ' . $title, tugonEmailTemplate('Parish Announcement', $email_body, 'View Announcement', $view_url), '', $recipient['id'], 'announcement');
                                $delivery_status = $sent['ok'] ? 'sent' : 'failed';
                            }
                            $log_stmt = $conn->prepare("INSERT IGNORE INTO announcement_recipients (announcement_id, user_id, email, delivery_status, sent_at) VALUES (?, ?, ?, ?, ?)");
                            if ($log_stmt) {
                                $sent_at = $delivery_status === 'sent' ? date('Y-m-d H:i:s') : null;
                                $log_stmt->bind_param('iisss', $announcement_id, $recipient['id'], $recipient['email'], $delivery_status, $sent_at);
                                $log_stmt->execute();
                                $log_stmt->close();
                            }
                        }
                        $success = 'Announcement posted successfully!';
                    } else {
                        if (!empty($attachment['path'])) {
                            @unlink(dirname(__DIR__) . DIRECTORY_SEPARATOR . $attachment['path']);
                        }
                        $error = 'Error posting announcement: ' . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    if (!empty($attachment['path'])) {
                        @unlink(dirname(__DIR__) . DIRECTORY_SEPARATOR . $attachment['path']);
                    }
                    $error = 'Error preparing announcement: ' . $conn->error;
                }
            }
        }
    }
}

// Get announcements
$page = intval($_GET['page'] ?? 1);
$limit = 10;
$type_filter = $_GET['type'] ?? '';
$where = "WHERE deleted_at IS NULL";
if (!empty($type_filter)) {
    $type_filter = $conn->real_escape_string($type_filter);
    $where .= " AND type = '$type_filter'";
}

$total_result = $conn->query("SELECT COUNT(*) as count FROM announcements $where");
$total = $total_result ? (int) $total_result->fetch_assoc()['count'] : 0;
if (!$total_result) {
    $error = 'Error loading announcement count: ' . $conn->error;
}
$pagination = getPaginationData($page, $limit, $total);

$sql = "SELECT a.*, u.fullname FROM announcements a 
        JOIN users u ON a.published_by = u.id 
        $where
        ORDER BY a.published_date DESC 
        LIMIT {$pagination['offset']}, {$pagination['limit']}";
$result = $conn->query($sql);
if (!$result) {
    $error = 'Error loading announcements: ' . $conn->error;
}

$page_title = 'Manage Announcements';

// Set breadcrumb data
$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Manage Announcements' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <!-- Breadcrumb Navigation -->
    <?php include '../includes/breadcrumb.php'; ?>
    
    <!-- Back Button -->
    <?php include '../includes/back_button.php'; ?>
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><i class="fas fa-bullhorn"></i> Manage Announcements</h1>
        </div>
        <div class="col-md-4 text-end">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal">
                <i class="fas fa-plus"></i> New Announcement
            </button>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Announcements List -->
    <?php if (!empty($type_filter)): ?>
        <div class="alert alert-light border d-flex justify-content-between align-items-center">
            <span>
                <i class="fas fa-filter"></i>
                Showing announcement type: <strong><?php echo e($announcement_types[$type_filter] ?? ucfirst(str_replace('_', ' ', $type_filter))); ?></strong>
            </span>
            <a href="manage-announcements.php" class="btn btn-sm btn-outline-secondary">Clear Type Filter</a>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($announcement = $result->fetch_assoc()): ?>
                <div class="col-md-6 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title"><?php echo sanitize($announcement['title']); ?></h5>
                                <span class="badge bg-<?php echo in_array($announcement['type'], ['parish_event', 'patronal_fiesta_schedule'], true) ? 'success' : 'info'; ?>">
                                    <?php echo e($announcement_types[$announcement['type']] ?? ucfirst(str_replace('_', ' ', $announcement['type']))); ?>
                                </span>
                            </div>
                            <p class="card-text text-muted"><?php echo substr(sanitize($announcement['content']), 0, 150); ?>...</p>
                            <?php if (!empty($announcement['attachment_path'])): ?>
                                <div class="announcement-attachment-preview mb-2">
                                    <?php if (isAnnouncementImageAttachment($announcement['attachment_mime_type'] ?? '')): ?>
                                        <img src="../announcement-attachment.php?id=<?php echo intval($announcement['announcement_id']); ?>" alt="Announcement attachment" class="img-fluid rounded border mb-2" style="max-height: 180px; object-fit: cover; width: 100%;">
                                    <?php endif; ?>
                                    <a class="btn btn-sm btn-outline-secondary" href="../announcement-attachment.php?id=<?php echo intval($announcement['announcement_id']); ?>" target="_blank">
                                        <i class="fas fa-paperclip"></i>
                                        <?php echo e($announcement['attachment_original_name'] ?: 'View attachment'); ?>
                                        <?php if (!empty($announcement['attachment_size'])): ?>
                                            <span class="text-muted">(<?php echo e(formatFileSize($announcement['attachment_size'])); ?>)</span>
                                        <?php endif; ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <small class="text-muted">
                                By <?php echo sanitize($announcement['fullname']); ?> on <?php echo formatDate($announcement['published_date']); ?>
                                <?php if ($announcement['type'] === 'patronal_fiesta_schedule' && !empty($announcement['event_date'])): ?>
                                    | Patronal Fiesta Date: <?php echo formatDate($announcement['event_date']); ?>
                                <?php endif; ?>
                            </small>
                        </div>
                        <div class="card-footer bg-light">
                            <button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i> Edit</button>
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i> Delete</button>
                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Archive this announcement? It will be hidden from this list but kept in the database.');">
                                <input type="hidden" name="action" value="archive_announcement">
                                <input type="hidden" name="announcement_id" value="<?php echo $announcement['announcement_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-secondary">
                                    <i class="fas fa-archive"></i> Archive
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">No announcements yet</div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Announcement Modal -->
<div class="modal fade" id="addAnnouncementModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Post New Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_announcement">
                    
                    <div class="mb-3">
                        <label for="type" class="form-label">Type</label>
                        <select class="form-select" id="type" name="type" required>
                            <?php foreach ($announcement_types as $value => $label): ?>
                                <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="content" class="form-label">Description</label>
                        <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="attachment" class="form-label">Add Image or File</label>
                        <input type="file" class="form-control" id="attachment" name="attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,image/jpeg,image/png,image/gif,application/pdf,text/plain">
                        <div class="form-text">Optional. Images appear in the announcement; other files are shown as attachments. Maximum 10MB.</div>
                    </div>

                    <div class="mb-3" id="patronalFiestaDateGroup" style="display:none;">
                        <label for="event_date" class="form-label">Date of Patronal Fiesta</label>
                        <input type="date" class="form-control" id="event_date" name="event_date">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Post Announcement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const type = document.getElementById('type');
    const dateGroup = document.getElementById('patronalFiestaDateGroup');
    const dateInput = document.getElementById('event_date');

    function togglePatronalFiestaDate() {
        const isPatronalFiesta = type && type.value === 'patronal_fiesta_schedule';
        if (dateGroup) {
            dateGroup.style.display = isPatronalFiesta ? '' : 'none';
        }
        if (dateInput) {
            dateInput.required = isPatronalFiesta;
            if (!isPatronalFiesta) {
                dateInput.value = '';
            }
        }
    }

    if (type) {
        type.addEventListener('change', togglePatronalFiestaDate);
        togglePatronalFiestaDate();
    }
});
</script>

<?php include '../templates/footer.php'; ?>
