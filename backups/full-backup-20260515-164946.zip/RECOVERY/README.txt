Recovery backup created 2026-05-15 16:49:46

Restore files by copying the project files back to the ParishSystem folder.
Restore records by importing RECOVERY/database.sql into the parish_management_system database.
