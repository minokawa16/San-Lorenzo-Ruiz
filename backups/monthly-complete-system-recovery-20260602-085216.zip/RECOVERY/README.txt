Complete System Recovery Backup
Created: 2026-06-02 08:52:16

This package includes database records, uploaded files, application source, templates, assets, configuration, logs, and recovery metadata.
