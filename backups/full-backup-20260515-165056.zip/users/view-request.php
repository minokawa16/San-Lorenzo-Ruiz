<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$user_id = $_SESSION['user_id'];
$request_id = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT r.*, u.fullname as user_name FROM requests r JOIN users u ON r.user_id = u.id WHERE r.request_id = ? AND r.user_id = ?");
if (!$stmt) {
    redirect('my-requests.php');
}

$stmt->bind_param('ii', $request_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows == 0) {
    $stmt->close();
    redirect('my-requests.php');
}

$request = $result->fetch_assoc();
$stmt->close();
$page_title = 'View Request';
?>
<?php include '../templates/header.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-file-alt"></i> Request Details</h5>
                        <span class="badge bg-<?php echo getStatusBadgeClass($request['status']); ?>">
                            <?php echo e(ucfirst($request['status'])); ?>
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-muted mb-2">Reference Number</h6>
                            <p class="lead"><?php echo e($request['reference_number']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted mb-2">Request Type</h6>
                            <p class="lead"><?php echo e(ucfirst(str_replace('_', ' ', $request['request_type']))); ?></p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-muted mb-2">Date Requested</h6>
                            <p><?php echo formatDate($request['date_requested']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted mb-2">Last Updated</h6>
                            <p><?php echo formatDate($request['updated_at']); ?></p>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="text-muted mb-2">Description</h6>
                        <p><?php echo sanitize($request['description'] ?? 'No description provided'); ?></p>
                    </div>

                    <?php if (!empty($request['admin_response'])): ?>
                        <div class="alert alert-info">
                            <h6><i class="fas fa-comment"></i> Admin Response</h6>
                            <p class="mb-0"><?php echo sanitize($request['admin_response']); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                        <a href="my-requests.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Requests
                        </a>
                        <?php if ($request['status'] == 'completed'): ?>
                            <button class="btn btn-primary" onclick="window.print()">
                                <i class="fas fa-print"></i> Print/Save as PDF
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
