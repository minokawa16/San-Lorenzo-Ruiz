<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$breadcrumbs = [
    'Dashboard' => 'index.php',
    'Request Certificate' => null
];

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') == 'POST') {
    $allowed_types = [
        'baptismal_certificate',
        'confirmation_certificate',
        'first_communion_certificate',
        'marriage_certificate',
    ];
    $request_type = $_POST['request_type'] ?? '';
    $description = trim($_POST['description'] ?? '');
    
    if (!in_array($request_type, $allowed_types, true)) {
        $error = 'Please select a request type';
    } else {
        $reference_number = generateReferenceNumber();
        $status = 'pending';
        $stmt = $conn->prepare("INSERT INTO requests (user_id, request_type, description, status, reference_number) VALUES (?, ?, ?, ?, ?)");

        if (!$stmt) {
            $error = 'Unable to prepare your request. Please contact the parish office.';
        } else {
            $stmt->bind_param('issss', $user_id, $request_type, $description, $status, $reference_number);
        }

        if (!$error && $stmt->execute()) {
            $request_id = $conn->insert_id;
            createAuditLog($conn, $user_id, 'CREATE_REQUEST', 'requests', $request_id);
            createNotification($conn, $user_id, 'Request Created', 'Your request has been submitted with reference: ' . $reference_number);
            $success = 'Request submitted successfully! Reference: ' . $reference_number;
        } else {
            $error = $error ?: 'Error submitting request: ' . $conn->error;
        }

        if (isset($stmt) && $stmt) {
            $stmt->close();
        }
    }
}

$page_title = 'Request Certificate';
?>
<?php include '../templates/header.php'; ?>

<?php include '../includes/breadcrumb.php'; ?>
<?php include '../includes/back_button.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-file-certificate"></i> Request Sacramental Certificate</h5>
                </div>
                <div class="card-body">
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="request_type" class="form-label">Certificate Type</label>
                            <select class="form-select form-select-lg" id="request_type" name="request_type" required>
                                <option value="">-- Select Certificate Type --</option>
                                <option value="baptismal_certificate">Baptismal Certificate</option>
                                <option value="confirmation_certificate">Confirmation Certificate</option>
                                <option value="first_communion_certificate">First Communion Certificate</option>
                                <option value="marriage_certificate">Marriage Certificate</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Additional Information (Optional)</label>
                            <textarea class="form-control" id="description" name="description" rows="4" placeholder="Provide any additional details about your request..."></textarea>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Processing Time:</strong> Your request will be reviewed by our staff and processed within 3-5 business days.
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Submit Request</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
