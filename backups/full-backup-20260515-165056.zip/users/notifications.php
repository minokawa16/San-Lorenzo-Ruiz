<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$user_id = intval($_SESSION['user_id']);
$success = '';
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'mark_all_read') {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        if ($stmt) {
            $stmt->bind_param('i', $user_id);
            $success = $stmt->execute() ? 'All notifications marked as read.' : 'Unable to update notifications.';
            $stmt->close();
        } else {
            $error = 'Unable to update notifications.';
        }
    }

    if ($action === 'mark_read') {
        $notification_id = intval($_POST['notification_id'] ?? 0);
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?");
        if ($stmt) {
            $stmt->bind_param('ii', $notification_id, $user_id);
            $success = $stmt->execute() ? 'Notification marked as read.' : 'Unable to update notification.';
            $stmt->close();
        } else {
            $error = 'Unable to update notification.';
        }
    }
}

$notifications = [];
$stmt = $conn->prepare("SELECT notification_id, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
}

$page_title = 'Notifications';
$breadcrumbs = [
    'Dashboard' => 'index.php',
    'Notifications' => null
];
?>
<?php include '../templates/header.php'; ?>

<?php include '../includes/breadcrumb.php'; ?>
<?php include '../includes/back_button.php'; ?>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h1 class="mb-2"><i class="fas fa-bell"></i> Notifications</h1>
            <p class="text-muted mb-0">Updates about your submitted requests and reservations.</p>
        </div>
        <?php if (!empty($notifications)): ?>
            <form method="POST">
                <input type="hidden" name="action" value="mark_all_read">
                <button type="submit" class="btn btn-outline-primary">
                    <i class="fas fa-check-double"></i> Mark all read
                </button>
            </form>
        <?php endif; ?>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo e($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <?php if (!empty($notifications)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($notifications as $notification): ?>
                        <div class="list-group-item d-flex justify-content-between align-items-start gap-3 <?php echo !$notification['is_read'] ? 'bg-light' : ''; ?>">
                            <div>
                                <div class="d-flex align-items-center gap-2">
                                    <h6 class="mb-1"><?php echo e($notification['title']); ?></h6>
                                    <?php if (!$notification['is_read']): ?>
                                        <span class="badge bg-primary">New</span>
                                    <?php endif; ?>
                                </div>
                                <p class="mb-1"><?php echo e($notification['message']); ?></p>
                                <small class="text-muted"><?php echo formatDateTime($notification['created_at']); ?></small>
                            </div>
                            <?php if (!$notification['is_read']): ?>
                                <form method="POST">
                                    <input type="hidden" name="action" value="mark_read">
                                    <input type="hidden" name="notification_id" value="<?php echo intval($notification['notification_id']); ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-primary">Mark read</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-bell-slash text-muted mb-3" style="font-size: 3rem;"></i>
                    <h5>No notifications yet</h5>
                    <p class="text-muted mb-0">New request and reservation updates will appear here.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
