<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$page_title = 'Announcements';
$breadcrumbs = [
    'Dashboard' => 'index.php',
    'Announcements' => null
];

$type = $_GET['type'] ?? 'all';
$allowed_types = ['all', 'announcement', 'schedule', 'event', 'obituary'];
if (!in_array($type, $allowed_types, true)) {
    $type = 'all';
}

$announcements = [];
if ($type === 'all') {
    $stmt = $conn->prepare("SELECT announcement_id, title, content, type, published_date, expiry_date FROM announcements WHERE status = 'active' AND (expiry_date IS NULL OR expiry_date >= NOW()) ORDER BY published_date DESC");
} else {
    $stmt = $conn->prepare("SELECT announcement_id, title, content, type, published_date, expiry_date FROM announcements WHERE status = 'active' AND type = ? AND (expiry_date IS NULL OR expiry_date >= NOW()) ORDER BY published_date DESC");
    if ($stmt) {
        $stmt->bind_param('s', $type);
    }
}

if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
    $stmt->close();
}
?>
<?php include '../templates/header.php'; ?>

<?php include '../includes/breadcrumb.php'; ?>
<?php include '../includes/back_button.php'; ?>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h1 class="mb-2"><i class="fas fa-bullhorn"></i> Announcements</h1>
            <p class="text-muted mb-0">Latest parish news, schedules, events, and notices.</p>
        </div>
        <form method="GET" class="d-flex gap-2">
            <select name="type" class="form-select" onchange="this.form.submit()">
                <option value="all" <?php echo $type === 'all' ? 'selected' : ''; ?>>All Types</option>
                <option value="announcement" <?php echo $type === 'announcement' ? 'selected' : ''; ?>>Announcements</option>
                <option value="schedule" <?php echo $type === 'schedule' ? 'selected' : ''; ?>>Schedules</option>
                <option value="event" <?php echo $type === 'event' ? 'selected' : ''; ?>>Events</option>
                <option value="obituary" <?php echo $type === 'obituary' ? 'selected' : ''; ?>>Obituaries</option>
            </select>
        </form>
    </div>

    <?php if (!empty($announcements)): ?>
        <div class="row">
            <?php foreach ($announcements as $announcement): ?>
                <div class="col-lg-6 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start gap-3 mb-2">
                                <h5 class="card-title mb-0"><?php echo e($announcement['title']); ?></h5>
                                <span class="badge bg-info"><?php echo e(ucfirst($announcement['type'])); ?></span>
                            </div>
                            <p class="card-text"><?php echo nl2br(e($announcement['content'])); ?></p>
                        </div>
                        <div class="card-footer bg-light">
                            <small class="text-muted">Posted <?php echo formatDateTime($announcement['published_date']); ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-bullhorn text-muted mb-3" style="font-size: 3rem;"></i>
                <h5>No announcements found</h5>
                <p class="text-muted mb-0">There are no active announcements for this filter.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../templates/footer.php'; ?>
