<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

ensureScheduleEventsTable($conn);

$page_title = 'Parish Calendar';
$breadcrumbs = [
    'Dashboard' => 'index.php',
    'Schedule' => null
];

$upcoming_events = [];
$stmt = $conn->prepare("SELECT title, description, event_date, start_time, end_time, location, category, priority, color_label
                        FROM schedule_events
                        WHERE visibility = 'public'
                          AND approval_status = 'approved'
                          AND status != 'cancelled'
                          AND event_date >= CURDATE()
                        ORDER BY event_date ASC, start_time ASC
                        LIMIT 8");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($result && $row = $result->fetch_assoc()) {
        $upcoming_events[] = $row;
    }
    $stmt->close();
}
?>
<?php include '../templates/header.php'; ?>

<?php include '../includes/breadcrumb.php'; ?>
<?php include '../includes/back_button.php'; ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css">

<style>
    .calendar-user-hero {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 18px;
    }

    .calendar-user-title {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .calendar-user-icon {
        width: 52px;
        height: 52px;
        border-radius: 18px;
        display: grid;
        place-items: center;
        color: #fff;
        background: linear-gradient(135deg, #1a73e8, #34a853);
        box-shadow: 0 14px 30px rgba(26, 115, 232, 0.24);
    }

    .calendar-user-title h1 {
        margin: 0;
        font-weight: 800;
        font-size: clamp(1.4rem, 2.2vw, 2rem);
        letter-spacing: 0;
    }

    .calendar-user-title p {
        margin: 3px 0 0;
        color: var(--text-muted, #64748b);
    }

    .calendar-user-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
    }

    .calendar-user-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 340px;
        gap: 18px;
        align-items: start;
    }

    .calendar-panel,
    .upcoming-panel {
        background: var(--surface-color, #fff);
        border: 1px solid #eef2f7;
        border-radius: 24px;
        box-shadow: var(--shadow-soft, 0 8px 24px rgba(16,24,40,0.08));
    }

    .calendar-panel {
        padding: 12px;
        min-height: 690px;
        position: relative;
    }

    .upcoming-panel {
        padding: 18px;
        position: sticky;
        top: 96px;
    }

    .upcoming-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 14px;
    }

    .upcoming-header h2 {
        margin: 0;
        font-size: 1rem;
        font-weight: 800;
    }

    .event-stack {
        display: grid;
        gap: 10px;
    }

    .event-card {
        border: 1px solid #eef2f7;
        border-left: 5px solid var(--event-color, #1a73e8);
        border-radius: 18px;
        padding: 12px;
        background: rgba(248, 250, 252, 0.82);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .event-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 24px rgba(15, 23, 42, 0.1);
    }

    .event-card strong {
        display: block;
        font-size: 0.95rem;
        margin-bottom: 4px;
    }

    .event-card span,
    .event-card small {
        color: var(--text-muted, #64748b);
    }

    .filter-bar {
        display: flex;
        gap: 10px;
        margin-bottom: 12px;
        flex-wrap: wrap;
    }

    .filter-bar .form-control,
    .filter-bar .form-select {
        max-width: 260px;
        border-radius: 999px;
    }

    .calendar-loading {
        position: absolute;
        inset: 12px;
        display: none;
        border-radius: 20px;
        background: linear-gradient(90deg, rgba(255,255,255,0.4), rgba(255,255,255,0.92), rgba(255,255,255,0.4));
        background-size: 220% 100%;
        animation: shimmer 1.2s linear infinite;
        z-index: 10;
    }

    .calendar-loading.active {
        display: block;
    }

    @keyframes shimmer {
        from { background-position: 220% 0; }
        to { background-position: -220% 0; }
    }

    .fc .fc-toolbar-title {
        font-size: 1.18rem;
        font-weight: 800;
    }

    .fc .fc-button-primary {
        background: #fff;
        border: 1px solid #e5e7eb;
        color: #172033;
        border-radius: 999px;
        font-weight: 700;
    }

    .fc .fc-button-primary:hover,
    .fc .fc-button-primary:not(:disabled).fc-button-active {
        background: #1a73e8;
        border-color: #1a73e8;
        color: #fff;
    }

    .fc-event {
        border: 0;
        border-radius: 999px;
        padding: 2px 7px;
        box-shadow: 0 5px 14px rgba(15, 23, 42, 0.12);
        cursor: pointer;
    }

    body[data-theme="dark"] .calendar-panel,
    body[data-theme="dark"] .upcoming-panel {
        background: #111827;
        border-color: #263244;
    }

    body[data-theme="dark"] .event-card {
        background: #172033;
        border-color: #263244;
    }

    body[data-theme="dark"] .fc .fc-button-primary {
        background: #172033;
        color: #e5eefb;
        border-color: #263244;
    }

    @media (max-width: 1100px) {
        .calendar-user-grid {
            grid-template-columns: 1fr;
        }

        .upcoming-panel {
            position: static;
        }
    }

    @media (max-width: 700px) {
        .calendar-user-hero {
            align-items: flex-start;
            flex-direction: column;
        }

        .calendar-user-actions {
            width: 100%;
            justify-content: flex-start;
        }

        .filter-bar .form-control,
        .filter-bar .form-select {
            max-width: 100%;
            flex: 1 1 100%;
        }

        .calendar-panel {
            min-height: 620px;
            border-radius: 18px;
        }
    }
</style>

<div class="container-fluid mt-4">
    <div class="calendar-user-hero">
        <div class="calendar-user-title">
            <div class="calendar-user-icon"><i class="fas fa-calendar-days"></i></div>
            <div>
                <h1>Parish Calendar</h1>
                <p>Mass schedules, sacraments, parish activities, reservations, announcements, and feast day events.</p>
            </div>
        </div>
        <div class="calendar-user-actions">
            <button class="btn btn-outline-primary" type="button" id="todayBtn"><i class="fas fa-location-crosshairs"></i> Today</button>
            <a href="make-reservation.php" class="btn btn-primary"><i class="fas fa-calendar-plus"></i> Request Reservation</a>
        </div>
    </div>

    <div class="calendar-user-grid">
        <section class="calendar-panel">
            <div class="filter-bar">
                <input type="search" class="form-control" id="calendarSearch" placeholder="Search parish calendar">
                <select class="form-select" id="categoryFilter">
                    <option value="all">All categories</option>
                    <option value="mass">Mass</option>
                    <option value="sacramental">Sacraments</option>
                    <option value="event">Events</option>
                    <option value="reservation">Reservations</option>
                    <option value="announcement">Announcements</option>
                    <option value="meeting">Meetings</option>
                </select>
            </div>
            <div class="calendar-loading" id="calendarLoading"></div>
            <div id="userCalendar"></div>
        </section>

        <aside class="upcoming-panel">
            <div class="upcoming-header">
                <h2><i class="fas fa-clock"></i> Upcoming</h2>
                <span class="badge bg-primary"><?php echo count($upcoming_events); ?></span>
            </div>
            <div class="event-stack">
                <?php if (!empty($upcoming_events)): ?>
                    <?php foreach ($upcoming_events as $event): ?>
                        <button type="button" class="event-card text-start" style="--event-color: <?php echo e($event['color_label'] ?: '#1a73e8'); ?>"
                                data-title="<?php echo e($event['title']); ?>"
                                data-date="<?php echo e(formatDate($event['event_date'])); ?>"
                                data-time="<?php echo e(formatTime($event['start_time'])); ?><?php echo !empty($event['end_time']) ? ' - ' . e(formatTime($event['end_time'])) : ''; ?>"
                                data-location="<?php echo e($event['location'] ?: 'Parish'); ?>"
                                data-description="<?php echo e($event['description']); ?>">
                            <strong><?php echo e($event['title']); ?></strong>
                            <span><?php echo e(formatDate($event['event_date'])); ?> at <?php echo e(formatTime($event['start_time'])); ?></span><br>
                            <small><?php echo e(ucfirst($event['category'])); ?> • <?php echo e($event['location'] ?: 'Parish'); ?></small>
                        </button>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-calendar-plus fa-2x mb-2"></i>
                        <p class="mb-0">No upcoming public schedules yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</div>

<div class="modal fade" id="eventDetailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailsTitle">Event Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailsBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-primary" id="remindBtn"><i class="fas fa-bell"></i> Remind Me</button>
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Done</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
<script>
const apiUrl = '../api/calendar-events.php';
const detailsModal = new bootstrap.Modal(document.getElementById('eventDetailsModal'));
const loading = document.getElementById('calendarLoading');
let calendar;
let selectedReminder = null;
let searchTimer;

function filters() {
    const params = new URLSearchParams();
    const q = document.getElementById('calendarSearch').value.trim();
    const category = document.getElementById('categoryFilter').value;
    if (q) params.set('q', q);
    if (category !== 'all') params.set('category', category);
    return params;
}

function showDetails(data) {
    selectedReminder = data;
    document.getElementById('detailsTitle').textContent = data.title;
    document.getElementById('detailsBody').innerHTML = `
        <div class="d-grid gap-2">
            <div><strong>When:</strong> ${data.when}</div>
            <div><strong>Location:</strong> ${data.location || 'Parish'}</div>
            <div><strong>Category:</strong> ${data.category || 'Schedule'}</div>
            <p class="mb-0">${data.description || ''}</p>
        </div>`;
    detailsModal.show();
}

document.addEventListener('DOMContentLoaded', function() {
    calendar = new FullCalendar.Calendar(document.getElementById('userCalendar'), {
        initialView: window.innerWidth < 700 ? 'listWeek' : 'dayGridMonth',
        height: 'auto',
        nowIndicator: true,
        dayMaxEvents: 3,
        headerToolbar: {
            left: 'prev,next',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,listWeek'
        },
        buttonText: {
            month: 'Month',
            week: 'Week',
            list: 'Agenda'
        },
        events: function(info, successCallback, failureCallback) {
            const params = filters();
            params.set('start', info.startStr.slice(0, 10));
            params.set('end', info.endStr.slice(0, 10));
            fetch(apiUrl + '?' + params.toString())
                .then(response => response.json())
                .then(successCallback)
                .catch(failureCallback);
        },
        loading: function(isLoading) {
            loading.classList.toggle('active', isLoading);
        },
        eventClick: function(info) {
            const props = info.event.extendedProps;
            const when = info.event.start.toLocaleString() + (info.event.end ? ' - ' + info.event.end.toLocaleTimeString() : '');
            showDetails({
                title: info.event.title,
                when,
                location: props.location || 'Parish',
                category: props.category || 'Schedule',
                description: props.description || '',
                start: info.event.start
            });
        }
    });
    calendar.render();
    setInterval(() => calendar.refetchEvents(), 30000);
});

document.getElementById('todayBtn').addEventListener('click', () => calendar.today());
document.getElementById('categoryFilter').addEventListener('change', () => calendar.refetchEvents());
document.getElementById('calendarSearch').addEventListener('input', function() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => calendar.refetchEvents(), 280);
});

document.querySelectorAll('.event-card').forEach(card => {
    card.addEventListener('click', function() {
        showDetails({
            title: this.dataset.title,
            when: `${this.dataset.date} ${this.dataset.time}`,
            location: this.dataset.location,
            category: 'Upcoming',
            description: this.dataset.description,
            start: new Date()
        });
    });
});

document.getElementById('remindBtn').addEventListener('click', function() {
    if (!selectedReminder) {
        return;
    }

    const reminders = JSON.parse(localStorage.getItem('parishCalendarReminders') || '[]');
    reminders.push({
        title: selectedReminder.title,
        when: selectedReminder.when,
        savedAt: new Date().toISOString()
    });
    localStorage.setItem('parishCalendarReminders', JSON.stringify(reminders.slice(-25)));
    this.innerHTML = '<i class="fas fa-check"></i> Reminder Saved';
    setTimeout(() => this.innerHTML = '<i class="fas fa-bell"></i> Remind Me', 1800);
});
</script>

<?php include '../templates/footer.php'; ?>
