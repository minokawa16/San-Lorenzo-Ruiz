<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$user_id = intval($_SESSION['user_id']);
$user_name = $_SESSION['fullname'] ?? 'User';

$request_counts = [
    'total' => 0,
    'pending' => 0,
    'approved' => 0,
    'completed' => 0,
];
$reservation_counts = [
    'total' => 0,
    'pending' => 0,
];
$recent_requests = [];
$upcoming_reservations = [];
$announcements = [];
$unread_count = getUnreadNotificationCount($conn, $user_id);

$stmt = $conn->prepare("SELECT status, COUNT(*) AS count FROM requests WHERE user_id = ? GROUP BY status");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $status = $row['status'];
        $count = intval($row['count']);
        $request_counts['total'] += $count;
        if (isset($request_counts[$status])) {
            $request_counts[$status] = $count;
        }
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT status, COUNT(*) AS count FROM reservations WHERE user_id = ? GROUP BY status");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $reservation_counts['total'] += intval($row['count']);
        if ($row['status'] === 'pending') {
            $reservation_counts['pending'] = intval($row['count']);
        }
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT request_id, request_type, status, reference_number, date_requested FROM requests WHERE user_id = ? ORDER BY date_requested DESC LIMIT 5");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $recent_requests[] = $row;
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT reservation_id, reservation_type, event_date, event_time, status FROM reservations WHERE user_id = ? ORDER BY event_date DESC, event_time DESC LIMIT 5");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $upcoming_reservations[] = $row;
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT announcement_id, title, content, type, published_date FROM announcements WHERE status = 'active' AND (expiry_date IS NULL OR expiry_date >= NOW()) ORDER BY published_date DESC LIMIT 4");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
    $stmt->close();
}

$page_title = 'User Dashboard';
?>
<?php include '../templates/header.php'; ?>

<section class="dashboard-hero">
    <div class="hero-text">
        <h1>Welcome back, <?php echo e($user_name); ?></h1>
        <p>Track requests, reserve parish services, and keep up with parish updates.</p>
    </div>
    <div class="hero-quote">
        Your parish services are gathered here for quick, steady access.
    </div>
</section>

<section class="stats-grid">
    <div class="stat-card-modern">
        <div class="stat-info">
            <span>Total Requests</span>
            <h3><span data-count="<?php echo intval($request_counts['total']); ?>"><?php echo $request_counts['total']; ?></span></h3>
        </div>
        <div class="stat-icon"><i class="fas fa-layer-group"></i></div>
    </div>
    <div class="stat-card-modern">
        <div class="stat-info">
            <span>Pending Review</span>
            <h3><span data-count="<?php echo intval($request_counts['pending'] + $reservation_counts['pending']); ?>"><?php echo $request_counts['pending'] + $reservation_counts['pending']; ?></span></h3>
        </div>
        <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
    </div>
    <div class="stat-card-modern">
        <div class="stat-info">
            <span>Approved</span>
            <h3><span data-count="<?php echo intval($request_counts['approved']); ?>"><?php echo $request_counts['approved']; ?></span></h3>
        </div>
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
    </div>
    <div class="stat-card-modern">
        <div class="stat-info">
            <span>Notifications</span>
            <h3><span data-count="<?php echo intval($unread_count); ?>"><?php echo $unread_count; ?></span></h3>
        </div>
        <div class="stat-icon"><i class="fas fa-bell"></i></div>
    </div>
</section>

<section class="ai-insights mb-4">
    <div class="card-panel">
        <div class="d-flex justify-content-between align-items-center">
            <div class="panel-title"><i class="fas fa-robot"></i> AI Quick Insights</div>
            <small class="text-muted">Updated now</small>
        </div>
        <div class="mt-3">
            <p class="text-muted">No insights yet. Connect analytics or enable AI features to see suggestions here.</p>
        </div>
    </div>
</section>

<section class="dashboard-grid">
    <div class="card-panel">
        <div class="panel-title"><i class="fas fa-bolt"></i> Quick Actions</div>
        <div class="quick-actions">
            <a href="request-certificate.php"><i class="fas fa-certificate"></i> Certificate</a>
            <a href="request-blessing.php"><i class="fas fa-hands-praying"></i> Blessing</a>
            <a href="make-reservation.php"><i class="fas fa-calendar-check"></i> Reservation</a>
            <a href="view-schedule.php"><i class="fas fa-calendar-days"></i> Schedule</a>
        </div>
    </div>

    <div class="card-panel">
        <div class="panel-title"><i class="fas fa-bullhorn"></i> Latest Announcements</div>
        <?php if (!empty($announcements)): ?>
            <div class="timeline">
                <?php foreach ($announcements as $announcement): ?>
                    <div class="timeline-item active">
                        <span class="timeline-dot"></span>
                        <div>
                            <strong><?php echo e($announcement['title']); ?></strong><br>
                            <small class="text-muted"><?php echo e(ucfirst($announcement['type'])); ?> - <?php echo formatDate($announcement['published_date']); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <a href="announcements.php" class="btn btn-outline-primary btn-sm mt-3">View all announcements</a>
        <?php else: ?>
            <p class="text-muted mb-0">No active announcements right now.</p>
        <?php endif; ?>
    </div>
</section>

<section class="dashboard-grid">
    <div class="card-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="panel-title mb-0"><i class="fas fa-list-check"></i> Recent Requests</div>
            <a href="my-requests.php" class="btn btn-outline-primary btn-sm">View all</a>
        </div>
        <?php if (!empty($recent_requests)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_requests as $request): ?>
                            <tr>
                                <td><strong><?php echo e($request['reference_number']); ?></strong></td>
                                <td><?php echo e(ucfirst(str_replace('_', ' ', $request['request_type']))); ?></td>
                                <td><span class="badge bg-<?php echo getStatusBadgeClass($request['status']); ?>"><?php echo e(ucfirst($request['status'])); ?></span></td>
                                <td><a href="view-request.php?id=<?php echo intval($request['request_id']); ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted mb-0">You have not submitted a request yet.</p>
        <?php endif; ?>
    </div>

    <div class="card-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="panel-title mb-0"><i class="fas fa-calendar-check"></i> Reservations</div>
            <a href="make-reservation.php" class="btn btn-outline-primary btn-sm">New reservation</a>
        </div>
        <?php if (!empty($upcoming_reservations)): ?>
            <div class="timeline">
                <?php foreach ($upcoming_reservations as $reservation): ?>
                    <div class="timeline-item">
                        <span class="timeline-dot"></span>
                        <div>
                            <strong><?php echo e(ucfirst(str_replace('_', ' ', $reservation['reservation_type']))); ?></strong>
                            <span class="badge bg-<?php echo getStatusBadgeClass($reservation['status']); ?>"><?php echo e(ucfirst($reservation['status'])); ?></span><br>
                            <small class="text-muted"><?php echo formatDate($reservation['event_date']); ?> <?php echo e(substr((string) $reservation['event_time'], 0, 5)); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted mb-0">No reservations submitted yet.</p>
        <?php endif; ?>
    </div>
</section>

<?php include '../templates/footer.php'; ?>
