<?php
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireLogin();
if (!isUser()) {
    redirect('../auth/login.php');
}

$page_title = 'Request Blessing';
$user_id = intval($_SESSION['user_id']);
$error = '';
$success = '';

$breadcrumbs = [
    'Dashboard' => 'index.php',
    'Request Blessing' => null
];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $allowed_types = ['house_blessing', 'car_blessing'];
    $request_type = $_POST['request_type'] ?? '';
    $preferred_date = trim($_POST['preferred_date'] ?? '');
    $preferred_time = trim($_POST['preferred_time'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $details = trim($_POST['details'] ?? '');

    if (!in_array($request_type, $allowed_types, true)) {
        $error = 'Please choose a blessing type.';
    } elseif ($location === '') {
        $error = 'Please provide the blessing location.';
    } else {
        $description_parts = [
            'Preferred date: ' . ($preferred_date ?: 'Not specified'),
            'Preferred time: ' . ($preferred_time ?: 'Not specified'),
            'Location: ' . $location,
            'Details: ' . ($details ?: 'None'),
        ];
        $description = implode("\n", $description_parts);
        $reference_number = generateReferenceNumber();
        $status = 'pending';

        $stmt = $conn->prepare("INSERT INTO requests (user_id, request_type, description, status, reference_number) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            $error = 'Unable to prepare your blessing request. Please contact the parish office.';
        } else {
            $stmt->bind_param('issss', $user_id, $request_type, $description, $status, $reference_number);
            if ($stmt->execute()) {
                $request_id = $conn->insert_id;
                createAuditLog($conn, $user_id, 'CREATE_REQUEST', 'requests', $request_id);
                createNotification($conn, $user_id, 'Blessing Request Created', 'Your blessing request has been submitted with reference: ' . $reference_number);
                $success = 'Blessing request submitted successfully! Reference: ' . $reference_number;
            } else {
                $error = 'Error submitting blessing request: ' . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>
<?php include '../templates/header.php'; ?>

<?php include '../includes/breadcrumb.php'; ?>
<?php include '../includes/back_button.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-hands-praying"></i> Request a Blessing</h5>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <?php echo e($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?php echo e($success); ?>
                            <a href="my-requests.php" class="alert-link">Track it in My Requests</a>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="request_type" class="form-label">Blessing Type</label>
                            <select class="form-select form-select-lg" id="request_type" name="request_type" required>
                                <option value="">-- Select Blessing Type --</option>
                                <option value="house_blessing">House Blessing</option>
                                <option value="car_blessing">Car Blessing</option>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="preferred_date" class="form-label">Preferred Date</label>
                                <input type="date" class="form-control" id="preferred_date" name="preferred_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="preferred_time" class="form-label">Preferred Time</label>
                                <input type="time" class="form-control" id="preferred_time" name="preferred_time">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location" placeholder="Complete address or parish location" required>
                        </div>

                        <div class="mb-3">
                            <label for="details" class="form-label">Additional Details</label>
                            <textarea class="form-control" id="details" name="details" rows="4" placeholder="Tell us anything the parish office should know."></textarea>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            Parish staff will review your request and confirm availability.
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Submit Blessing Request</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
