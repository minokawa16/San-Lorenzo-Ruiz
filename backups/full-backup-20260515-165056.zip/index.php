<?php
/**
 * Homepage
 * AI-Powered Parish Request and Sacramental Records Management System
 */

include 'includes/session.php';
include 'includes/helpers.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: users/index.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parish Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --navy: #15354d;
            --navy-deep: #0d2436;
            --navy-soft: #245a7c;
            --gold: #d4af37;
            --gold-soft: #f2d77b;
            --white: #ffffff;
            --gray: #eef3f7;
            --muted: #d7e3ed;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--white);
            background:
                radial-gradient(circle at 16% 18%, rgba(212, 175, 55, 0.18), transparent 28%),
                radial-gradient(circle at 84% 12%, rgba(255, 255, 255, 0.12), transparent 24%),
                linear-gradient(135deg, var(--navy-deep) 0%, var(--navy) 48%, var(--navy-soft) 100%);
            overflow-x: hidden;
        }

        .site-shell {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .site-shell::before {
            content: "";
            position: absolute;
            inset: 0;
            background-image:
                linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
            background-size: 44px 44px;
            pointer-events: none;
            mask-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.9), transparent 86%);
        }

        .navbar {
            position: relative;
            z-index: 2;
            padding: 18px 0;
            background: rgba(13, 36, 54, 0.6);
            backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: var(--white);
            font-weight: 700;
            text-decoration: none;
        }

        .brand-mark {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: var(--navy);
            background: linear-gradient(135deg, var(--gold-soft), var(--gold));
            box-shadow: 0 10px 30px rgba(212, 175, 55, 0.25);
        }

        .nav-actions {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .hero {
            position: relative;
            z-index: 1;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 72px 20px 82px;
            text-align: center;
        }

        .hero-content {
            width: min(900px, 100%);
            animation: fadeUp 0.75s ease both;
        }

        .hero-icon {
            width: 108px;
            height: 108px;
            margin: 0 auto 28px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(145deg, rgba(255, 255, 255, 0.95), rgba(238, 243, 247, 0.9));
            color: var(--gold);
            box-shadow: 0 24px 70px rgba(0, 0, 0, 0.22);
            position: relative;
        }

        .hero-icon::after {
            content: "";
            position: absolute;
            inset: -12px;
            border: 1px solid rgba(242, 215, 123, 0.38);
            border-radius: 38px;
        }

        .hero-icon i {
            font-size: 3.6rem;
            filter: drop-shadow(0 5px 10px rgba(13, 36, 54, 0.16));
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 7px 14px;
            margin-bottom: 18px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.18);
            color: var(--gold-soft);
            font-size: 0.88rem;
            font-weight: 700;
        }

        .hero h1 {
            margin: 0;
            font-size: clamp(2.4rem, 6vw, 4.7rem);
            line-height: 1.05;
            font-weight: 800;
            letter-spacing: 0;
            text-shadow: 0 8px 28px rgba(0, 0, 0, 0.24);
        }

        .hero-subtitle {
            max-width: 720px;
            margin: 22px auto 0;
            color: var(--muted);
            font-size: clamp(1rem, 2vw, 1.22rem);
            line-height: 1.75;
        }

        .hero-actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 14px;
            margin-top: 34px;
        }

        .hero-btn {
            min-width: 154px;
            min-height: 52px;
            border-radius: 999px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 13px 24px;
            font-weight: 800;
            text-decoration: none;
            transition: transform 0.25s ease, box-shadow 0.25s ease, background 0.25s ease, color 0.25s ease;
        }

        .hero-btn:hover {
            transform: translateY(-3px);
        }

        .hero-btn.primary {
            background: var(--white);
            color: var(--navy);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.22);
        }

        .hero-btn.primary:hover {
            background: var(--gold-soft);
            color: var(--navy-deep);
        }

        .hero-btn.gold {
            background: linear-gradient(135deg, var(--gold-soft), var(--gold));
            color: var(--navy-deep);
            box-shadow: 0 18px 42px rgba(212, 175, 55, 0.25);
        }

        .hero-btn.outline {
            border: 1px solid rgba(255, 255, 255, 0.54);
            color: var(--white);
            background: rgba(255, 255, 255, 0.05);
        }

        .hero-btn.outline:hover {
            background: rgba(255, 255, 255, 0.14);
            border-color: var(--gold-soft);
            color: var(--white);
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(18px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 640px) {
            .navbar {
                padding: 14px 0;
            }

            .navbar .container {
                gap: 14px;
            }

            .nav-actions {
                width: 100%;
                justify-content: center;
            }

            .hero {
                padding-top: 48px;
            }

            .hero-icon {
                width: 92px;
                height: 92px;
                border-radius: 24px;
            }

            .hero-icon i {
                font-size: 3rem;
            }

            .hero-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .hero-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="site-shell">
        <nav class="navbar">
            <div class="container d-flex flex-wrap align-items-center justify-content-between">
                <a class="navbar-brand" href="index.php">
                    <span class="brand-mark"><i class="fas fa-church"></i></span>
                    <span>Parish System</span>
                </a>
                <div class="nav-actions">
                    <a href="auth/login.php" class="hero-btn outline">
                        <i class="fas fa-right-to-bracket"></i> Login
                    </a>
                    <a href="auth/register.php" class="hero-btn gold">
                        <i class="fas fa-user-plus"></i> Register
                    </a>
                </div>
            </div>
        </nav>

        <main class="hero">
            <section class="hero-content" aria-labelledby="page-title">
                <div class="hero-icon" aria-hidden="true">
                    <i class="fas fa-church"></i>
                </div>
                <div class="eyebrow">
                    <i class="fas fa-cross"></i>
                    Parish digital services
                </div>
                <h1 id="page-title">Parish Management System</h1>
                <p class="hero-subtitle">
                    A secure web-based platform for parish requests, sacramental records, reservations, announcements, and community services.
                </p>
                <div class="hero-actions">
                    <a href="auth/login.php" class="hero-btn primary">
                        <i class="fas fa-right-to-bracket"></i> Login
                    </a>
                    <a href="auth/register.php" class="hero-btn gold">
                        <i class="fas fa-user-plus"></i> Register
                    </a>
                    <a href="auth/register.php" class="hero-btn outline">
                        <i class="fas fa-arrow-right"></i> Get Started
                    </a>
                </div>
            </section>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
