-- Create Parish Management System Database
CREATE DATABASE IF NOT EXISTS parish_management_system;
USE parish_management_system;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fullname VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    chapel_district VARCHAR(255),
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    profile_picture VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Requests Table
CREATE TABLE IF NOT EXISTS requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    request_type ENUM('baptismal_certificate', 'confirmation_certificate', 'first_communion_certificate', 'marriage_certificate', 'house_blessing', 'car_blessing', 'church_reservation', 'wedding_reservation', 'burial_reservation') NOT NULL,
    description TEXT,
    status ENUM('pending', 'approved', 'rejected', 'processing', 'completed') DEFAULT 'pending',
    date_requested TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    admin_response TEXT,
    reference_number VARCHAR(50) UNIQUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Baptism Records Table
CREATE TABLE IF NOT EXISTS baptism_records (
    baptism_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT,
    fullname VARCHAR(100) NOT NULL,
    birth_date DATE,
    baptism_date DATE,
    parents VARCHAR(200),
    godparents VARCHAR(200),
    priest VARCHAR(100),
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE SET NULL,
    INDEX (fullname),
    INDEX (baptism_date),
    INDEX (request_id)
);

-- First Communion Records Table
CREATE TABLE IF NOT EXISTS first_communion_records (
    communion_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT,
    fullname VARCHAR(100) NOT NULL,
    birth_date DATE,
    communion_date DATE,
    sponsor VARCHAR(100),
    priest VARCHAR(100),
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE SET NULL,
    INDEX (fullname),
    INDEX (communion_date),
    INDEX (request_id)
);

-- Confirmation Records Table
CREATE TABLE IF NOT EXISTS confirmation_records (
    confirmation_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT,
    fullname VARCHAR(100) NOT NULL,
    birth_date DATE,
    confirmation_date DATE,
    confirmation_name VARCHAR(100),
    sponsor VARCHAR(100),
    bishop_priest VARCHAR(100),
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE SET NULL,
    INDEX (fullname),
    INDEX (confirmation_date),
    INDEX (request_id)
);

-- Marriage Records Table
CREATE TABLE IF NOT EXISTS marriage_records (
    marriage_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT,
    husband_name VARCHAR(100) NOT NULL,
    wife_name VARCHAR(100) NOT NULL,
    wedding_date DATE,
    sponsors VARCHAR(200),
    officiating_priest VARCHAR(100),
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE SET NULL,
    INDEX (husband_name),
    INDEX (wife_name),
    INDEX (wedding_date),
    INDEX (request_id)
);

-- Announcements Table
CREATE TABLE IF NOT EXISTS announcements (
    announcement_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    image_path VARCHAR(255),
    type ENUM('announcement', 'schedule', 'event', 'obituary') DEFAULT 'announcement',
    published_by INT NOT NULL,
    published_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATETIME,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (published_by) REFERENCES users(id),
    INDEX (published_date)
);

-- Reservations Table
CREATE TABLE IF NOT EXISTS reservations (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    reservation_type ENUM('wedding', 'baptism', 'confirmation', 'burial', 'church_venue') NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME,
    event_details TEXT,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (event_date),
    UNIQUE KEY unique_reservation (reservation_type, event_date, event_time)
);

-- Schedule Events Table
CREATE TABLE IF NOT EXISTS schedule_events (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NULL,
    location VARCHAR(150),
    category VARCHAR(50) DEFAULT 'event',
    priority VARCHAR(20) DEFAULT 'normal',
    color_label VARCHAR(20) DEFAULT '#1a73e8',
    recurrence_rule VARCHAR(100) DEFAULT 'none',
    assigned_personnel VARCHAR(150),
    visibility ENUM('public', 'private') DEFAULT 'public',
    approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
    status ENUM('active', 'upcoming', 'ongoing', 'finished', 'cancelled') DEFAULT 'upcoming',
    reminder_minutes INT DEFAULT 30,
    notify_email TINYINT(1) DEFAULT 0,
    notify_sms TINYINT(1) DEFAULT 0,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_schedule_date (event_date),
    INDEX idx_schedule_status_date (status, event_date, start_time)
);

-- Certificate Templates Table
CREATE TABLE IF NOT EXISTS certificate_templates (
    template_id INT PRIMARY KEY AUTO_INCREMENT,
    certificate_type ENUM('baptismal', 'confirmation', 'first_communion', 'marriage') NOT NULL,
    template_content LONGTEXT NOT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (user_id, is_read)
);

-- Audit Log Table
CREATE TABLE IF NOT EXISTS audit_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_value LONGTEXT,
    new_value LONGTEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX (created_at)
);

-- Create default admin user (password: admin123)
INSERT INTO users (fullname, phone_number, email, chapel_district, password, role, status) 
VALUES ('Admin', '555-0000', 'admin@gmail.com', 'Main Chapel', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36DxYXpm', 'admin', 'active')
ON DUPLICATE KEY UPDATE id=id;

-- Create default certificate templates
INSERT INTO certificate_templates (certificate_type, template_content, created_by) 
VALUES 
    ('baptismal', '<h1>Baptismal Certificate</h1><p>Full Name: {{fullname}}</p><p>Birth Date: {{birth_date}}</p><p>Baptism Date: {{baptism_date}}</p>', 1),
    ('confirmation', '<h1>Confirmation Certificate</h1><p>Full Name: {{fullname}}</p><p>Confirmation Date: {{confirmation_date}}</p>', 1),
    ('first_communion', '<h1>First Communion Certificate</h1><p>Full Name: {{fullname}}</p><p>Communion Date: {{communion_date}}</p>', 1),
    ('marriage', '<h1>Marriage Certificate</h1><p>Groom: {{husband_name}}</p><p>Bride: {{wife_name}}</p><p>Wedding Date: {{wedding_date}}</p>', 1)
ON DUPLICATE KEY UPDATE template_id=template_id;
