Place the parish church hero/background image here:

- Path: assets/img/san_lorenzo_ruiz.jpg
- Recommended: 1920x1080 or larger, high-quality JPG or WebP.

How the system uses this image:
- Full-screen background (body.church-theme)
- Dashboard hero and login/register background

If you prefer a different filename, update `assets/css/style.css` background-image URL accordingly.