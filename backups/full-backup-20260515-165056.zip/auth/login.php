<?php
/**
 * Login Page
 * AI-Powered Parish Request and Sacramental Records Management System
 * Handles user authentication with proper password verification and security
 */

// Start session directly without session.php to avoid conflicts
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include other dependencies
include '../database/config.php';
include '../includes/helpers.php';

// Verify database connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// If already logged in, redirect to appropriate dashboard
// Check if session variables actually exist (not just the array)
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header("Location: ../admin/dashboard.php", true, 302);
    } else {
        header("Location: ../users/dashboard.php", true, 302);
    }
    exit();
}

$error = '';
$notice = isset($_GET['registered']) ? 'Account created successfully. You can now login.' : '';
$email_input = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get and sanitize input
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Store email for form repopulation (for non-sensitive display)
    $email_input = htmlspecialchars($email);
    
    // Validate input
    if (empty($email) || empty($password)) {
        $error = 'Email and password are required';
    } elseif (!isValidEmail($email)) {
        $error = 'Invalid email format';
    } else {
        // Sanitize email for database query
        $email_safe = $conn->real_escape_string($email);
        
        // Query to find user by email and active status
        $sql = "SELECT id, fullname, email, password, role, status FROM users WHERE email = '$email_safe' LIMIT 1";
        $result = $conn->query($sql);
        
        // Check if query executed successfully
        if (!$result) {
            $error = 'Database error: ' . $conn->error;
        } elseif ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Check if account is active
            if ($user['status'] !== 'active') {
                $error = 'Your account is inactive. Please contact the administrator.';
            } else {
                // Verify password using bcrypt password_verify()
                if (verifyPassword($password, $user['password'])) {
                    // Password is correct - set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    
                    // Create audit log for successful login
                    createAuditLog($conn, $user['id'], 'LOGIN', 'users', $user['id']);
                    
                    // Role-based redirection
                    if ($user['role'] == 'admin') {
                        header("Location: ../admin/dashboard.php");
                        exit();
                    } else {
                        header("Location: ../users/dashboard.php");
                        exit();
                    }
                } else {
                    // Password verification failed
                    $error = 'Invalid email or password';
                }
            }
        } else {
            // Email not found
            $error = 'Invalid email or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Parish Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="card shadow-lg border-0">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <i class="fas fa-church text-primary" style="font-size: 3rem;"></i>
                            <h2 class="mt-3">Parish System</h2>
                            <p class="text-muted">Request & Records Management</p>
                        </div>

                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?php echo e($error); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if ($notice): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fas fa-check-circle"></i> <?php echo e($notice); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control form-control-lg" id="email" name="email" value="<?php echo $email_input; ?>" required autofocus>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control form-control-lg" id="password" name="password" required>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">
                                    Remember me
                                </label>
                            </div>

                            <button type="submit" class="btn btn-primary btn-lg w-100" name="login">
                                <i class="fas fa-sign-in-alt"></i> Login
                            </button>
                        </form>

                        <hr class="my-4">

                        <div class="text-center">
                            <p class="text-muted">Don't have an account? 
                                <a href="register.php" class="text-primary fw-bold">Register here</a>
                            </p>
                        </div>

                        <div class="alert alert-info mt-3">
                            <small><strong>Demo Credentials:</strong><br>
                            Email: admin@parish.com<br>
                            Password: admin123
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
