<?php
/**
 * User Registration Page
 * AI-Powered Parish Request and Sacramental Records Management System
 * Handles user registration with proper password hashing and validation
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../database/config.php';
include '../includes/helpers.php';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header("Location: ../admin/dashboard.php", true, 302);
    } else {
        header("Location: ../users/dashboard.php", true, 302);
    }
    exit();
}

$error = '';
$success = '';
$form_data = [
    'fullname' => '',
    'phone_number' => '',
    'email' => '',
    'chapel_district' => ''
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = isset($_POST['fullname']) ? sanitize($_POST['fullname']) : '';
    $phone_number = isset($_POST['phone_number']) ? sanitize($_POST['phone_number']) : '';
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : '';
    $chapel_district = isset($_POST['chapel_district']) ? sanitize($_POST['chapel_district']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $form_data = [
        'fullname' => $fullname,
        'phone_number' => $phone_number,
        'email' => $email,
        'chapel_district' => $chapel_district
    ];

    if (empty($fullname) || empty($phone_number) || empty($email) || empty($chapel_district) || empty($password) || empty($confirm_password)) {
        $error = 'Please complete all required fields.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please enter a valid email address.';
    } elseif (!preg_match('/@gmail\.com$/i', $email)) {
        $error = 'Please use a Gmail address ending in @gmail.com.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $email_safe = $conn->real_escape_string($email);
        $sql = "SELECT id FROM users WHERE email = '$email_safe' LIMIT 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $error = 'This Gmail address is already registered.';
        } else {
            $hashed_password = hashPassword($password);

            $fullname_safe = $conn->real_escape_string($fullname);
            $phone_number_safe = $conn->real_escape_string($phone_number);
            $chapel_district_safe = $conn->real_escape_string($chapel_district);

            $sql = "INSERT INTO users (fullname, phone_number, email, chapel_district, password, role, status)
                    VALUES ('$fullname_safe', '$phone_number_safe', '$email_safe', '$chapel_district_safe', '$hashed_password', 'user', 'active')";

            if ($conn->query($sql)) {
                $success = 'Account created successfully. Redirecting to login...';
                $form_data = [
                    'fullname' => '',
                    'phone_number' => '',
                    'email' => '',
                    'chapel_district' => ''
                ];

                $new_user_id = $conn->insert_id;
                createAuditLog($conn, $new_user_id, 'REGISTRATION', 'users', $new_user_id);

                echo '<script>
                    setTimeout(function() {
                        window.location.href = "login.php?registered=1";
                    }, 2200);
                </script>';
            } else {
                $error = 'Registration failed. Please try again later.';
            }
        }
    }
}

$chapel_options = [
    'Main Chapel',
    'North District',
    'South District',
    'East District',
    'West District',
    'Central Parish'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Parish Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --register-navy: #0b1f3a;
            --register-navy-soft: #14365d;
            --register-gold: #d4af37;
            --register-gold-soft: #f4dc82;
            --register-gray: #eef3f7;
            --register-muted: #5d6d7f;
            --register-danger: #b42318;
            --register-success: #0f7a4f;
        }

        body.register-page {
            min-height: 100vh;
            margin: 0;
            color: #172033;
            background: var(--register-navy);
            overflow-x: hidden;
        }

        body.register-page::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -3;
            background-image:
                linear-gradient(135deg, rgba(11, 31, 58, 0.24), rgba(11, 31, 58, 0.1)),
                url("../assets/img/san-lorenzo-ruiz-church.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            filter: brightness(1.06) contrast(1.12) saturate(1.08);
            transform: scale(1.02);
        }

        body.register-page::after {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            background:
                radial-gradient(circle at 18% 18%, rgba(212, 175, 55, 0.24), transparent 26%),
                radial-gradient(circle at 82% 12%, rgba(255, 255, 255, 0.15), transparent 24%),
                linear-gradient(135deg, rgba(11, 31, 58, 0.84) 0%, rgba(11, 31, 58, 0.62) 48%, rgba(6, 16, 30, 0.86) 100%);
        }

        .register-shell {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 38px 18px;
            overflow: hidden;
        }

        .register-shell::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: 0;
            background-image:
                radial-gradient(circle, rgba(255, 255, 255, 0.2) 1px, transparent 1.8px),
                radial-gradient(circle, rgba(212, 175, 55, 0.18) 1px, transparent 2px);
            background-position: 0 0, 38px 52px;
            background-size: 92px 92px, 126px 126px;
            opacity: 0.45;
            animation: particleDrift 18s linear infinite;
            pointer-events: none;
        }

        .register-shell::after {
            content: "\f684  \f654  \f2cd";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            position: absolute;
            inset: auto 4vw 4vh auto;
            z-index: 0;
            color: rgba(255, 255, 255, 0.08);
            font-size: clamp(2.4rem, 8vw, 6rem);
            letter-spacing: 24px;
            pointer-events: none;
        }

        .register-card {
            position: relative;
            z-index: 1;
            width: min(100%, 640px);
            max-height: calc(100vh - 42px);
            overflow-y: auto;
            background: linear-gradient(145deg, rgba(255, 255, 255, 0.88), rgba(255, 255, 255, 0.72));
            border: 1px solid rgba(255, 255, 255, 0.48);
            border-radius: 28px;
            box-shadow:
                0 28px 80px rgba(0, 0, 0, 0.34),
                0 0 0 1px rgba(212, 175, 55, 0.16),
                0 0 44px rgba(212, 175, 55, 0.16);
            padding: clamp(22px, 4vw, 38px);
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
            animation: fadeUp 0.78s cubic-bezier(0.2, 0.8, 0.2, 1) both;
        }

        .register-card::before {
            content: "";
            position: absolute;
            inset: 12px;
            z-index: -1;
            border-radius: 22px;
            background:
                radial-gradient(circle at top left, rgba(212, 175, 55, 0.18), transparent 32%),
                linear-gradient(135deg, rgba(255, 255, 255, 0.18), transparent);
        }

        .register-card-header {
            text-align: center;
            margin-bottom: 22px;
        }

        .register-card-icon {
            width: 68px;
            height: 68px;
            margin: 0 auto 14px;
            border-radius: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--register-gold-soft), var(--register-gold));
            color: var(--register-navy);
            font-size: 1.9rem;
            box-shadow: 0 18px 40px rgba(212, 175, 55, 0.28);
            text-decoration: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .register-card-icon:hover {
            color: var(--register-navy);
            transform: translateY(-2px);
            box-shadow: 0 22px 46px rgba(212, 175, 55, 0.36);
        }

        .register-card h2 {
            margin: 0;
            font-weight: 850;
            color: var(--register-navy);
            letter-spacing: 0;
            font-size: clamp(1.65rem, 4vw, 2.15rem);
        }

        .register-card-header p {
            color: var(--register-muted);
            margin: 8px 0 0;
            line-height: 1.55;
        }

        .community-quote {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0 0 20px;
            padding: 12px 14px;
            border-radius: 18px;
            color: #203246;
            background: rgba(11, 31, 58, 0.06);
            border: 1px solid rgba(212, 175, 55, 0.18);
            font-size: 0.9rem;
            line-height: 1.45;
        }

        .community-quote i {
            color: var(--register-gold);
        }

        .registration-form {
            display: grid;
            gap: 14px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .field-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .field-group.full {
            grid-column: 1 / -1;
        }

        .field-label {
            color: var(--register-navy);
            font-weight: 800;
            font-size: 0.9rem;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap .field-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--register-muted);
            pointer-events: none;
            width: 18px;
            text-align: center;
        }

        .register-card .form-control,
        .register-card .form-select {
            width: 100%;
            min-height: 50px;
            border-radius: 15px;
            border: 1px solid rgba(219, 228, 238, 0.95);
            padding: 12px 16px 12px 46px;
            background-color: rgba(255, 255, 255, 0.88);
            color: #172033;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease, background 0.2s ease;
        }

        .register-card .form-select {
            padding-right: 42px;
        }

        .register-card .form-control:focus,
        .register-card .form-select:focus {
            border-color: var(--register-gold);
            background: #ffffff;
            box-shadow:
                0 0 0 4px rgba(212, 175, 55, 0.2),
                0 12px 26px rgba(11, 31, 58, 0.12);
            transform: translateY(-1px);
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 12px;
            background: transparent;
            color: var(--register-muted);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease, color 0.2s ease;
        }

        .password-toggle:hover {
            background: rgba(11, 31, 58, 0.08);
            color: var(--register-navy);
        }

        .input-wrap.password .form-control {
            padding-right: 54px;
        }

        .field-message {
            min-height: 18px;
            color: var(--register-danger);
            font-size: 0.82rem;
            font-weight: 700;
        }

        .form-hint {
            color: var(--register-muted);
            font-size: 0.82rem;
            margin-top: -2px;
        }

        .is-invalid-field {
            border-color: #f04438 !important;
            box-shadow: 0 0 0 4px rgba(240, 68, 56, 0.12) !important;
        }

        .auth-alert {
            border: none;
            border-radius: 18px;
            box-shadow: none;
            font-weight: 700;
        }

        .auth-alert.alert-danger {
            color: var(--register-danger);
            background: #fff1f0;
        }

        .auth-alert.alert-success {
            color: var(--register-success);
            background: #ecfdf3;
        }

        .submit-btn {
            min-height: 54px;
            border: none;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--register-navy) 0%, var(--register-navy-soft) 48%, var(--register-gold) 100%);
            color: #ffffff;
            font-weight: 850;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow:
                0 16px 36px rgba(11, 31, 58, 0.28),
                0 0 26px rgba(212, 175, 55, 0.2);
            transition: transform 0.22s ease, box-shadow 0.22s ease, opacity 0.22s ease, filter 0.22s ease;
        }

        .submit-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            filter: brightness(1.04);
            box-shadow:
                0 20px 44px rgba(11, 31, 58, 0.34),
                0 0 34px rgba(212, 175, 55, 0.36);
        }

        .submit-btn:disabled {
            cursor: not-allowed;
            opacity: 0.78;
        }

        .spinner {
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255, 255, 255, 0.45);
            border-top-color: #ffffff;
            border-radius: 50%;
            animation: spin 0.75s linear infinite;
            display: none;
        }

        .submit-btn.is-loading .spinner {
            display: inline-block;
        }

        .submit-btn.is-loading .submit-icon {
            display: none;
        }

        .login-link {
            text-align: center;
            color: #425265;
            margin: 20px 0 0;
        }

        .login-link a {
            color: var(--register-navy);
            font-weight: 850;
            text-decoration: none;
        }

        .login-link a:hover {
            color: #0b4f78;
            text-decoration: underline;
        }

        .toast-stack {
            position: fixed;
            z-index: 20;
            top: 20px;
            right: 20px;
            display: grid;
            gap: 12px;
            width: min(360px, calc(100vw - 28px));
        }

        .auth-toast {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 14px 16px;
            border-radius: 18px;
            color: #ffffff;
            background: rgba(11, 31, 58, 0.86);
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(18px);
            animation: toastIn 0.35s ease both;
        }

        .auth-toast.success i {
            color: #87efac;
        }

        .auth-toast.error i {
            color: #fecaca;
        }

        .auth-toast strong {
            display: block;
            line-height: 1.2;
        }

        .auth-toast span {
            display: block;
            color: rgba(255, 255, 255, 0.78);
            font-size: 0.88rem;
            margin-top: 2px;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(22px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes toastIn {
            from {
                opacity: 0;
                transform: translateX(14px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes particleDrift {
            from {
                background-position: 0 0, 38px 52px;
            }
            to {
                background-position: 92px 92px, 164px 178px;
            }
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
            }
        }

        @media (max-width: 640px) {
            .register-shell {
                align-items: flex-start;
                padding: 16px 10px;
            }

            .register-card {
                max-height: none;
                border-radius: 24px;
                padding: 22px 16px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .toast-stack {
                top: 12px;
                right: 14px;
                left: 14px;
                width: auto;
            }
        }
    </style>
</head>
<body class="register-page">
    <div class="toast-stack" id="toastStack" aria-live="polite" aria-atomic="true">
        <?php if ($error): ?>
            <div class="auth-toast error" role="alert">
                <i class="fas fa-circle-exclamation"></i>
                <div>
                    <strong>Registration needs attention</strong>
                    <span><?php echo e($error); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="auth-toast success" role="status">
                <i class="fas fa-circle-check"></i>
                <div>
                    <strong>Account created</strong>
                    <span><?php echo e($success); ?></span>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <main class="register-shell">
        <section class="register-card" aria-label="Registration form">
            <div class="register-card-header">
                <a href="../index.php" class="register-card-icon" aria-label="Back to Parish System homepage">
                    <i class="fas fa-church"></i>
                </a>
                <h2>Create Your Parish Account</h2>
                <p>Register to access parish requests, sacramental records, schedules, and church services.</p>
            </div>

            <div class="community-quote">
                <i class="fas fa-cross"></i>
                <span>Welcome to San Lorenzo Ruiz Catholic Church. One community, one faith, one service portal.</span>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger auth-alert alert-dismissible fade show" role="alert">
                    <i class="fas fa-circle-exclamation"></i> <?php echo e($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success auth-alert alert-dismissible fade show" role="alert">
                    <i class="fas fa-circle-check"></i> <?php echo e($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="registration-form" id="registrationForm" novalidate>
                <div class="form-grid">
                    <div class="field-group">
                        <label for="fullname" class="field-label">Full Name</label>
                        <div class="input-wrap">
                            <i class="fas fa-user field-icon"></i>
                            <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo e($form_data['fullname']); ?>" autocomplete="name" required autofocus>
                        </div>
                        <div class="field-message" data-error-for="fullname"></div>
                    </div>

                    <div class="field-group">
                        <label for="phone_number" class="field-label">Phone Number</label>
                        <div class="input-wrap">
                            <i class="fas fa-phone field-icon"></i>
                            <input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?php echo e($form_data['phone_number']); ?>" autocomplete="tel" placeholder="09XXXXXXXXX" required>
                        </div>
                        <div class="field-message" data-error-for="phone_number"></div>
                    </div>

                    <div class="field-group">
                        <label for="email" class="field-label">Gmail Address</label>
                        <div class="input-wrap">
                            <i class="fas fa-envelope field-icon"></i>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($form_data['email']); ?>" autocomplete="email" placeholder="name@gmail.com" required>
                        </div>
                        <div class="field-message" data-error-for="email"></div>
                    </div>

                    <div class="field-group">
                        <label for="chapel_district" class="field-label">Chapel/District</label>
                        <div class="input-wrap">
                            <i class="fas fa-location-dot field-icon"></i>
                            <select class="form-select" id="chapel_district" name="chapel_district" required>
                                <option value="">Select your Chapel/District</option>
                                <?php foreach ($chapel_options as $option): ?>
                                    <option value="<?php echo e($option); ?>" <?php echo $form_data['chapel_district'] === $option ? 'selected' : ''; ?>>
                                        <?php echo e($option); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field-message" data-error-for="chapel_district"></div>
                    </div>

                    <div class="field-group">
                        <label for="password" class="field-label">Password</label>
                        <div class="input-wrap password">
                            <i class="fas fa-lock field-icon"></i>
                            <input type="password" class="form-control" id="password" name="password" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password="password" aria-label="Show password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-hint">Use at least 8 characters.</div>
                        <div class="field-message" data-error-for="password"></div>
                    </div>

                    <div class="field-group">
                        <label for="confirm_password" class="field-label">Confirm Password</label>
                        <div class="input-wrap password">
                            <i class="fas fa-key field-icon"></i>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password="confirm_password" aria-label="Show confirm password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="field-message" data-error-for="confirm_password"></div>
                    </div>
                </div>

                <button type="submit" class="submit-btn" id="registerSubmit" <?php echo $success ? 'disabled' : ''; ?>>
                    <span class="spinner" aria-hidden="true"></span>
                    <i class="fas fa-user-check submit-icon"></i>
                    <span class="submit-text"><?php echo $success ? 'Account Created' : 'Create Account'; ?></span>
                </button>
            </form>

            <p class="login-link">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        </section>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const form = document.getElementById('registrationForm');
        const submitButton = document.getElementById('registerSubmit');
        const submitText = submitButton.querySelector('.submit-text');

        const fields = {
            fullname: document.getElementById('fullname'),
            phone_number: document.getElementById('phone_number'),
            email: document.getElementById('email'),
            chapel_district: document.getElementById('chapel_district'),
            password: document.getElementById('password'),
            confirm_password: document.getElementById('confirm_password')
        };

        function setFieldError(fieldName, message) {
            const field = fields[fieldName];
            const messageTarget = document.querySelector('[data-error-for="' + fieldName + '"]');
            if (!field || !messageTarget) {
                return;
            }

            field.classList.toggle('is-invalid-field', Boolean(message));
            messageTarget.textContent = message || '';
        }

        function validateForm() {
            let isValid = true;
            const emailPattern = /^[^\s@]+@gmail\.com$/i;

            Object.keys(fields).forEach((fieldName) => setFieldError(fieldName, ''));

            if (!fields.fullname.value.trim()) {
                setFieldError('fullname', 'Full name is required.');
                isValid = false;
            }

            if (!fields.phone_number.value.trim()) {
                setFieldError('phone_number', 'Phone number is required.');
                isValid = false;
            }

            if (!emailPattern.test(fields.email.value.trim())) {
                setFieldError('email', 'Use a valid Gmail address.');
                isValid = false;
            }

            if (!fields.chapel_district.value) {
                setFieldError('chapel_district', 'Please select a chapel or district.');
                isValid = false;
            }

            if (fields.password.value.length < 8) {
                setFieldError('password', 'Password must be at least 8 characters.');
                isValid = false;
            }

            if (fields.confirm_password.value !== fields.password.value) {
                setFieldError('confirm_password', 'Passwords do not match.');
                isValid = false;
            }

            return isValid;
        }

        function showToast(type, title, message) {
            const toastStack = document.getElementById('toastStack');
            const toast = document.createElement('div');
            toast.className = 'auth-toast ' + type;
            toast.setAttribute('role', type === 'success' ? 'status' : 'alert');
            toast.innerHTML = '<i class="fas ' + (type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><div><strong>' + title + '</strong><span>' + message + '</span></div>';
            toastStack.appendChild(toast);
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(14px)';
                setTimeout(() => toast.remove(), 280);
            }, 4200);
        }

        Object.values(fields).forEach((field) => {
            field.addEventListener('input', () => {
                if (field.classList.contains('is-invalid-field')) {
                    validateForm();
                }
            });
            field.addEventListener('change', () => {
                if (field.classList.contains('is-invalid-field')) {
                    validateForm();
                }
            });
        });

        document.querySelectorAll('[data-toggle-password]').forEach((toggle) => {
            toggle.addEventListener('click', () => {
                const target = document.getElementById(toggle.dataset.togglePassword);
                const icon = toggle.querySelector('i');
                const shouldShow = target.type === 'password';
                target.type = shouldShow ? 'text' : 'password';
                icon.classList.toggle('fa-eye', !shouldShow);
                icon.classList.toggle('fa-eye-slash', shouldShow);
                toggle.setAttribute('aria-label', shouldShow ? 'Hide password' : 'Show password');
            });
        });

        form.addEventListener('submit', (event) => {
            if (!validateForm()) {
                event.preventDefault();
                showToast('error', 'Check the form', 'Please correct the highlighted fields before creating your account.');
                return;
            }

            submitButton.disabled = true;
            submitButton.classList.add('is-loading');
            submitText.textContent = 'Creating account...';
        });
    </script>
</body>
</html>
