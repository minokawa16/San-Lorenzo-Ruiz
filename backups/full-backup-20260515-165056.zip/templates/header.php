<?php
/**
 * Header Template
 * Navigation and session management
 */

// Safe session initialization - prevents duplicate session_start() warnings
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($conn)) {
    include '../database/config.php';
}
if (!function_exists('isLoggedIn')) {
    include '../includes/helpers.php';
}

$current_page = basename($_SERVER['PHP_SELF']);
$is_user_area = isLoggedIn() && !isAdmin() && (
    strpos($_SERVER['PHP_SELF'], '/users/') !== false ||
    in_array($current_page, ['profile.php', 'change-password.php'], true)
);
$unread_notification_count = 0;
$recent_header_notifications = [];
if (isLoggedIn()) {
    $unread_notification_count = getUnreadNotificationCount($conn, $_SESSION['user_id']);
    $recent_header_notifications = getRecentNotifications($conn, $_SESSION['user_id'], 5);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' : ''; ?>Parish Management System</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="<?php echo $is_user_area ? 'user-area' : ''; ?> church-theme">
    <?php if ($is_user_area): ?>
    <div class="user-shell">
        <?php include '../includes/user-sidebar.php'; ?>
        <div class="user-main">
            <header class="user-topbar">
                <div class="topbar-left">
                    <button class="topbar-toggle" id="userSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <div class="topbar-title">TUGON Parish System</div>
                </div>
                <form class="topbar-search" action="<?php echo BASE_URL; ?>users/my-requests.php" method="GET">
                    <i class="fas fa-search"></i>
                    <input type="text" name="q" placeholder="Search requests..." value="<?php echo e($_GET['q'] ?? ''); ?>">
                </form>
                <div class="topbar-actions">
                    <!-- Optional settings icon (keeps header minimal) -->
                    <button class="icon-btn" id="settingsBtn" title="Settings" type="button">
                        <i class="fas fa-cog"></i>
                    </button>
                    <button class="icon-btn" id="darkModeToggle" type="button" aria-label="Toggle dark mode">
                        <i class="fas fa-moon"></i>
                    </button>
                    <div class="dropdown">
                        <button class="profile-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="profile-avatar">
                                <?php echo strtoupper(substr($_SESSION['fullname'] ?? 'U', 0, 1)); ?>
                            </span>
                            <span class="profile-name"><?php echo sanitize($_SESSION['fullname']); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../auth/profile.php">Profile Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>
            <main class="user-content">
    <?php else: ?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo isAdmin() ? '../admin/dashboard.php' : '../index.php'; ?>">
                <i class="fas fa-church"></i> Parish System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#notificationModal">
                                <i class="fas fa-bell"></i> Notifications
                                <?php 
                                $count = getUnreadNotificationCount($conn, $_SESSION['user_id']);
                                if ($count > 0): 
                                ?>
                                    <span class="badge bg-danger"><?php echo $count; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle"></i> <?php echo sanitize($_SESSION['fullname']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="../auth/profile.php">Profile</a></li>
                                <li><a class="dropdown-item" href="../auth/profile.php">Profile Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="../auth/logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../index.php">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="page-content">
    <?php endif; ?>
