<?php
/**
 * Reports & Analytics Page
 * Admin interface for viewing system reports
 */

// Include centralized session management
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

// Require admin access
requireAdmin();

$page_title = 'Reports & Analytics';

// Set breadcrumb data
$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Reports' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <!-- Breadcrumb Navigation -->
    <?php include '../includes/breadcrumb.php'; ?>
    
    <!-- Back Button -->
    <?php include '../includes/back_button.php'; ?>

    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><i class="fas fa-chart-bar"></i> Reports & Analytics</h1>
        </div>
    </div>

    <div class="card">
        <div class="card-body text-center py-5">
            <i class="fas fa-chart-bar" style="font-size: 3rem; color: #ccc;" class="mb-3"></i>
            <h5 class="mt-3">Reports Module</h5>
            <p class="text-muted">This module is under development. It will provide comprehensive statistics and analytics about:</p>
            <ul class="list-unstyled text-muted">
                <li><i class="fas fa-check"></i> Request statistics by type and status</li>
                <li><i class="fas fa-check"></i> User engagement metrics</li>
                <li><i class="fas fa-check"></i> Sacramental records summary</li>
                <li><i class="fas fa-check"></i> Monthly/yearly reports</li>
                <li><i class="fas fa-check"></i> Downloadable reports in PDF</li>
            </ul>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
