<?php
/**
 * Admin Settings
 * Maintenance and recovery tools for backups.
 */

include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

requireAdmin();

$page_title = 'Settings';
$error = '';
$success = '';
$backup_dir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'backups';
$project_root = realpath(__DIR__ . '/..');

function ensureBackupDirectory($backup_dir) {
    if (!is_dir($backup_dir) && !mkdir($backup_dir, 0755, true)) {
        return false;
    }

    $index_file = $backup_dir . DIRECTORY_SEPARATOR . 'index.php';
    if (!file_exists($index_file)) {
        file_put_contents($index_file, "<?php\nhttp_response_code(403);\nexit('Access denied');\n");
    }

    $htaccess_file = $backup_dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!file_exists($htaccess_file)) {
        file_put_contents($htaccess_file, "Options -Indexes\nRequire all denied\nDeny from all\n");
    }

    return is_writable($backup_dir);
}

function sqlValue($conn, $value) {
    if ($value === null) {
        return 'NULL';
    }

    return "'" . $conn->real_escape_string((string) $value) . "'";
}

function createDatabaseBackup($conn, $backup_dir) {
    if (!ensureBackupDirectory($backup_dir)) {
        throw new Exception('Backup folder is not writable.');
    }

    $filename = 'database-backup-' . date('Ymd-His') . '.sql';
    $path = $backup_dir . DIRECTORY_SEPARATOR . $filename;
    $handle = fopen($path, 'w');
    if (!$handle) {
        throw new Exception('Unable to create database backup file.');
    }

    fwrite($handle, "-- Parish Management System Database Backup\n");
    fwrite($handle, "-- Created: " . date('Y-m-d H:i:s') . "\n\n");
    fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables_result = $conn->query('SHOW TABLES');
    if (!$tables_result) {
        fclose($handle);
        throw new Exception('Unable to read database tables: ' . $conn->error);
    }

    while ($table_row = $tables_result->fetch_array()) {
        $table = $table_row[0];
        $safe_table = str_replace('`', '``', $table);

        fwrite($handle, "DROP TABLE IF EXISTS `$safe_table`;\n");
        $create_result = $conn->query("SHOW CREATE TABLE `$safe_table`");
        if (!$create_result) {
            fclose($handle);
            throw new Exception("Unable to read table structure for $table: " . $conn->error);
        }

        $create_row = $create_result->fetch_assoc();
        fwrite($handle, $create_row['Create Table'] . ";\n\n");

        $rows_result = $conn->query("SELECT * FROM `$safe_table`");
        if (!$rows_result) {
            fclose($handle);
            throw new Exception("Unable to read rows from $table: " . $conn->error);
        }

        while ($row = $rows_result->fetch_assoc()) {
            $columns = array_map(function ($column) {
                return '`' . str_replace('`', '``', $column) . '`';
            }, array_keys($row));
            $values = array_map(function ($value) use ($conn) {
                return sqlValue($conn, $value);
            }, array_values($row));

            fwrite($handle, "INSERT INTO `$safe_table` (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $values) . ");\n");
        }

        fwrite($handle, "\n");
    }

    fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($handle);

    return $path;
}

function addProjectFilesToZip($zip, $project_root, $backup_dir) {
    $root_length = strlen($project_root) + 1;
    $backup_real = realpath($backup_dir);
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($project_root, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $file) {
        $path = $file->getPathname();
        $real_path = realpath($path);

        if ($backup_real && strpos($real_path, $backup_real) === 0) {
            continue;
        }

        $relative_path = str_replace('\\', '/', substr($path, $root_length));
        if ($file->isDir()) {
            $zip->addEmptyDir($relative_path);
        } else {
            $zip->addFile($path, $relative_path);
        }
    }
}

function createFullBackup($conn, $backup_dir, $project_root) {
    if (!class_exists('ZipArchive')) {
        throw new Exception('PHP ZipArchive is not enabled. Enable the zip extension in XAMPP to create full file backups.');
    }

    if (!ensureBackupDirectory($backup_dir)) {
        throw new Exception('Backup folder is not writable.');
    }

    $database_backup = createDatabaseBackup($conn, $backup_dir);
    $filename = 'full-backup-' . date('Ymd-His') . '.zip';
    $path = $backup_dir . DIRECTORY_SEPARATOR . $filename;

    $zip = new ZipArchive();
    if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new Exception('Unable to create full backup ZIP file.');
    }

    addProjectFilesToZip($zip, $project_root, $backup_dir);
    $zip->addFile($database_backup, 'RECOVERY/database.sql');
    $zip->addFromString('RECOVERY/README.txt', "Recovery backup created " . date('Y-m-d H:i:s') . "\n\nRestore files by copying the project files back to the ParishSystem folder.\nRestore records by importing RECOVERY/database.sql into the parish_management_system database.\n");
    $zip->close();

    return $path;
}

function getBackupFiles($backup_dir) {
    if (!is_dir($backup_dir)) {
        return [];
    }

    $files = glob($backup_dir . DIRECTORY_SEPARATOR . '*.{sql,zip}', GLOB_BRACE);
    usort($files, function ($a, $b) {
        return filemtime($b) <=> filemtime($a);
    });

    return $files;
}

if (isset($_GET['download'])) {
    $requested = basename($_GET['download']);
    $path = $backup_dir . DIRECTORY_SEPARATOR . $requested;
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));

    if (!in_array($extension, ['sql', 'zip'], true) || !is_file($path)) {
        http_response_code(404);
        exit('Backup file not found.');
    }

    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'database_backup') {
            $path = createDatabaseBackup($conn, $backup_dir);
            createAuditLog($conn, $_SESSION['user_id'], 'CREATE_DATABASE_BACKUP', 'system', 0);
            $success = 'Database backup created: ' . basename($path);
        } elseif ($action === 'full_backup') {
            $path = createFullBackup($conn, $backup_dir, $project_root);
            createAuditLog($conn, $_SESSION['user_id'], 'CREATE_FULL_BACKUP', 'system', 0);
            $success = 'Full recovery backup created: ' . basename($path);
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$backup_files = getBackupFiles($backup_dir);

$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Settings' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <?php include '../includes/breadcrumb.php'; ?>

    <?php include '../includes/back_button.php'; ?>

    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="mb-2"><i class="fas fa-cog"></i> Settings</h1>
            <p class="text-muted">Maintenance and recovery tools for parish files and records</p>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-database"></i> Database Backup</h5>
                    <p class="text-muted">Creates a SQL copy of users, requests, reservations, announcements, sacramental records, and other database tables.</p>
                    <form method="POST">
                        <input type="hidden" name="action" value="database_backup">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-download"></i> Create Database Backup
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-shield-halved"></i> Full Recovery Backup</h5>
                    <p class="text-muted">Creates a ZIP copy of the project files plus a database recovery SQL file. Use this if files are corrupted or deleted.</p>
                    <form method="POST">
                        <input type="hidden" name="action" value="full_backup">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-file-zipper"></i> Create Full Backup
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title"><i class="fas fa-clock-rotate-left"></i> Available Backup Files</h5>

            <?php if (count($backup_files) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>File</th>
                                <th>Type</th>
                                <th>Size</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backup_files as $file): ?>
                                <tr>
                                    <td><strong><?php echo e(basename($file)); ?></strong></td>
                                    <td><?php echo strtoupper(e(pathinfo($file, PATHINFO_EXTENSION))); ?></td>
                                    <td><?php echo number_format(filesize($file) / 1024, 2); ?> KB</td>
                                    <td><?php echo date('M d, Y g:i A', filemtime($file)); ?></td>
                                    <td>
                                        <a href="?download=<?php echo urlencode(basename($file)); ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-download"></i> Download
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info mb-0">No backup files created yet.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="alert alert-warning mt-4">
        <strong>Recovery reminder:</strong> keep a copy of full backups outside this computer, such as an external drive or secure cloud storage. If the whole XAMPP folder is lost, local backups can be lost too.
    </div>
</div>

<?php include '../templates/footer.php'; ?>
