<?php
/**
 * Admin - Process Request Page
 * Handle request review, approval, and management
 * 
 * This file was MISSING - causing the "404 Not Found" error
 * Fixed: May 8, 2026
 */

// Include security and dependencies
include '../config/security.php';
include '../includes/Security.php';
include '../includes/Logger.php';
include '../database/BaseDB.php';
include '../database/config.php';
include '../includes/session.php';
include '../includes/helpers.php';

// Check admin access
requireAdmin();

// Initialize components
$logger = new Logger();
$db = new BaseDB($conn);

// Get request ID from URL
$request_id = (int)($_GET['id'] ?? 0);

if ($request_id === 0) {
    header("Location: manage-requests.php");
    exit;
}

// Fetch request details
$sql = "SELECT r.*, u.id as user_id, u.fullname, u.email, u.phone_number, u.chapel_district, u.created_at as user_created_at
        FROM requests r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.request_id = ? AND r.deleted_at IS NULL
        LIMIT 1";

$request = $db->selectOne($sql, 'i', [$request_id]);

if (!$request) {
    header("Location: manage-requests.php?error=Request not found");
    exit;
}

// Handle form submission (Approve/Reject/Add Remarks)
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Verify CSRF token
        $security = new Security();
        $csrf_token = $_POST['csrf_token'] ?? '';
        if (!$security->verifyCSRFToken($csrf_token)) {
            throw new Exception('CSRF token validation failed');
        }

        $action = trim($_POST['action'] ?? '');
        $admin_response = trim($_POST['admin_response'] ?? '');
        $new_status = trim($_POST['status'] ?? '');

        // Validate action
        if (!in_array($action, ['approve', 'reject', 'request_more', 'complete', 'remark'])) {
            throw new Exception('Invalid action');
        }

        // Map actions to statuses
        $status_map = [
            'approve' => 'approved',
            'reject' => 'rejected',
            'request_more' => 'processing',
            'complete' => 'completed',
            'remark' => $request['status']  // Keep current status
        ];

        $new_status = $status_map[$action];

        // Start transaction
        $db->beginTransaction();

        try {
            // Update request
            $update_sql = "UPDATE requests 
                          SET status = ?, 
                              admin_response = ?, 
                              updated_at = NOW() 
                          WHERE request_id = ?";
            
            $db->update($update_sql, 'ssi', [$new_status, $admin_response, $request_id]);

            // Log to audit trail
            $audit_sql = "INSERT INTO audit_logs (user_id, action_type, table_name, record_id, new_value) 
                         VALUES (?, ?, ?, ?, ?)";
            $action_type = strtoupper($action);
            $new_value = json_encode(['status' => $new_status, 'admin_response' => $admin_response]);
            $db->insert($audit_sql, 'issss', [$_SESSION['user_id'], $action_type, 'requests', $request_id, $new_value]);

            // Create notification for user
            $notification_sql = "INSERT INTO notifications_log (user_id, notification_type, subject, message, status, recipient) 
                                VALUES (?, ?, ?, ?, ?, ?)";
            
            $notification_messages = [
                'approve' => 'Your request has been approved!',
                'reject' => 'Your request has been rejected. ' . $admin_response,
                'request_more' => 'Your request requires additional information. ' . $admin_response,
                'complete' => 'Your request has been completed!',
                'remark' => 'Your request has been updated with remarks.'
            ];

            $notification_subject = ucfirst(str_replace('_', ' ', $action)) . ' - Request #' . $request['reference_number'];
            $notification_message = $notification_messages[$action];

            $db->insert($notification_sql, 'isssss', [
                $request['user_id'],
                'email',
                $notification_subject,
                $notification_message,
                'pending',
                $request['email']
            ]);

            // If approved, prepare for certificate generation
            if ($action === 'approve') {
                // This can trigger automatic certificate generation
                $logger->info('Request approved - ready for certificate generation', [
                    'request_id' => $request_id,
                    'user_id' => $request['user_id']
                ]);
            }

            // Commit transaction
            $db->commit();

            $success_message = 'Request ' . $action . 'd successfully! User has been notified.';
            
            // Log the action
            $logger->info('Admin processed request', [
                'request_id' => $request_id,
                'user_id' => $request['user_id'],
                'action' => $action,
                'admin_id' => $_SESSION['user_id']
            ]);

            // Refresh request data
            $request = $db->selectOne($sql, 'i', [$request_id]);

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

    } catch (Exception $e) {
        $error_message = $e->getMessage();
        $logger->error('Error processing request: ' . $e->getMessage());
    }
}

// Get request history
$history_sql = "SELECT * FROM audit_logs 
               WHERE table_name = 'requests' AND record_id = ? 
               ORDER BY timestamp DESC";
$history = $db->select($history_sql, 'i', [$request_id]);

// Get request documents if any
$docs_sql = "SELECT * FROM request_documents WHERE request_id = ? AND deleted_at IS NULL";
$documents = $db->select($docs_sql, 'i', [$request_id]);

$page_title = 'Review Request - #' . $request['reference_number'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Parish Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/holy-theme.css">
    <style>
        body {
            background: linear-gradient(135deg, #1E3A5F 0%, #2d5a7b 100%);
            min-height: 100vh;
            font-family: 'Poppins', 'Inter', sans-serif;
        }

        .container-main {
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .card-header-holy {
            background: linear-gradient(135deg, #1E3A5F 0%, #10B981 100%);
            color: white;
            padding: 20px;
            border-radius: 12px 12px 0 0;
            border-left: 5px solid #D4AF37;
        }

        .request-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border-top: 4px solid #10B981;
        }

        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
        }

        .status-pending {
            background: #FFF3CD;
            color: #856404;
        }

        .status-approved {
            background: #D4EDDA;
            color: #155724;
        }

        .status-rejected {
            background: #F8D7DA;
            color: #721C24;
        }

        .status-completed {
            background: #D1ECF1;
            color: #0C5460;
        }

        .status-processing {
            background: #E2E3E5;
            color: #383D41;
        }

        .info-block {
            background: #F8F9FA;
            border-left: 4px solid #D4AF37;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .info-label {
            font-weight: 600;
            color: #1E3A5F;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .info-value {
            color: #333;
            font-size: 15px;
        }

        .action-btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
        }

        .btn-approve {
            background: linear-gradient(135deg, #10B981 0%, #059669 100%);
            color: white;
        }

        .btn-approve:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
            color: white;
        }

        .btn-reject {
            background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
            color: white;
        }

        .btn-reject:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(239, 68, 68, 0.3);
            color: white;
        }

        .btn-more-info {
            background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
            color: white;
        }

        .btn-more-info:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(245, 158, 11, 0.3);
            color: white;
        }

        .btn-complete {
            background: linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%);
            color: white;
        }

        .btn-complete:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
            color: white;
        }

        .timeline {
            position: relative;
            padding: 20px 0;
        }

        .timeline-item {
            display: flex;
            margin-bottom: 20px;
        }

        .timeline-marker {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #D4AF37 0%, #B8860B 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-right: 15px;
            flex-shrink: 0;
            font-size: 18px;
        }

        .timeline-content {
            flex-grow: 1;
        }

        .timeline-date {
            color: #666;
            font-size: 12px;
            margin-bottom: 5px;
        }

        .timeline-title {
            font-weight: 600;
            color: #1E3A5F;
            margin-bottom: 5px;
        }

        .timeline-description {
            color: #555;
            font-size: 14px;
        }

        .modal-header-holy {
            background: linear-gradient(135deg, #1E3A5F 0%, #10B981 100%);
            color: white;
            border: none;
        }

        .form-label {
            color: #1E3A5F;
            font-weight: 600;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #D4AF37;
            font-size: 14px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #10B981;
            box-shadow: 0 0 0 0.2rem rgba(16, 185, 129, 0.1);
        }

        .back-link {
            color: white;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            color: #D4AF37;
        }

        .header-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #D4AF37 0%, #B8860B 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container-main">
        <!-- Back Button -->
        <a href="manage-requests.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Requests
        </a>

        <!-- Success/Error Messages -->
        <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header Section with Request Overview -->
        <div class="header-section">
            <div class="row align-items-center">
                <div class="col-auto">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
                <div class="col">
                    <h2 class="mb-0" style="color: #1E3A5F;">
                        <strong><?php echo htmlspecialchars($request['fullname']); ?></strong>
                    </h2>
                    <p class="text-muted mb-0">Reference: <strong><?php echo $request['reference_number']; ?></strong></p>
                </div>
                <div class="col-auto">
                    <span class="status-badge status-<?php echo $request['status']; ?>">
                        <?php echo ucfirst($request['status']); ?>
                    </span>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Main Content (Left) -->
            <div class="col-lg-8">
                <!-- Request Details Card -->
                <div class="request-card">
                    <div class="card-header-holy">
                        <h5 class="mb-0">
                            <i class="fas fa-file-alt"></i> REQUEST DETAILS
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Request Type</div>
                                    <div class="info-value">
                                        <?php echo ucfirst(str_replace('_', ' ', $request['request_type'])); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Request Date</div>
                                    <div class="info-value">
                                        <?php echo date('F d, Y H:i A', strtotime($request['date_requested'])); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if (!empty($request['description'])): ?>
                            <div class="info-block">
                                <div class="info-label">Description</div>
                                <div class="info-value">
                                    <?php echo nl2br(htmlspecialchars($request['description'])); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($request['admin_response'])): ?>
                            <div class="info-block" style="border-left-color: #EF4444; background: #FEE2E2;">
                                <div class="info-label">Previous Admin Response</div>
                                <div class="info-value">
                                    <?php echo nl2br(htmlspecialchars($request['admin_response'])); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- User Information Card -->
                <div class="request-card">
                    <div class="card-header-holy">
                        <h5 class="mb-0">
                            <i class="fas fa-user-circle"></i> USER INFORMATION
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Full Name</div>
                                    <div class="info-value"><?php echo htmlspecialchars($request['fullname']); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Email Address</div>
                                    <div class="info-value">
                                        <a href="mailto:<?php echo htmlspecialchars($request['email']); ?>">
                                            <?php echo htmlspecialchars($request['email']); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Phone Number</div>
                                    <div class="info-value">
                                        <a href="tel:<?php echo htmlspecialchars($request['phone_number']); ?>">
                                            <?php echo htmlspecialchars($request['phone_number']); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-block">
                                    <div class="info-label">Chapel District</div>
                                    <div class="info-value"><?php echo htmlspecialchars($request['chapel_district'] ?? 'N/A'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Timeline/History Card -->
                <?php if (!empty($history)): ?>
                    <div class="request-card">
                        <div class="card-header-holy">
                            <h5 class="mb-0">
                                <i class="fas fa-history"></i> REQUEST TIMELINE
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="timeline">
                                <?php foreach ($history as $item): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-marker">
                                            <i class="fas fa-check"></i>
                                        </div>
                                        <div class="timeline-content">
                                            <div class="timeline-date">
                                                <?php echo date('F d, Y H:i A', strtotime($item['timestamp'])); ?>
                                            </div>
                                            <div class="timeline-title">
                                                <?php echo ucfirst(str_replace('_', ' ', $item['action_type'])); ?>
                                            </div>
                                            <div class="timeline-description">
                                                <?php echo htmlspecialchars($item['action_type']); ?> by Admin
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar (Right) - Actions -->
            <div class="col-lg-4">
                <!-- Action Panel -->
                <div class="request-card">
                    <div class="card-header-holy">
                        <h5 class="mb-0">
                            <i class="fas fa-tasks"></i> ACTIONS
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['_csrf_token'] ?? ''); ?>">

                            <div class="mb-3">
                                <label for="status" class="form-label">Update Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="pending" <?php echo $request['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="approved" <?php echo $request['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="rejected" <?php echo $request['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                    <option value="processing" <?php echo $request['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $request['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="admin_response" class="form-label">Admin Remarks</label>
                                <textarea class="form-control" id="admin_response" name="admin_response" rows="4" placeholder="Add your remarks here..."></textarea>
                                <small class="text-muted">User will be notified of your remarks</small>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" name="action" value="approve" class="action-btn btn-approve" onclick="return confirm('Approve this request?');">
                                    <i class="fas fa-check"></i> Approve Request
                                </button>
                                <button type="submit" name="action" value="reject" class="action-btn btn-reject" onclick="return confirm('Reject this request?');">
                                    <i class="fas fa-times"></i> Reject Request
                                </button>
                                <button type="submit" name="action" value="request_more" class="action-btn btn-more-info" onclick="return confirm('Request more information?');">
                                    <i class="fas fa-question"></i> Request Info
                                </button>
                                <button type="submit" name="action" value="complete" class="action-btn btn-complete" onclick="return confirm('Mark as completed?');">
                                    <i class="fas fa-flag-checkered"></i> Complete
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Help Section -->
                <div class="request-card">
                    <div class="card-header-holy">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle"></i> GUIDE
                        </h5>
                    </div>
                    <div class="card-body">
                        <p style="font-size: 13px; color: #555;">
                            <strong style="color: #1E3A5F;">Approve:</strong> Request is validated and approved<br>
                            <strong style="color: #1E3A5F;">Reject:</strong> Request is denied<br>
                            <strong style="color: #1E3A5F;">Request Info:</strong> Need more details from user<br>
                            <strong style="color: #1E3A5F;">Complete:</strong> Final status - request fulfilled
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
