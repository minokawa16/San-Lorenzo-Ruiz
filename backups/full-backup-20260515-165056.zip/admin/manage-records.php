<?php
/**
 * Manage Records Page
 * Admin interface for managing sacramental records (Baptism, Confirmation, etc.)
 */

// Include centralized session management
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

// Require admin access
requireAdmin();

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add_baptism') {
        $fullname = $conn->real_escape_string(sanitize($_POST['fullname']));
        $birth_date = $conn->real_escape_string($_POST['birth_date']);
        $baptism_date = $conn->real_escape_string($_POST['baptism_date']);
        $parents = $conn->real_escape_string(sanitize($_POST['parents']));
        $godparents = $conn->real_escape_string(sanitize($_POST['godparents']));
        $priest = $conn->real_escape_string(sanitize($_POST['priest']));
        
        $sql = "INSERT INTO baptism_records (fullname, birth_date, baptism_date, parents, godparents, priest)
                VALUES ('$fullname', '$birth_date', '$baptism_date', '$parents', '$godparents', '$priest')";
        
        if ($conn->query($sql)) {
            $record_id = $conn->insert_id;
            createAuditLog($conn, $_SESSION['user_id'], 'ADD_RECORD', 'baptism_records', $record_id);
            $success = 'Baptism record added successfully!';
        } else {
            $error = 'Error adding record: ' . $conn->error;
        }
    }
}

// Get records
$record_type = $_GET['type'] ?? 'baptism';
$search = $_GET['search'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 10;

// Build query based on record type
switch($record_type) {
    case 'baptism':
        $table = 'baptism_records';
        $columns = 'baptism_id, fullname, birth_date, baptism_date, parents, godparents, priest';
        $search_columns = ['fullname', 'parents', 'godparents', 'priest'];
        break;
    case 'communion':
        $table = 'first_communion_records';
        $columns = 'communion_id as baptism_id, fullname, birth_date, communion_date as baptism_date, sponsor as godparents, priest';
        $search_columns = ['fullname', 'sponsor', 'priest'];
        break;
    case 'confirmation':
        $table = 'confirmation_records';
        $columns = 'confirmation_id as baptism_id, fullname, birth_date, confirmation_date as baptism_date, sponsor as godparents, bishop_priest as priest';
        $search_columns = ['fullname', 'confirmation_name', 'sponsor', 'bishop_priest'];
        break;
    case 'marriage':
        $table = 'marriage_records';
        $columns = 'marriage_id as baptism_id, husband_name as fullname, wedding_date as baptism_date, sponsors as godparents, officiating_priest as priest';
        $search_columns = ['husband_name', 'wife_name', 'sponsors', 'officiating_priest'];
        break;
    default:
        $record_type = 'baptism';
        $table = 'baptism_records';
        $columns = 'baptism_id, fullname, birth_date, baptism_date, parents, godparents, priest';
        $search_columns = ['fullname', 'parents', 'godparents', 'priest'];
}

$where = "WHERE status = 'active'";
if (!empty($search)) {
    $search_escaped = $conn->real_escape_string($search);
    $search_terms = array_map(function ($column) use ($search_escaped) {
        return "$column LIKE '%$search_escaped%'";
    }, $search_columns);
    $where .= " AND (" . implode(' OR ', $search_terms) . ")";
}

$total_result = $conn->query("SELECT COUNT(*) as count FROM $table $where");
$total = $total_result ? (int) $total_result->fetch_assoc()['count'] : 0;
if (!$total_result) {
    $error = 'Error loading record count: ' . $conn->error;
}
$pagination = getPaginationData($page, $limit, $total);

$sql = "SELECT $columns FROM $table $where ORDER BY baptism_date DESC LIMIT {$pagination['offset']}, {$pagination['limit']}";
$result = $conn->query($sql);
if (!$result) {
    $error = 'Error loading records: ' . $conn->error;
}

$page_title = 'Manage Sacramental Records';

// Set breadcrumb data
$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Manage Records' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <!-- Breadcrumb Navigation -->
    <?php include '../includes/breadcrumb.php'; ?>
    
    <!-- Back Button -->
    <?php include '../includes/back_button.php'; ?>

    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><i class="fas fa-book"></i> Sacramental Records</h1>
            <p class="text-muted">Manage and search sacramental records efficiently</p>
        </div>
        <div class="col-md-4 text-end">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRecordModal">
                <i class="fas fa-plus"></i> Add Record
            </button>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <!-- Type Selector -->
            <ul class="nav nav-tabs mb-3" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo $record_type == 'baptism' ? 'active' : ''; ?>" href="?type=baptism">
                        <i class="fas fa-water"></i> Baptism
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $record_type == 'communion' ? 'active' : ''; ?>" href="?type=communion">
                        <i class="fas fa-bread-slice"></i> First Communion
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $record_type == 'confirmation' ? 'active' : ''; ?>" href="?type=confirmation">
                        <i class="fas fa-dove"></i> Confirmation
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $record_type == 'marriage' ? 'active' : ''; ?>" href="?type=marriage">
                        <i class="fas fa-ring"></i> Marriage
                    </a>
                </li>
            </ul>

            <!-- Search -->
            <form method="GET" class="mb-3" action="">
                <input type="hidden" name="type" value="<?php echo $record_type; ?>">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" placeholder="Search by name..." value="<?php echo sanitize($search); ?>">
                    <button class="btn btn-outline-primary" type="submit">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>

            <!-- Records Table -->
            <?php if ($result && $result->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Details</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo sanitize($row['fullname']); ?></strong></td>
                                    <td><?php echo formatDate($row['baptism_date']); ?></td>
                                    <td>
                                        <small>Priest: <?php echo sanitize($row['priest']); ?><br>
                                        <?php if (isset($row['godparents'])): ?>
                                            Sponsor(s): <?php echo sanitize($row['godparents']); ?>
                                        <?php endif; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <a href="generate-cert.php?type=<?php echo $record_type; ?>&id=<?php echo $row['baptism_id']; ?>" class="btn btn-sm btn-outline-success" title="Generate Certificate">
                                            <i class="fas fa-certificate"></i>
                                        </a>
                                        <a href="#" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                                        <a href="#" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">No records found</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Record Modal -->
<div class="modal fade" id="addRecordModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Baptism Record</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_baptism">
                    
                    <div class="mb-3">
                        <label for="fullname" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="fullname" name="fullname" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="birth_date" class="form-label">Birth Date</label>
                            <input type="date" class="form-control" id="birth_date" name="birth_date" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="baptism_date" class="form-label">Baptism Date</label>
                            <input type="date" class="form-control" id="baptism_date" name="baptism_date" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="parents" class="form-label">Parents</label>
                        <input type="text" class="form-control" id="parents" name="parents">
                    </div>
                    <div class="mb-3">
                        <label for="godparents" class="form-label">Godparents</label>
                        <input type="text" class="form-control" id="godparents" name="godparents">
                    </div>
                    <div class="mb-3">
                        <label for="priest" class="form-label">Priest</label>
                        <input type="text" class="form-control" id="priest" name="priest" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
