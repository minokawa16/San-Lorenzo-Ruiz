<?php
/**
 * Manage Announcements Page
 * Admin interface for managing parish announcements
 */

// Include centralized session management
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

// Require admin access
requireAdmin();

$error = '';
$success = '';

// Handle form submission 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add_announcement') {
        $title = $conn->real_escape_string(sanitize($_POST['title']));
        $content = $conn->real_escape_string($_POST['content']);
        $type = $conn->real_escape_string($_POST['type']);
        $published_by = $_SESSION['user_id'];
        
        $sql = "INSERT INTO announcements (title, content, type, published_by, status)
                VALUES ('$title', '$content', '$type', '$published_by', 'active')";
        
        if ($conn->query($sql)) {
            $success = 'Announcement posted successfully!';
        } else {
            $error = 'Error posting announcement: ' . $conn->error;
        }
    }
}

// Get announcements
$page = intval($_GET['page'] ?? 1);
$limit = 10;

$total_result = $conn->query("SELECT COUNT(*) as count FROM announcements");
$total = $total_result->fetch_assoc()['count'];
$pagination = getPaginationData($page, $limit, $total);

$sql = "SELECT a.*, u.fullname FROM announcements a 
        JOIN users u ON a.published_by = u.id 
        ORDER BY a.published_date DESC 
        LIMIT {$pagination['offset']}, {$pagination['limit']}";
$result = $conn->query($sql);

$page_title = 'Manage Announcements';

// Set breadcrumb data
$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Manage Announcements' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <!-- Breadcrumb Navigation -->
    <?php include '../includes/breadcrumb.php'; ?>
    
    <!-- Back Button -->
    <?php include '../includes/back_button.php'; ?>
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><i class="fas fa-bullhorn"></i> Manage Announcements</h1>
        </div>
        <div class="col-md-4 text-end">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal">
                <i class="fas fa-plus"></i> New Announcement
            </button>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Announcements List -->
    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($announcement = $result->fetch_assoc()): ?>
                <div class="col-md-6 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title"><?php echo sanitize($announcement['title']); ?></h5>
                                <span class="badge bg-<?php echo $announcement['type'] == 'event' ? 'success' : 'info'; ?>">
                                    <?php echo ucfirst($announcement['type']); ?>
                                </span>
                            </div>
                            <p class="card-text text-muted"><?php echo substr(sanitize($announcement['content']), 0, 150); ?>...</p>
                            <small class="text-muted">
                                By <?php echo sanitize($announcement['fullname']); ?> on <?php echo formatDate($announcement['published_date']); ?>
                            </small>
                        </div>
                        <div class="card-footer bg-light">
                            <button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i> Edit</button>
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i> Delete</button>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">No announcements yet</div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Announcement Modal -->
<div class="modal fade" id="addAnnouncementModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Post New Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_announcement">
                    
                    <div class="mb-3">
                        <label for="type" class="form-label">Type</label>
                        <select class="form-select" id="type" name="type" required>
                            <option value="announcement">Announcement</option>
                            <option value="event">Event</option>
                            <option value="schedule">Schedule</option>
                            <option value="obituary">Obituary</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Post Announcement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
