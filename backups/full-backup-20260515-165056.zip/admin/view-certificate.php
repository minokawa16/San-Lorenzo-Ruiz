<?php
session_start();
include '../database/config.php';
include '../includes/helpers.php';

requireAdmin();

if (!isset($_SESSION['certificate_data']) || !isset($_SESSION['cert_type'])) {
    header('Location: certificate-generator.php');
    exit;
}

$data = $_SESSION['certificate_data'];
$cert_type = $_SESSION['cert_type'];

$page_title = 'View Certificate';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($cert_type); ?> Certificate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print {
            body { margin: 0; padding: 0; }
            .btn { display: none; }
        }
        
        .certificate {
            background: white;
            border: 3px solid #1a3a52;
            padding: 60px 40px;
            margin: 20px;
            text-align: center;
            font-family: Georgia, serif;
            min-height: 600px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }
        
        .certificate::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            bottom: 20px;
            border: 2px solid #d4af37;
            pointer-events: none;
        }
        
        .certificate-content {
            position: relative;
            z-index: 1;
        }
        
        .certificate-title {
            font-size: 2.5rem;
            color: #1a3a52;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .certificate-subtitle {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 30px;
        }
        
        .certificate-text {
            font-size: 1rem;
            margin: 20px 0;
        }
        
        .recipient-name {
            font-size: 1.8rem;
            color: #1a3a52;
            font-weight: bold;
            margin: 30px 0;
            text-decoration: underline;
        }
        
        .certificate-details {
            font-size: 0.95rem;
            margin-top: 40px;
        }
        
        .certificate-footer {
            display: flex;
            justify-content: space-around;
            margin-top: 60px;
            font-size: 0.9rem;
        }
        
        .signature-line {
            border-top: 1px solid #333;
            width: 150px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center my-3">
            <h3>Certificate Preview</h3>
            <div>
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Print
                </button>
                <a href="certificate-generator.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>

        <div class="certificate">
            <div class="certificate-content">
                <div class="certificate-title">SACRAMENTAL CERTIFICATE</div>
                <div class="certificate-subtitle">
                    <?php 
                    switch($cert_type) {
                        case 'baptism':
                            echo 'BAPTISM CERTIFICATE';
                            break;
                        case 'communion':
                            echo 'FIRST HOLY COMMUNION CERTIFICATE';
                            break;
                        case 'confirmation':
                            echo 'CONFIRMATION CERTIFICATE';
                            break;
                        case 'marriage':
                            echo 'MARRIAGE CERTIFICATE';
                            break;
                    }
                    ?>
                </div>

                <div class="certificate-text">
                    This is to certify that
                </div>

                <div class="recipient-name">
                    <?php 
                    if ($cert_type == 'marriage') {
                        echo sanitize($data['husband_name']) . ' & ' . sanitize($data['wife_name']);
                    } else {
                        echo sanitize($data['fullname']);
                    }
                    ?>
                </div>

                <div class="certificate-details">
                    <?php if ($cert_type == 'baptism'): ?>
                        <p>Was baptized on <strong><?php echo formatDate($data['baptism_date']); ?></strong></p>
                        <p>Born on <strong><?php echo formatDate($data['birth_date']); ?></strong></p>
                        <?php if(!empty($data['parents'])): ?>
                        <p>Parents: <strong><?php echo sanitize($data['parents']); ?></strong></p>
                        <?php endif; ?>
                        <?php if(!empty($data['godparents'])): ?>
                        <p>Godparents: <strong><?php echo sanitize($data['godparents']); ?></strong></p>
                        <?php endif; ?>
                        <p>Presided by: <strong><?php echo sanitize($data['priest']); ?></strong></p>
                        
                    <?php elseif ($cert_type == 'communion'): ?>
                        <p>Received First Holy Communion on <strong><?php echo formatDate($data['communion_date']); ?></strong></p>
                        <?php if(!empty($data['parents'])): ?>
                        <p>Parents: <strong><?php echo sanitize($data['parents']); ?></strong></p>
                        <?php endif; ?>
                        <p>Presided by: <strong><?php echo sanitize($data['priest']); ?></strong></p>
                        
                    <?php elseif ($cert_type == 'confirmation'): ?>
                        <p>Was confirmed on <strong><?php echo formatDate($data['confirmation_date']); ?></strong></p>
                        <?php if(!empty($data['confirmation_name'])): ?>
                        <p>Confirmation Name: <strong><?php echo sanitize($data['confirmation_name']); ?></strong></p>
                        <?php endif; ?>
                        <?php if(!empty($data['sponsor'])): ?>
                        <p>Sponsor: <strong><?php echo sanitize($data['sponsor']); ?></strong></p>
                        <?php endif; ?>
                        <p>Presided by: <strong><?php echo sanitize($data['bishop_priest']); ?></strong></p>
                        
                    <?php elseif ($cert_type == 'marriage'): ?>
                        <p>Were united in marriage on <strong><?php echo formatDate($data['wedding_date']); ?></strong></p>
                        <?php if(!empty($data['sponsors'])): ?>
                        <p>Sponsors: <strong><?php echo sanitize($data['sponsors']); ?></strong></p>
                        <?php endif; ?>
                        <p>Presided by: <strong><?php echo sanitize($data['officiating_priest']); ?></strong></p>
                    <?php endif; ?>
                </div>

                <div class="certificate-footer">
                    <div class="text-center">
                        <div class="signature-line"></div>
                        <small>Parish Seal</small>
                    </div>
                    <div class="text-center">
                        <p><small><?php echo date('M d, Y'); ?></small></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
