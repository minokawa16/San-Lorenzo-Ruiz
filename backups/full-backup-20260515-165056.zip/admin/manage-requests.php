<?php
/**
 * Manage Requests Page
 * Admin interface for managing user requests
 */

// Include centralized session management
include '../includes/session.php';
include '../database/config.php';
include '../includes/helpers.php';

// Require admin access
requireAdmin();

$error = '';
$success = '';

// Handle status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_id'])) {
    $request_id = intval($_POST['request_id']);
    $status = $conn->real_escape_string($_POST['status']);
    $admin_response = $conn->real_escape_string($_POST['admin_response']);
    
    $sql = "UPDATE requests SET status = '$status', admin_response = '$admin_response' 
            WHERE request_id = $request_id";
    
    if ($conn->query($sql)) {
        // Get user_id for notification
        $req_result = $conn->query("SELECT user_id FROM requests WHERE request_id = $request_id");
        $req_data = $req_result->fetch_assoc();
        
        // Create notification
        createNotification($conn, $req_data['user_id'], 'Request Update', 
                         "Your request status has been updated to: " . ucfirst($status));
        
        createAuditLog($conn, $_SESSION['user_id'], 'UPDATE_REQUEST', 'requests', $request_id);
        $success = 'Request updated successfully!';
    } else {
        $error = 'Error updating request: ' . $conn->error;
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$count_where = "WHERE 1=1";
$list_where = "WHERE 1=1";
if (!empty($status_filter)) {
    $status_filter = $conn->real_escape_string($status_filter);
    $count_where .= " AND status = '$status_filter'";
    $list_where .= " AND r.status = '$status_filter'";
}

$page = intval($_GET['page'] ?? 1);
$limit = 10;

$total_result = $conn->query("SELECT COUNT(*) as count FROM requests $count_where");
$total = $total_result ? (int) $total_result->fetch_assoc()['count'] : 0;
if (!$total_result) {
    $error = 'Error loading request count: ' . $conn->error;
}
$pagination = getPaginationData($page, $limit, $total);

$sql = "SELECT r.*, u.fullname, u.email FROM requests r 
        JOIN users u ON r.user_id = u.id 
        $list_where 
        ORDER BY r.date_requested DESC 
        LIMIT {$pagination['offset']}, {$pagination['limit']}";
$result = $conn->query($sql);
if (!$result) {
    $error = 'Error loading requests: ' . $conn->error;
}

$page_title = 'Manage Requests';

// Set breadcrumb data
$breadcrumbs = [
    'Dashboard' => 'dashboard.php',
    'Manage Requests' => null
];
?>
<?php include '../templates/header.php'; ?>

<div class="container-fluid mt-4">
    <!-- Breadcrumb Navigation -->
    <?php include '../includes/breadcrumb.php'; ?>
    
    <!-- Back Button -->
    <?php include '../includes/back_button.php'; ?>

    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><i class="fas fa-tasks"></i> Manage Requests</h1>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <!-- Filter Buttons -->
            <div class="btn-group mb-3" role="group">
                <a href="?status=" class="btn btn-outline-primary <?php echo empty($status_filter) ? 'active' : ''; ?>">
                    All
                </a>
                <a href="?status=pending" class="btn btn-outline-warning <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">
                    Pending
                </a>
                <a href="?status=approved" class="btn btn-outline-success <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">
                    Approved
                </a>
                <a href="?status=rejected" class="btn btn-outline-danger <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">
                    Rejected
                </a>
                <a href="?status=completed" class="btn btn-outline-info <?php echo $status_filter == 'completed' ? 'active' : ''; ?>">
                    Completed
                </a>
            </div>

            <!-- Requests Table -->
            <?php if ($result && $result->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Ref #</th>
                                <th>User</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($request = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo $request['reference_number']; ?></strong></td>
                                    <td><?php echo sanitize($request['fullname']); ?><br><small><?php echo $request['email']; ?></small></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $request['request_type'])); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo getStatusBadgeClass($request['status']); ?>">
                                            <?php echo ucfirst($request['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($request['date_requested']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" 
                                                data-bs-target="#processModal" 
                                                data-request-id="<?php echo $request['request_id']; ?>"
                                                data-request-type="<?php echo $request['request_type']; ?>"
                                                data-current-status="<?php echo $request['status']; ?>">
                                            <i class="fas fa-edit"></i> Process
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($pagination['total_pages'] > 1): ?>
                    <nav class="mt-3">
                        <ul class="pagination justify-content-center">
                            <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&status=<?php echo $status_filter; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">No requests found</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Process Request Modal -->
<div class="modal fade" id="processModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Process Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="request_id" id="request_id">
                    
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="admin_response" class="form-label">Admin Response/Notes</label>
                        <textarea class="form-control" id="admin_response" name="admin_response" rows="4"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('processModal').addEventListener('show.bs.modal', function(e) {
    const button = e.relatedTarget;
    document.getElementById('request_id').value = button.getAttribute('data-request-id');
    document.getElementById('status').value = button.getAttribute('data-current-status');
});
</script>

<?php include '../templates/footer.php'; ?>
