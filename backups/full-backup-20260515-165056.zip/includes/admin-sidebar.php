<?php
/**
 * ADMIN SIDEBAR NAVIGATION
 * Modern redesigned sidebar matching user sidebar UI/UX
 * Displays navigation menu for parish administrative staff
 */
?>

<aside class="admin-sidebar" id="adminSidebar">
  <div class="sidebar-brand">
    <div class="brand-logo">
      <i class="fas fa-crown"></i>
    </div>
    <div class="brand-text">
      <div class="brand-title">ADMIN</div>
      <div class="brand-subtitle">Control Panel</div>
    </div>
    <button class="sidebar-toggle" id="adminSidebarToggle">
      <i class="fas fa-bars"></i>
    </button>
  </div>

  <nav class="sidebar-nav">
    <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php' && strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'active' : ''; ?>" data-tooltip="Dashboard">
      <i class="fas fa-gauge"></i>
      <span>Dashboard</span>
    </a>

    <div class="nav-section-label">Request Management</div>
    <a href="<?php echo BASE_URL; ?>admin/manage-requests.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'manage-requests.php') ? 'active' : ''; ?>" data-tooltip="Manage Requests">
      <i class="fas fa-inbox"></i>
      <span>Pending Requests</span>
      <span class="pill-badge" id="pendingBadge" style="display:none;">0</span>
    </a>

    <div class="nav-section-label">Sacramental Records</div>
    <a href="<?php echo BASE_URL; ?>admin/manage-records.php" class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['manage-records.php', 'baptism-records.php', 'confirmation-records.php', 'communion-records.php', 'marriage-records.php']) ? 'active' : ''; ?>" data-tooltip="Sacramental Records">
      <i class="fas fa-book-bible"></i>
      <span>Sacramental Records</span>
    </a>

    <div class="nav-section-label">Operations</div>
    <a href="<?php echo BASE_URL; ?>admin/certificate-generator.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'certificate-generator.php') ? 'active' : ''; ?>" data-tooltip="Generate Certificates">
      <i class="fas fa-certificate"></i>
      <span>Generate Certificates</span>
    </a>
    <a href="<?php echo BASE_URL; ?>admin/manage-announcements.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'manage-announcements.php') ? 'active' : ''; ?>" data-tooltip="Announcements">
      <i class="fas fa-bullhorn"></i>
      <span>Announcements</span>
    </a>
    <a href="<?php echo BASE_URL; ?>admin/manage-calendar.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'manage-calendar.php') ? 'active' : ''; ?>" data-tooltip="Calendar">
      <i class="fas fa-calendar-days"></i>
      <span>Calendar</span>
    </a>

    <div class="nav-section-label">Administration</div>
    <a href="<?php echo BASE_URL; ?>admin/manage-users.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'manage-users.php') ? 'active' : ''; ?>" data-tooltip="Users">
      <i class="fas fa-users"></i>
      <span>Users</span>
    </a>
    <a href="<?php echo BASE_URL; ?>admin/reports.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'reports.php') ? 'active' : ''; ?>" data-tooltip="Reports">
      <i class="fas fa-chart-bar"></i>
      <span>Reports</span>
    </a>
    <a href="<?php echo BASE_URL; ?>admin/settings.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'settings.php') ? 'active' : ''; ?>" data-tooltip="Settings">
      <i class="fas fa-cog"></i>
      <span>Settings</span>
    </a>

    <div class="nav-section-label">Account</div>
    <a href="<?php echo BASE_URL; ?>auth/logout.php" class="nav-link logout" data-tooltip="Logout">
      <i class="fas fa-arrow-right-from-bracket"></i>
      <span>Logout</span>
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="profile-mini">
      <span class="profile-dot"></span>
      <span><?php echo substr($_SESSION['fullname'], 0, 15); ?></span>
    </div>
  </div>
</aside>

<style>
/* Admin Sidebar Styles - Modern Design */
.admin-sidebar {
  position: fixed;
  left: 0;
  top: 0;
  width: 260px;
  height: 100vh;
  background: linear-gradient(180deg, #0f172a 0%, #1e3a8a 100%);
  color: white;
  overflow-y: auto;
  z-index: 900;
  box-shadow: var(--shadow-lg);
  transition: width 0.3s ease;
}

.admin-sidebar .sidebar-brand {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 18px 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}

.brand-logo {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  background: rgba(255, 193, 7, 0.18);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fbbf24;
}

.brand-text {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.brand-title {
  font-weight: 700;
  letter-spacing: 0.4px;
  font-size: 1rem;
}

.brand-subtitle {
  font-size: 0.75rem;
  opacity: 0.7;
}

.sidebar-toggle {
  background: none;
  border: none;
  color: white;
  font-size: 1.1rem;
  cursor: pointer;
}

.sidebar-nav {
  padding: 20px 16px 90px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.nav-section-label {
  text-transform: uppercase;
  font-size: 0.7rem;
  letter-spacing: 1px;
  color: rgba(255, 255, 255, 0.5);
  margin: 16px 8px 6px;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 12px;
  color: rgba(255, 255, 255, 0.75);
  text-decoration: none;
  transition: all 0.2s ease;
  position: relative;
}

.nav-link i {
  min-width: 22px;
  text-align: center;
}

.nav-link:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #fbbf24;
}

.nav-link.active {
  background: rgba(251, 191, 36, 0.18);
  color: #fbbf24;
  box-shadow: inset 3px 0 0 #fbbf24;
}

.nav-link.logout {
  color: #fca5a5;
}

.pill-badge {
  margin-left: auto;
  background: #ef4444;
  color: white;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 0.7rem;
}

.sidebar-footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: 14px 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.12);
  background: rgba(15, 23, 42, 0.8);
}

.profile-mini {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.85rem;
}

.profile-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #22c55e;
}

body.admin-sidebar-collapsed .admin-sidebar {
  width: 88px;
}

body.admin-sidebar-collapsed .admin-sidebar .brand-text,
body.admin-sidebar-collapsed .admin-sidebar .nav-link span,
body.admin-sidebar-collapsed .admin-sidebar .nav-section-label,
body.admin-sidebar-collapsed .admin-sidebar .pill-badge,
body.admin-sidebar-collapsed .admin-sidebar .profile-mini {
  display: none;
}

body.admin-sidebar-collapsed .admin-sidebar .nav-link::after {
  content: attr(data-tooltip);
  position: absolute;
  left: 72px;
  background: #0f172a;
  color: white;
  padding: 6px 10px;
  border-radius: 8px;
  font-size: 0.75rem;
  white-space: nowrap;
  opacity: 0;
  transform: translateX(-6px);
  pointer-events: none;
  transition: all 0.2s ease;
}

body.admin-sidebar-collapsed .admin-sidebar .nav-link:hover::after {
  opacity: 1;
  transform: translateX(0);
}

/* Mobile Responsive */
@media (max-width: 768px) {
  .admin-sidebar {
    transform: translateX(-100%);
    width: 260px;
  }

  .admin-sidebar.open {
    transform: translateX(0);
}
}
</style>

<script>
// Sidebar Toggle for Mobile
document.addEventListener('DOMContentLoaded', function() {
  const sidebarToggle = document.getElementById('adminSidebarToggle');
  const sidebar = document.querySelector('.admin-sidebar');

  if (localStorage.getItem('adminSidebarCollapsed') === 'true') {
    document.body.classList.add('admin-sidebar-collapsed');
  }

  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function() {
      if (window.innerWidth <= 768) {
        sidebar.classList.toggle('open');
      } else {
        document.body.classList.toggle('admin-sidebar-collapsed');
        localStorage.setItem(
          'adminSidebarCollapsed',
          document.body.classList.contains('admin-sidebar-collapsed')
        );
      }
    });
  }
});
</script>
