<?php
/**
 * Helper Functions and Authentication
 * AI-Powered Parish Request and Sacramental Records Management System
 * Provides utility functions for authentication, validation, and security
 */

if (!defined('BASE_URL')) {
    define('BASE_URL', '/ParishSystem/');
}

// Generate unique reference numbers for requests
function generateReferenceNumber() {
    return 'PRQ-' . date('Ymd') . '-' . mt_rand(10000, 99999);
}

// Sanitize input data - remove special characters and trim whitespace
function sanitize($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function e($data) {
    return htmlspecialchars((string) $data, ENT_QUOTES, 'UTF-8');
}

// Validate email format
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Hash password using bcrypt (PASSWORD_DEFAULT uses bcrypt by default)
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
}

// Verify password against bcrypt hash
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Check if password needs rehashing (for bcrypt algorithm updates)
function passwordNeedsRehash($hash) {
    return password_needs_rehash($hash, PASSWORD_DEFAULT, ['cost' => 10]);
}

// Validate password strength
function isValidPassword($password) {
    // Minimum 8 characters, at least one uppercase, one lowercase, one number
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/', $password);
}

// Create notification
function createNotification($conn, $user_id, $title, $message) {
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    if (!$stmt) {
        return false;
    }

    $user_id = intval($user_id);
    $stmt->bind_param('iss', $user_id, $title, $message);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

// Get notification count
function getUnreadNotificationCount($conn, $user_id) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    if (!$stmt) {
        return 0;
    }

    $user_id = intval($user_id);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : ['count' => 0];
    $stmt->close();
    return intval($row['count'] ?? 0);
}

function getRecentNotifications($conn, $user_id, $limit = 5) {
    $notifications = [];
    $stmt = $conn->prepare("SELECT notification_id, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    if (!$stmt) {
        return $notifications;
    }

    $user_id = intval($user_id);
    $limit = max(1, intval($limit));
    $stmt->bind_param('ii', $user_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($result && $row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
    return $notifications;
}

// Log audit trail for admin actions
function createAuditLog($conn, $user_id, $action, $table_name, $record_id, $old_value = null, $new_value = null) {
    $user_id = !empty($user_id) ? intval($user_id) : 'NULL';
    $action = $conn->real_escape_string($action);
    $table_name = $conn->real_escape_string($table_name);
    $old_value = $old_value ? $conn->real_escape_string(json_encode($old_value)) : 'NULL';
    $new_value = $new_value ? $conn->real_escape_string(json_encode($new_value)) : 'NULL';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $ip = $conn->real_escape_string($ip);
    
    $sql = "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value, ip_address)
            VALUES ($user_id, '$action', '$table_name', $record_id, '$old_value', '$new_value', '$ip')";
    return $conn->query($sql);
}

// Format date for display
function formatDate($date) {
    if (empty($date)) {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

function formatDateTime($date) {
    if (empty($date)) {
        return 'N/A';
    }
    return date('M d, Y g:i A', strtotime($date));
}

function formatTime($time) {
    if (empty($time)) {
        return '';
    }
    return date('g:i A', strtotime($time));
}

function scheduleEventColumnExists($conn, $column) {
    $column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM schedule_events LIKE '$column'");
    return $result && $result->num_rows > 0;
}

function ensureScheduleEventsTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS schedule_events (
        schedule_id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        event_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NULL,
        location VARCHAR(150),
        category VARCHAR(50) DEFAULT 'event',
        priority VARCHAR(20) DEFAULT 'normal',
        color_label VARCHAR(20) DEFAULT '#1a73e8',
        recurrence_rule VARCHAR(100) DEFAULT 'none',
        assigned_personnel VARCHAR(150),
        visibility ENUM('public', 'private') DEFAULT 'public',
        approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
        status ENUM('active', 'upcoming', 'ongoing', 'finished', 'cancelled') DEFAULT 'upcoming',
        reminder_minutes INT DEFAULT 30,
        notify_email TINYINT(1) DEFAULT 0,
        notify_sms TINYINT(1) DEFAULT 0,
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
        INDEX idx_schedule_date (event_date),
        INDEX idx_schedule_status_date (status, event_date, start_time)
    )";

    if (!$conn->query($sql)) {
        return false;
    }

    $columns = [
        'category' => "ALTER TABLE schedule_events ADD COLUMN category VARCHAR(50) DEFAULT 'event' AFTER location",
        'priority' => "ALTER TABLE schedule_events ADD COLUMN priority VARCHAR(20) DEFAULT 'normal' AFTER category",
        'color_label' => "ALTER TABLE schedule_events ADD COLUMN color_label VARCHAR(20) DEFAULT '#1a73e8' AFTER priority",
        'recurrence_rule' => "ALTER TABLE schedule_events ADD COLUMN recurrence_rule VARCHAR(100) DEFAULT 'none' AFTER color_label",
        'assigned_personnel' => "ALTER TABLE schedule_events ADD COLUMN assigned_personnel VARCHAR(150) AFTER recurrence_rule",
        'visibility' => "ALTER TABLE schedule_events ADD COLUMN visibility ENUM('public', 'private') DEFAULT 'public' AFTER assigned_personnel",
        'approval_status' => "ALTER TABLE schedule_events ADD COLUMN approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved' AFTER visibility",
        'reminder_minutes' => "ALTER TABLE schedule_events ADD COLUMN reminder_minutes INT DEFAULT 30 AFTER status",
        'notify_email' => "ALTER TABLE schedule_events ADD COLUMN notify_email TINYINT(1) DEFAULT 0 AFTER reminder_minutes",
        'notify_sms' => "ALTER TABLE schedule_events ADD COLUMN notify_sms TINYINT(1) DEFAULT 0 AFTER notify_email"
    ];

    foreach ($columns as $column => $alterSql) {
        if (!scheduleEventColumnExists($conn, $column) && !$conn->query($alterSql)) {
            return false;
        }
    }

    $conn->query("ALTER TABLE schedule_events MODIFY COLUMN status ENUM('active', 'upcoming', 'ongoing', 'finished', 'cancelled') DEFAULT 'upcoming'");

    return true;
}

// Get user by ID
function getUserById($conn, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM users WHERE id = $id";
    $result = $conn->query($sql);
    return $result ? $result->fetch_assoc() : null;
}

// Get request status badge color
function getStatusBadgeClass($status) {
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'processing' => 'info',
        'completed' => 'success',
        'active' => 'success',
        'inactive' => 'secondary',
        'archived' => 'secondary'
    ];
    return $colors[$status] ?? 'secondary';
}

// Pagination helper
function getPaginationData($page, $limit, $total) {
    $page = max(1, intval($page));
    $limit = max(1, intval($limit));
    $offset = ($page - 1) * $limit;
    $total = intval($total);
    $total_pages = ceil($total / $limit);
    
    return [
        'page' => $page,
        'limit' => $limit,
        'offset' => $offset,
        'total' => $total,
        'total_pages' => $total_pages
    ];
}

// Redirect function
function redirect($location) {
    header("Location: $location");
    exit;
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check user role - admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Check user role - regular user
function isUser() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
}

// Require login - redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('../auth/login.php');
    }
}

// Require admin access
function requireAdmin() {
    if (!isLoggedIn() || !isAdmin()) {
        redirect('../auth/login.php');
    }
}

// Get current user full name
function getCurrentUserFullName() {
    return isset($_SESSION['fullname']) ? htmlspecialchars($_SESSION['fullname']) : 'User';
}

// Get current user ID
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
}

?>
